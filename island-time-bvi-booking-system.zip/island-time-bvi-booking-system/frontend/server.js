const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3000;

const server = http.createServer((req, res) => {
    // Serve index.html for the root path
    if (req.url === '/' || req.url === '/index.html') {
        fs.readFile(path.join(__dirname, 'index.html'), (err, data) => {
            if (err) {
                res.writeHead(500);
                res.end('Error loading index.html');
                return;
            }
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(data);
        });
    } 
    // Health check endpoint
    else if (req.url === '/api/health') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
            status: 'OK',
            message: 'Island Time BVI Frontend Server is running',
            timestamp: new Date().toISOString()
        }));
    }
    // Serve other files (CSS, JS, images)
    else {
        const filePath = path.join(__dirname, req.url);
        fs.readFile(filePath, (err, data) => {
            if (err) {
                res.writeHead(404);
                res.end('File not found');
                return;
            }
            
            // Set appropriate content type
            const ext = path.extname(filePath);
            const contentTypes = {
                '.html': 'text/html',
                '.css': 'text/css',
                '.js': 'application/javascript',
                '.png': 'image/png',
                '.jpg': 'image/jpeg',
                '.jpeg': 'image/jpeg',
                '.gif': 'image/gif',
                '.svg': 'image/svg+xml'
            };
            
            res.writeHead(200, { 
                'Content-Type': contentTypes[ext] || 'text/plain' 
            });
            res.end(data);
        });
    }
});

server.listen(PORT, () => {
    console.log('🏝️  ' + '='.repeat(50));
    console.log('🏝️  Island Time BVI Booking System');
    console.log('🏝️  Frontend Server Started Successfully!');
    console.log('🏝️  ' + '='.repeat(50));
    console.log(`🏝️  Frontend running on: http://localhost:${PORT}`);
    console.log(`📊  Health Check: http://localhost:${PORT}/api/health`);
    console.log(`🔗  Backend API: http://localhost:3001`);
    console.log(`👑  Admin Dashboard: http://localhost:3001/admin`);
    console.log('🏝️  ' + '='.repeat(50));
});