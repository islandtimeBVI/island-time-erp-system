// modify-booking.js
// This file handles booking modifications

class BookingModifier {
    constructor() {
        this.modificationData = null;
    }

    // Get the correct path to car rental service
    getCarRentalServicePath() {
        const currentPath = window.location.pathname;
        console.log('Current path:', currentPath);
        
        // Check if we're in dashboard
        if (currentPath.includes('/guest/')) {
            return '../car-rental-service.html';
        } else if (currentPath.includes('dashboard')) {
            return 'car-rental-service.html';
        } else {
            return '/car-rental-service.html';
        }
    }

    // Prepare booking data for modification
    prepareModificationData(trip) {
        if (!trip) return null;
        
        const modifyData = {
            id: trip.id,
            type: 'car-rental',
            serviceType: 'car-rental',
            carPreference: trip.vehicle || trip.carModel || 'Compact/Small Car',
            pickupLocation: trip.from,
            startDate: this.formatDateForModification(trip.date),
            endDate: this.getReturnDateForModification(trip),
            customerName: this.getCustomerName(),
            customerEmail: this.getCustomerEmail(),
            customerPhone: this.getCustomerPhone(),
            passengers: trip.passengers || 1,
            estimatedPrice: trip.price,
            price: trip.price,
            dates: trip.duration || `${trip.date} to ${this.getReturnDateForModification(trip)}`,
            status: trip.status || 'pending',
            time: '10:00 AM',
            from: trip.from,
            to: trip.from,
            icon: 'directions_car',
            drivers: trip.drivers || trip.passengers || 1,
            canReview: false,
            originalBooking: trip.originalBooking,
            isModification: true,
            timestamp: new Date().toISOString()
        };
        
        return modifyData;
    }

    formatDateForModification(dateString) {
        try {
            const date = new Date(dateString);
            return date.toISOString().split('T')[0]; // YYYY-MM-DD format
        } catch (e) {
            return new Date().toISOString().split('T')[0];
        }
    }

    getReturnDateForModification(trip) {
        try {
            if (trip.duration && trip.duration.includes(' to ')) {
                const parts = trip.duration.split(' to ');
                if (parts.length === 2) {
                    const returnDate = new Date(parts[1]);
                    if (!isNaN(returnDate.getTime())) {
                        return returnDate.toISOString().split('T')[0];
                    }
                }
            }
            
            // Default: 3 days from pickup
            const pickupDate = new Date(trip.date);
            const returnDate = new Date(pickupDate);
            returnDate.setDate(returnDate.getDate() + 3);
            return returnDate.toISOString().split('T')[0];
        } catch (e) {
            const today = new Date();
            const defaultReturn = new Date(today);
            defaultReturn.setDate(defaultReturn.getDate() + 3);
            return defaultReturn.toISOString().split('T')[0];
        }
    }

    getCustomerName() {
        const userData = localStorage.getItem('islandTimeUser');
        if (userData) {
            const user = JSON.parse(userData);
            return `${user.firstName || ''} ${user.lastName || ''}`.trim();
        }
        return '';
    }

    getCustomerEmail() {
        const userData = localStorage.getItem('islandTimeUser');
        if (userData) {
            const user = JSON.parse(userData);
            return user.email || '';
        }
        return '';
    }

    getCustomerPhone() {
        const userData = localStorage.getItem('islandTimeUser');
        if (userData) {
            const user = JSON.parse(userData);
            return user.phone || '';
        }
        return '';
    }

    // Save modification data and redirect
    saveAndRedirect(trip) {
        if (!trip) {
            alert('Trip not found');
            return;
        }

        // Prepare modification data
        const modifyData = this.prepareModificationData(trip);
        
        // Save to sessionStorage for immediate use
        sessionStorage.setItem('modifyBookingData', JSON.stringify(modifyData));
        
        // Also save to localStorage as backup
        localStorage.setItem('currentModification', JSON.stringify({
            id: trip.id,
            data: modifyData,
            timestamp: new Date().toISOString()
        }));
        
        // Mark this as active modification
        localStorage.setItem('activeModificationId', trip.id);
        
        // Get the correct path
        const carRentalPath = this.getCarRentalServicePath();
        
        console.log('Redirecting to:', carRentalPath);
        console.log('Modification data:', modifyData);
        
        // Show message
        this.showMessage('Preparing booking modification...', 'info');
        
        // Redirect after a short delay
        setTimeout(() => {
            window.location.href = `${carRentalPath}?modify=true&id=${trip.id}`;
        }, 500);
    }

    showMessage(message, type = 'info') {
        // Simple notification
        const colors = {
            success: 'green',
            error: 'red',
            info: 'blue'
        };
        
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 bg-${colors[type]}-100 border border-${colors[type]}-400 text-${colors[type]}-700 px-4 py-3 rounded-lg shadow-lg z-50`;
        notification.innerHTML = `
            <div class="flex items-center">
                <span class="material-symbols-outlined mr-2">${type === 'success' ? 'check_circle' : 'info'}</span>
                <span>${message}</span>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
}

// Create global instance
const bookingModifier = new BookingModifier();

// Global function for HTML onclick handlers
function modifyBooking(tripId) {
    // Get trip data from dashboard instance
    if (window.guestDashboard) {
        const trip = [...window.guestDashboard.upcomingTrips, ...window.guestDashboard.pastTrips]
            .find(t => t.id === tripId);
        
        if (trip) {
            bookingModifier.saveAndRedirect(trip);
        } else {
            alert('Trip not found');
        }
    } else {
        alert('Dashboard not loaded. Please refresh the page.');
    }
}