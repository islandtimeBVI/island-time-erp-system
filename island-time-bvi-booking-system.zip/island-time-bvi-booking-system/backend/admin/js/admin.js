class AdminApp {
    constructor() {
        this.token = localStorage.getItem('adminToken');
        this.user = JSON.parse(localStorage.getItem('adminUser') || '{}');
        this.currentSection = 'dashboard-overview';
        this.socket = null;
        this.isSocketConnected = false;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.checkAuthStatus();
        this.updateCurrentDate();
        this.setupNewsAutoRefresh();
    }

    setupEventListeners() {
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleLogin();
            });
        }

        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => {
                this.handleLogout();
            });
        }

        document.querySelectorAll('.sidebar a').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = e.target.getAttribute('data-section');
                this.showSection(section);
            });
        });

        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tab = e.target.getAttribute('data-tab');
                this.showTab(tab, e.target.closest('.help-tabs, .rates-tabs'));
            });
        });

        // Add water taxi tab listeners
        document.querySelectorAll('#water-taxi .tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const tabId = e.target.getAttribute('data-tab');
                this.showWaterTaxiTab(tabId, e.target);
            });
        });

        this.setupModalForms();
    }

    setupModalForms() {
        const accountForm = document.getElementById('account-settings-form');
        if (accountForm) {
            accountForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveSettings();
            });
        }

        const slowSeasonForm = document.getElementById('slow-season-form');
        if (slowSeasonForm) {
            slowSeasonForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveSlowSeasonSettings();
            });
        }

        const addUserForm = document.getElementById('add-user-form');
        if (addUserForm) {
            addUserForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addUser();
            });
        }

        const messageForm = document.getElementById('new-message-form');
        if (messageForm) {
            messageForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.sendMessage();
            });
        }

        const boatNameForm = document.getElementById('new-boat-name-form');
        if (boatNameForm) {
            boatNameForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addBoatName();
            });
        }

        const calendarForm = document.getElementById('new-calendar-event-form');
        if (calendarForm) {
            calendarForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addCalendarEvent();
            });
        }

        const todoForm = document.getElementById('new-todo-form');
        if (todoForm) {
            todoForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addTodo();
            });
        }

        const bookingForm = document.getElementById('new-booking-form');
        if (bookingForm) {
            bookingForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.createBooking();
            });
        }

        const newsForm = document.getElementById('add-news-form');
        if (newsForm) {
            newsForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addNews();
            });
        }

        // Water Taxi form setups
        const waterTaxiEditTemplateForm = document.getElementById('water-taxi-edit-template-form');
        if (waterTaxiEditTemplateForm) {
            waterTaxiEditTemplateForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveWaterTaxiTemplate();
            });
        }

        const waterTaxiAddRouteForm = document.getElementById('water-taxi-add-route-form');
        if (waterTaxiAddRouteForm) {
            waterTaxiAddRouteForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveWaterTaxiRoute();
            });
        }

        const authorizationForm = document.getElementById('send-authorization-form');
        if (authorizationForm) {
            authorizationForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.sendAuthorizationCard();
            });
        }
    }

    // ========== WATER TAXI MANAGEMENT METHODS ==========

    showWaterTaxiTab(tabId, button) {
        // Hide all water taxi tabs
        document.querySelectorAll('#water-taxi .tab-content').forEach(tab => {
            tab.classList.remove('active');
        });
        
        // Remove active class from all water taxi tab buttons
        document.querySelectorAll('#water-taxi .tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Show selected tab
        const targetTab = document.getElementById(tabId);
        if (targetTab) {
            targetTab.classList.add('active');
            button.classList.add('active');
            
            // Load tab-specific data
            switch(tabId) {
                case 'water-taxi-bookings-tab':
                    this.loadWaterTaxiBookings();
                    break;
                case 'water-taxi-templates-tab':
                    this.loadWaterTaxiTemplates();
                    break;
                case 'water-taxi-passports-tab':
                    this.loadPassports();
                    break;
                case 'water-taxi-authorization-tab':
                    this.loadAuthorizationTemplate();
                    break;
                case 'water-taxi-sailclear-tab':
                    this.loadSailClearData();
                    break;
                case 'water-taxi-routes-tab':
                    this.loadWaterTaxiRoutes();
                    break;
            }
        }
    }

    async loadWaterTaxiBookings() {
        try {
            const response = await this.apiCall('/api/admin/bookings');
            if (response && response.success) {
                const waterTaxiBookings = response.data.filter(booking => 
                    booking.serviceType === 'water-taxi' || 
                    booking.serviceType === 'Water Taxi' ||
                    (booking.serviceType && booking.serviceType.toLowerCase().includes('water'))
                );
                this.renderWaterTaxiBookings(waterTaxiBookings);
                
                // Update stats
                const today = new Date().toISOString().split('T')[0];
                const todayBookings = waterTaxiBookings.filter(booking => booking.date === today);
                const totalPassengers = todayBookings.reduce((sum, booking) => sum + (parseInt(booking.passengers) || 1), 0);
                const totalRevenue = todayBookings.reduce((sum, booking) => sum + (parseFloat(booking.estimatedPrice) || 0), 0);
                
                this.updateElementText('water-taxi-today', todayBookings.length);
                this.updateElementText('water-taxi-passengers', totalPassengers);
                this.updateElementText('water-taxi-revenue', `$${totalRevenue.toFixed(2)}`);
            }
        } catch (error) {
            console.error('Error loading water taxi bookings:', error);
            this.showNotification('Error loading water taxi bookings', 'error');
        }
    }

    renderWaterTaxiBookings(bookings) {
        const container = document.getElementById('water-taxi-bookings');
        if (!container) return;
        
        if (bookings.length === 0) {
            container.innerHTML = '<p class="text-gray-500">No water taxi bookings found</p>';
            return;
        }

        container.innerHTML = bookings.map(booking => `
            <div class="booking-item p-4 border-b border-gray-200 last:border-b-0 hover:bg-gray-50">
                <div class="flex justify-between items-start">
                    <div class="flex-1">
                        <div class="flex items-start justify-between">
                            <div>
                                <h4 class="font-semibold text-gray-800">${booking.customerName}</h4>
                                <p class="text-sm text-gray-600">${booking.customerEmail} • ${booking.customerPhone || 'No phone provided'}</p>
                            </div>
                            <span class="status-badge ${booking.status}">${booking.status}</span>
                        </div>
                        
                        <div class="mt-2 grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                            <div>
                                <span class="text-gray-500">Date:</span>
                                <p class="font-medium">${new Date(booking.date).toLocaleDateString()}</p>
                            </div>
                            <div>
                                <span class="text-gray-500">Passengers:</span>
                                <p class="font-medium">${booking.passengers || 'Not specified'}</p>
                            </div>
                            <div>
                                <span class="text-gray-500">Estimated Price:</span>
                                <p class="font-medium">$${parseFloat(booking.estimatedPrice || 0).toFixed(2)}</p>
                            </div>
                        </div>
                        
                        ${booking.fromLocation || booking.toLocation ? `
                            <div class="mt-2 text-sm">
                                <span class="text-gray-500">Route:</span>
                                <p class="font-medium">${booking.fromLocation || 'Not specified'} → ${booking.toLocation || 'Not specified'}</p>
                            </div>
                        ` : ''}
                        
                        ${booking.specialRequests ? `
                            <div class="mt-2">
                                <span class="text-gray-500 text-sm">Special Requests:</span>
                                <p class="text-sm mt-1">${booking.specialRequests}</p>
                            </div>
                        ` : ''}
                        
                        <div class="mt-3 flex gap-2">
                            <button onclick="adminApp.sendWaterTaxiResponse('${booking.id}', 'confirmation')" 
                                    class="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700 flex items-center">
                                <span class="material-symbols-outlined text-sm mr-1">mail</span>
                                Send Confirmation
                            </button>
                            <button onclick="adminApp.sendWaterTaxiResponse('${booking.id}', 'quote')" 
                                    class="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700 flex items-center">
                                <span class="material-symbols-outlined text-sm mr-1">mail</span>
                                Send Quote
                            </button>
                            <button onclick="adminApp.viewBookingDetails('${booking.id}')" 
                                    class="bg-gray-600 text-white px-3 py-1 rounded text-sm hover:bg-gray-700 flex items-center">
                                <span class="material-symbols-outlined text-sm mr-1">visibility</span>
                                View Details
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');
    }

    async loadWaterTaxiTemplates() {
        try {
            const response = await this.apiCall('/api/admin/water-taxi/templates');
            let templates;
            
            if (response && response.success) {
                templates = response.data;
            } else {
                templates = this.getDefaultWaterTaxiTemplates();
            }
            
            this.renderWaterTaxiTemplates(templates);
        } catch (error) {
            console.error('Error loading water taxi templates:', error);
            const defaultTemplates = this.getDefaultWaterTaxiTemplates();
            this.renderWaterTaxiTemplates(defaultTemplates);
        }
    }

    getDefaultWaterTaxiTemplates() {
        return {
            confirmation: {
                subject: "Water Taxi Booking Confirmation - Island Time BVI",
                body: `Dear {customer_name},

Thank you for booking your water taxi transfer with us. Please see your confirmation below.

<span style="color: #ff0000; font-weight: bold;">IT IS IMPORTANT that you take some time to read through this confirmation in its entirety. Important information about your trip is included. If you have any questions, please do let us know, we are here to help.</span>

Our Additional Services

A friendly reminder that we also offer powerboat & RIB rentals, skippered day charters, and car and Jeep rentals. Please let me know if I can assist with any of our additional services. 

! NEW REQUIREMENT ! – CUSTOMS & IMMIGRATION ONLINE PORTAL -

Travelers are required to complete the online Immigration and Customs Form which will be available 72 hours prior to your arrival in the BVI. Fill in the form at a time and place convenient for you. Once the form is completed, the Immigration and Customs receipts are to be saved to your mobile device or printed and presented to Immigration and Customs upon arrival.

You can access the portal here:
<a href="https://bviedcard.gov.vg/en">British Virgin Islands - Online Immigration & Customs Portal</a>

You will need the following information:

<span style="color: #ff0000; font-weight: bold;">VESSEL NAME: Island Time</span>
<span style="color: #ff0000; font-weight: bold;">REGISTRATION #: IT000</span>

Guest name:     
Number of guests:
Contact Number:  

<table border="1" cellpadding="6" cellspacing="0" style="width: 100%; border-collapse: collapse; margin: 15px 0; font-size: 12px;">
    <tr>
        <th style="text-align: left; background: #f0f0f0; padding: 8px;">Reservation Details</th>
        <th style="text-align: left; background: #f0f0f0; padding: 8px;">Return Trip (if booking a roundtrip)</th>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;">Date:</td>
        <td style="padding: 6px; border: 1px solid #ddd;">Date:</td>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;">Pickup Location:</td>
        <td style="padding: 6px; border: 1px solid #ddd;">Pickup Location:</td>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;">Pickup Time:</td>
        <td style="padding: 6px; border: 1px solid #ddd;">Pickup Time:</td>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;">Drop Off Location:</td>
        <td style="padding: 6px; border: 1px solid #ddd;">Drop Off Location:</td>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;">Flight Details:</td>
        <td style="padding: 6px; border: 1px solid #ddd;">Flight Details:</td>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;">Land Taxi On STT:</td>
        <td style="padding: 6px; border: 1px solid #ddd;">Land Taxi On STT:</td>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;">&nbsp;</td>
        <td style="padding: 6px; border: 1px solid #ddd;">&nbsp;</td>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;"><strong>FARE QUOTED:</strong></td>
        <td style="padding: 6px; border: 1px solid #ddd;">&nbsp;</td>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;">Water Taxi (Charged to Card):</td>
        <td style="padding: 6px; border: 1px solid #ddd;">&nbsp;</td>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;">Int'l Processing Fees (Charged to Card):</td>
        <td style="padding: 6px; border: 1px solid #ddd;">&nbsp;</td>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;">Land Taxi On STT (Paid In Cash):</td>
        <td style="padding: 6px; border: 1px solid #ddd;">&nbsp;</td>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;">&nbsp;</td>
        <td style="padding: 6px; border: 1px solid #ddd;">&nbsp;</td>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;"><strong>PAYMENT DETAILS:</strong></td>
        <td style="padding: 6px; border: 1px solid #ddd;">&nbsp;</td>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;">Payment Method:</td>
        <td style="padding: 6px; border: 1px solid #ddd;">&nbsp;</td>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;">Total Trip Cost:</td>
        <td style="padding: 6px; border: 1px solid #ddd;">&nbsp;</td>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;">&nbsp;</td>
        <td style="padding: 6px; border: 1px solid #ddd;">&nbsp;</td>
    </tr>
    <tr>
        <td style="padding: 6px; border: 1px solid #ddd;">&nbsp;</td>
        <td style="padding: 6px; border: 1px solid #ddd;">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="2" style="padding: 6px; border: 1px solid #ddd;">
            (Gratuities for your drivers and captains have not been included but are always appreciated and best paid in cash)
        </td>
    </tr>
</table>

Payment will be taken for your reservation 72 hours prior to arrival. If a roundtrip water taxi is booked, full payment will be taken. 
Land taxis can be charged to credit card, however a 15% admin fee will be charged. Departure delays will be charge at $50 per half hour or may result in your trip being cancelled or rescheduled.

Passport information
To expedite the customs and immigration process please provide us with a copy of the passport ID page for each person in your party no later than 72 hours prior to your trip.

Meeting the Land Taxi Service on St Thomas
If you have booked a land taxi from St Thomas Airport, please remember to switch your phone on once your flight lands so the driver can contact you. Taxi service on St Thomas is arranged as a courtesy and provided through a third party vendor. The drivers are not Island Time employees and we do not mark up land taxi rates, 100% of the land taxi rate goes to the drivers. Rates are set by the Virgin Islands Taxicab Commission. If you have not been contacted by your driver when you arrive in St Thomas, please call +1-340-474-1346 / +1-340-473-8644.

About our fleet
We operate a variety of boats from 28' to 39'. Most of the fleet are open powerboats with ample seating and storage for your luggage. We also operate a few fully enclosed boats. Boats are assigned based on group size, maintenance schedules and the demands of the day. We cannot guarantee that service will be provided on a particular boat unless you have made an upgrade request.

Trip Timings
On your inbound trip, we allow 1.5 - 2.5 hours from point of collection to your destination, with one stop for customs and immigration. On your return trip we allow for 4.5 – 5 hours from flight departure time to get you back to the airport including two stops for customs and immigration (BVI & USVI).

Water Taxi Cancellation Policy
If for some reason you must cancel your reservation with us, you will be charged as follows:
7 days or more – no charge 
3 - 7 days in advance - 50% of the cost of your reservation
Less than 72 hours in advance - 100% of the cost of your reservation
All cancellations must be done via email.

No Show Policy
If you do not show up for your reservation, you will be charged 100% of the cost of the reservation.

Best regards,
Island Time BVI Team`
            },
            quote: {
                subject: "Water Taxi Quote - Island Time BVI",
                body: `Dear {customer_name},

Thank you for your interest in our water taxi services!

Based on your inquiry, here is your quote:
• Passengers: {passengers}
• Route: {from_location} to {to_location}
• Estimated Price: {estimated_price}

This quote includes:
• Professional captain
• Safe and comfortable transportation
• All necessary safety equipment

To confirm your booking, please reply to this email or call us directly.

We look forward to serving you!

Best regards,
Island Time BVI Team`
            }
        };
    }

    renderWaterTaxiTemplates(templates) {
        const confirmationContainer = document.getElementById('water-taxi-confirmation-template');
        const quoteContainer = document.getElementById('water-taxi-quote-template');
        
        if (confirmationContainer && templates.confirmation) {
            const formattedBody = this.cleanTemplateSpacing(templates.confirmation.body);
            
            confirmationContainer.innerHTML = `
                <div class="template-content">
                    <h5 class="font-semibold mb-3">Subject: ${templates.confirmation.subject}</h5>
                    <div class="bg-white p-4 rounded border border-gray-200">
                        ${formattedBody}
                    </div>
                </div>
            `;
        }
        
        if (quoteContainer && templates.quote) {
            const formattedBody = this.cleanTemplateSpacing(templates.quote.body);
            
            quoteContainer.innerHTML = `
                <div class="template-content">
                    <h5 class="font-semibold mb-3">Subject: ${templates.quote.subject}</h5>
                    <div class="bg-white p-4 rounded border border-gray-200">
                        ${formattedBody}
                    </div>
                </div>
            `;
        }
    }

    cleanTemplateSpacing(content) {
        if (!content) return '';
        
        const lines = content.split('\n');
        let result = '';
        let inTable = false;
        
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            const originalLine = lines[i];
            
            if (originalLine.includes('<table')) {
                inTable = true;
                result += originalLine + '\n';
                continue;
            }
            
            if (originalLine.includes('</table>')) {
                inTable = false;
                result += originalLine + '\n';
                continue;
            }
            
            if (inTable) {
                result += originalLine + '\n';
            } else {
                if (line === '') {
                    if (!result.endsWith('<br><br>')) {
                        result += '<br>';
                    }
                } else {
                    result += line + '<br>';
                }
            }
        }
        
        return result;
    }

    async loadWaterTaxiRoutes() {
        try {
            const response = await this.apiCall('/api/admin/rates');
            if (response && response.success) {
                this.renderWaterTaxiRoutes(response.data);
            }
        } catch (error) {
            console.error('Error loading water taxi routes:', error);
        }
    }

    renderWaterTaxiRoutes(ratesData) {
        const container = document.getElementById('water-taxi-routes');
        if (!container || !ratesData.waterTaxi) return;
        
        const waterTaxi = ratesData.waterTaxi;
        
        container.innerHTML = `
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="bg-gray-50 p-4 rounded-lg">
                    <h4 class="font-semibold text-gray-800 mb-3">Pricing Structure</h4>
                    <div class="space-y-2">
                        <div class="flex justify-between">
                            <span>Base Rate:</span>
                            <span class="font-semibold">$${waterTaxi.baseRate}</span>
                        </div>
                        <div class="flex justify-between">
                            <span>Per Person:</span>
                            <span class="font-semibold">$${waterTaxi.perPerson}</span>
                        </div>
                        <div class="flex justify-between">
                            <span>Minimum Passengers:</span>
                            <span class="font-semibold">${waterTaxi.minimumPassengers}</span>
                        </div>
                    </div>
                </div>
                
                <div class="bg-gray-50 p-4 rounded-lg">
                    <h4 class="font-semibold text-gray-800 mb-3">Popular Routes</h4>
                    <div class="space-y-3">
                        ${waterTaxi.routes ? waterTaxi.routes.map(route => `
                            <div class="border-b border-gray-200 pb-2 last:border-b-0">
                                <div class="flex justify-between items-center">
                                    <div>
                                        <p class="font-medium">${route.from} → ${route.to}</p>
                                        <p class="text-sm text-gray-600">Duration: ${route.duration} mins</p>
                                    </div>
                                    <span class="font-semibold text-green-600">$${route.price}</span>
                                </div>
                            </div>
                        `).join('') : '<p class="text-gray-500">No routes configured</p>'}
                    </div>
                </div>
            </div>
        `;
    }

    async saveWaterTaxiTemplate() {
        try {
            const templateType = document.getElementById('template-type').value;
            const subject = document.getElementById('template-subject').value;
            const body = document.getElementById('template-body').value;
            
            const response = await this.apiCall('/api/admin/water-taxi/templates', 'PUT', {
                templates: {
                    [templateType]: { subject, body }
                }
            });
            
            if (response && response.success) {
                this.showNotification('Water Taxi template saved successfully!', 'success');
                this.closeModal('water-taxi-edit-template-modal');
                await this.loadWaterTaxiTemplates();
            } else {
                this.showNotification('Error saving template: ' + (response?.message || 'Unknown error'), 'error');
            }
        } catch (error) {
            console.error('Error saving water taxi template:', error);
            this.showNotification('Error saving template', 'error');
        }
    }

    async saveWaterTaxiRoute() {
        try {
            const formData = {
                from: document.getElementById('route-from').value,
                to: document.getElementById('route-to').value,
                price: parseFloat(document.getElementById('route-price').value),
                duration: parseInt(document.getElementById('route-duration').value)
            };
            
            const response = await this.apiCall('/api/admin/rates');
            if (response && response.success) {
                this.showNotification('Water Taxi route added successfully!', 'success');
                this.closeModal('water-taxi-add-route-modal');
                await this.loadWaterTaxiRoutes();
            }
        } catch (error) {
            console.error('Error saving water taxi route:', error);
            this.showNotification('Error saving route', 'error');
        }
    }

    useTemplate(templateType) {
        this.showNotification(`Opening ${templateType} template for use...`, 'info');
        setTimeout(() => {
            this.showNotification(`Ready to use ${templateType} template! Copy the template content and paste into your email client.`, 'success');
        }, 1000);
    }

    async sendWaterTaxiResponse(bookingId, templateType) {
        try {
            const bookingsResponse = await this.apiCall('/api/admin/bookings');
            if (bookingsResponse && bookingsResponse.success) {
                const booking = bookingsResponse.data.find(b => b.id === bookingId);
                if (booking) {
                    const templatesResponse = await this.apiCall('/api/admin/water-taxi/templates');
                    let templates;
                    
                    if (templatesResponse && templatesResponse.success) {
                        templates = templatesResponse.data;
                    } else {
                        templates = this.getDefaultWaterTaxiTemplates();
                    }
                    
                    const template = templates[templateType];
                    if (template) {
                        const subject = this.replaceTemplateVariables(template.subject, booking);
                        const body = this.replaceTemplateVariables(template.body, booking);
                        
                        this.openEmailClient(booking.customerEmail, subject, body);
                    }
                }
            }
        } catch (error) {
            console.error('Error sending water taxi response:', error);
            this.showNotification('Error preparing email response', 'error');
        }
    }

    replaceTemplateVariables(text, booking) {
        return text
            .replace(/{customer_name}/g, booking.customerName)
            .replace(/{booking_date}/g, new Date(booking.date).toLocaleDateString())
            .replace(/{passengers}/g, booking.passengers || 'Not specified')
            .replace(/{from_location}/g, booking.fromLocation || 'Not specified')
            .replace(/{to_location}/g, booking.toLocation || 'Not specified')
            .replace(/{estimated_price}/g, `$${parseFloat(booking.estimatedPrice || 0).toFixed(2)}`)
            .replace(/{customer_email}/g, booking.customerEmail)
            .replace(/{customer_phone}/g, booking.customerPhone || 'Not provided');
    }

    openEmailClient(to, subject, body) {
        const mailtoLink = `mailto:${to}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        window.open(mailtoLink, '_blank');
    }

    refreshWaterTaxiBookings() {
        this.loadWaterTaxiBookings();
        this.showNotification('Water taxi bookings refreshed', 'success');
    }

    viewBookingDetails(bookingId) {
        this.showNotification(`Viewing details for booking ${bookingId}`, 'info');
    }

    editWaterTaxiTemplate() {
        this.showNotification('Template editor coming soon!', 'info');
    }

    async loadWaterTaxiData() {
        const firstTab = document.querySelector('#water-taxi .tab-btn');
        if (firstTab) {
            const tabId = firstTab.getAttribute('data-tab');
            this.showWaterTaxiTab(tabId, firstTab);
        }
    }

    // ========== PASSPORT MANAGEMENT METHODS ==========

    async loadPassports() {
        try {
            const response = await this.apiCall('/api/admin/passports');
            if (response && response.success) {
                this.renderPassports(response.data);
                this.updatePassportStats(response.data);
            } else {
                console.error('Failed to load passports:', response?.message);
            }
        } catch (error) {
            console.error('Error loading passports:', error);
            this.showNotification('Error loading passports', 'error');
        }
    }

    renderPassports(passports) {
        const container = document.getElementById('water-taxi-passports-list');
        if (!container) return;
        
        if (passports.length === 0) {
            container.innerHTML = '<p class="text-gray-500">No passports uploaded yet</p>';
            return;
        }

        container.innerHTML = passports.map(passport => `
            <div class="passport-item border border-gray-200 rounded-lg p-4 mb-4 bg-white">
                <div class="flex justify-between items-start mb-3">
                    <div>
                        <h4 class="font-semibold text-lg">${passport.fullName}</h4>
                        <p class="text-gray-600">Passport: ${passport.passportNumber} • ${passport.nationality}</p>
                    </div>
                    <span class="status-badge ${passport.status}">${passport.status}</span>
                </div>
                
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                    <div>
                        <span class="text-gray-500 text-sm">Date of Birth:</span>
                        <p class="font-medium text-sm">${new Date(passport.dateOfBirth).toLocaleDateString()}</p>
                    </div>
                    <div>
                        <span class="text-gray-500 text-sm">Expiry Date:</span>
                        <p class="font-medium text-sm ${this.isPassportExpired(passport.expiryDate) ? 'text-red-600' : ''}">
                            ${new Date(passport.expiryDate).toLocaleDateString()}
                        </p>
                    </div>
                    <div>
                        <span class="text-gray-500 text-sm">Uploaded:</span>
                        <p class="font-medium text-sm">${new Date(passport.uploadedAt).toLocaleDateString()}</p>
                    </div>
                    <div>
                        <span class="text-gray-500 text-sm">Booking Ref:</span>
                        <p class="font-medium text-sm">${passport.bookingReference || 'N/A'}</p>
                    </div>
                </div>
                
                <div class="flex gap-2">
                    <button onclick="adminApp.viewPassport('${passport.id}')" 
                            class="bg-blue-500 text-white py-2 px-3 rounded text-sm hover:bg-blue-600 flex items-center">
                        <span class="material-symbols-outlined text-sm mr-1">visibility</span>
                        View
                    </button>
                    <button onclick="adminApp.downloadPassport('${passport.id}')" 
                            class="bg-green-500 text-white py-2 px-3 rounded text-sm hover:bg-green-600 flex items-center">
                        <span class="material-symbols-outlined text-sm mr-1">download</span>
                        Download
                    </button>
                    <button onclick="adminApp.verifyPassport('${passport.id}')" 
                            class="bg-purple-500 text-white py-2 px-3 rounded text-sm hover:bg-purple-600 flex items-center">
                        <span class="material-symbols-outlined text-sm mr-1">verified</span>
                        Verify
                    </button>
                </div>
            </div>
        `).join('');
    }

    updatePassportStats(passports) {
        const total = passports.length;
        const verified = passports.filter(p => p.status === 'verified').length;
        const pending = passports.filter(p => p.status === 'pending').length;
        const invalid = passports.filter(p => this.isPassportExpired(p.expiryDate) || p.status === 'invalid').length;

        this.updateElementText('total-passports', total);
        this.updateElementText('verified-passports', verified);
        this.updateElementText('pending-passports', pending);
        this.updateElementText('invalid-passports', invalid);
    }

    isPassportExpired(expiryDate) {
        return new Date(expiryDate) < new Date();
    }

    async downloadPassport(passportId) {
        try {
            const response = await fetch(`/api/admin/passports/${passportId}/download`, {
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `passport-${passportId}.pdf`;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
            } else {
                this.showNotification('Error downloading passport', 'error');
            }
        } catch (error) {
            console.error('Error downloading passport:', error);
            this.showNotification('Error downloading passport', 'error');
        }
    }

    async verifyPassport(passportId) {
        try {
            const response = await this.apiCall(`/api/admin/passports/${passportId}/verify`, 'PUT');
            if (response && response.success) {
                this.showNotification('Passport verified successfully', 'success');
                await this.loadPassports();
            } else {
                this.showNotification('Error verifying passport', 'error');
            }
        } catch (error) {
            console.error('Error verifying passport:', error);
            this.showNotification('Error verifying passport', 'error');
        }
    }

    async downloadAllPassports() {
        try {
            const response = await fetch('/api/admin/passports/download-all', {
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `all-passports-${new Date().toISOString().split('T')[0]}.zip`;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
            } else {
                this.showNotification('Error downloading passports', 'error');
            }
        } catch (error) {
            console.error('Error downloading passports:', error);
            this.showNotification('Error downloading passports', 'error');
        }
    }

    async exportPassportData() {
        try {
            const response = await this.apiCall('/api/admin/passports/export');
            if (response && response.success) {
                const csv = this.convertToCSV(response.data);
                const blob = new Blob([csv], { type: 'text/csv' });
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `passport-data-${new Date().toISOString().split('T')[0]}.csv`;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
                
                this.showNotification('Passport data exported successfully', 'success');
            }
        } catch (error) {
            console.error('Error exporting passport data:', error);
            this.showNotification('Error exporting passport data', 'error');
        }
    }

    convertToCSV(data) {
        const headers = ['Full Name', 'Passport Number', 'Nationality', 'Date of Birth', 'Expiry Date', 'Status', 'Booking Reference'];
        const csv = [headers.join(',')];
        
        data.forEach(item => {
            const row = [
                `"${item.fullName}"`,
                item.passportNumber,
                item.nationality,
                new Date(item.dateOfBirth).toISOString().split('T')[0],
                new Date(item.expiryDate).toISOString().split('T')[0],
                item.status,
                item.bookingReference || ''
            ];
            csv.push(row.join(','));
        });
        
        return csv.join('\n');
    }

    async filterPassports() {
        const filter = document.getElementById('passport-filter').value;
        this.showNotification(`Filtering passports: ${filter}`, 'info');
    }

    async refreshPassports() {
        await this.loadPassports();
        this.showNotification('Passports refreshed', 'success');
    }

    viewPassport(passportId) {
        this.showNotification(`Viewing passport ${passportId} - Feature coming soon`, 'info');
    }

    // ========== AUTHORIZATION CARD EMAIL METHODS ==========

    async loadAuthorizationTemplate() {
        try {
            const response = await this.apiCall('/api/admin/water-taxi/templates/authorization');
            let template;
            
            if (response && response.success) {
                template = response.data;
            } else {
                template = this.getDefaultAuthorizationTemplate();
            }
            
            this.renderAuthorizationTemplate(template);
        } catch (error) {
            console.error('Error loading authorization template:', error);
            const defaultTemplate = this.getDefaultAuthorizationTemplate();
            this.renderAuthorizationTemplate(defaultTemplate);
        }
    }

    getDefaultAuthorizationTemplate() {
        return {
            subject: "Customs & Immigration Authorization Card - Island Time BVI",
            body: `Dear {customer_name},

IMPORTANT: AUTHORIZATION CARD REQUIREMENTS

Please find below your authorization card information for customs and immigration purposes. This card must be presented upon arrival.

AUTHORIZATION CARD DETAILS:
• Vessel Name: Island Time
• Registration #: IT000
• Captain: {captain_name}
• Date of Arrival: {arrival_date}
• Number of Passengers: {passenger_count}

REQUIRED DOCUMENTS:
1. Valid Passport (for all passengers)
2. Completed Immigration Form
3. Return Ticket (if applicable)
4. This Authorization Card

Please ensure all passengers have their passports ready for inspection. The captain will assist with the customs and immigration process upon arrival.

If you have any questions, please contact us at +1-284-499-4755.

Safe travels,

Island Time BVI Team`
        };
    }

    renderAuthorizationTemplate(template) {
        const container = document.getElementById('authorization-card-template');
        if (!container || !template) return;
        
        container.innerHTML = `
            <div class="template-content">
                <h5 class="font-semibold mb-3">Subject: ${template.subject}</h5>
                <div class="bg-white p-4 rounded border border-gray-200">
                    ${template.body.replace(/\n/g, '<br>')}
                </div>
            </div>
        `;
    }

    async sendAuthorizationCard() {
        try {
            const customerEmail = document.getElementById('auth-customer-email').value;
            const customerName = document.getElementById('auth-customer-name').value;
            const captainName = document.getElementById('auth-captain-name').value;
            const arrivalDate = document.getElementById('auth-arrival-date').value;
            const passengerCount = document.getElementById('auth-passenger-count').value;
            
            const response = await this.apiCall('/api/admin/water-taxi/send-authorization', 'POST', {
                customerEmail,
                customerName,
                captainName,
                arrivalDate,
                passengerCount
            });
            
            if (response && response.success) {
                this.showNotification('Authorization card sent successfully!', 'success');
                this.closeModal('send-authorization-modal');
            } else {
                this.showNotification('Error sending authorization card: ' + (response?.message || 'Unknown error'), 'error');
            }
        } catch (error) {
            console.error('Error sending authorization card:', error);
            this.showNotification('Error sending authorization card', 'error');
        }
    }

    editAuthorizationTemplate() {
        this.showNotification('Authorization template editor coming soon!', 'info');
    }

    useAuthorizationTemplate() {
        this.showNotification('Opening authorization card template for use...', 'info');
        setTimeout(() => {
            this.showNotification('Ready to use authorization card template! Copy the template content and paste into your email client.', 'success');
        }, 1000);
    }

    // ========== SAILCLEAR INTEGRATION METHODS ==========

    async loadSailClearData() {
        try {
            const [statusResponse, submissionsResponse] = await Promise.all([
                this.apiCall('/api/admin/sailclear/status'),
                this.apiCall('/api/admin/sailclear/submissions')
            ]);

            if (statusResponse && statusResponse.success) {
                this.updateSailClearStatus(statusResponse.data);
            }

            if (submissionsResponse && submissionsResponse.success) {
                this.renderSailClearSubmissions(submissionsResponse.data);
            }
        } catch (error) {
            console.error('Error loading SailClear data:', error);
        }
    }

    updateSailClearStatus(status) {
        const statusElement = document.getElementById('sailclear-status');
        const statusText = document.getElementById('sailclear-status-text');
        const lastSync = document.getElementById('last-sync-time');

        if (statusElement && statusText && lastSync) {
            if (status.connected) {
                statusElement.className = 'w-3 h-3 rounded-full bg-green-500 mr-3';
                statusText.textContent = 'Connected';
            } else {
                statusElement.className = 'w-3 h-3 rounded-full bg-red-500 mr-3';
                statusText.textContent = 'Disconnected';
            }

            lastSync.textContent = status.lastSync ? new Date(status.lastSync).toLocaleString() : 'Never';
        }
    }

    renderSailClearSubmissions(submissions) {
        const container = document.getElementById('sailclear-submissions');
        if (!container) return;

        if (submissions.length === 0) {
            container.innerHTML = '<p class="text-gray-500">No submissions yet</p>';
            return;
        }

        container.innerHTML = submissions.map(submission => `
            <div class="submission-item border border-gray-200 rounded-lg p-3 mb-2 bg-white">
                <div class="flex justify-between items-start">
                    <div>
                        <h4 class="font-semibold text-sm">${submission.reference}</h4>
                        <p class="text-xs text-gray-600">Vessel: ${submission.vesselName} • Passengers: ${submission.passengerCount}</p>
                        <p class="text-xs text-gray-500">Submitted: ${new Date(submission.submittedAt).toLocaleString()}</p>
                    </div>
                    <span class="status-badge ${submission.status}">${submission.status}</span>
                </div>
                ${submission.notes ? `<p class="text-xs text-gray-600 mt-1">${submission.notes}</p>` : ''}
            </div>
        `).join('');
    }

    async testSailClearConnection() {
        try {
            const apiKey = document.getElementById('sailclear-api-key').value;
            const response = await this.apiCall('/api/admin/sailclear/test-connection', 'POST', { apiKey });
            
            if (response && response.success) {
                this.showNotification('SailClear connection test successful', 'success');
                this.updateSailClearStatus(response.data);
            } else {
                this.showNotification('SailClear connection test failed: ' + (response?.message || 'Unknown error'), 'error');
            }
        } catch (error) {
            console.error('Error testing SailClear connection:', error);
            this.showNotification('Error testing SailClear connection', 'error');
        }
    }

    async syncSailClearData() {
        try {
            const response = await this.apiCall('/api/admin/sailclear/sync', 'POST');
            if (response && response.success) {
                this.showNotification('SailClear data synchronized successfully', 'success');
                await this.loadSailClearData();
            } else {
                this.showNotification('SailClear synchronization failed', 'error');
            }
        } catch (error) {
            console.error('Error syncing SailClear data:', error);
            this.showNotification('Error syncing SailClear data', 'error');
        }
    }

    manageSailClearPassengers() {
        this.showNotification('Passenger management feature coming soon', 'info');
    }

    manageCrewLists() {
        this.showNotification('Crew list management feature coming soon', 'info');
    }

    // ========== MODAL SHOW METHODS ==========

    showEditTemplateModal(templateType) {
        this.showModal('water-taxi-edit-template-modal');
    }

    showAddRouteModal() {
        this.showModal('water-taxi-add-route-modal');
    }

    showSendAuthorizationModal() {
        this.showModal('send-authorization-modal');
    }

    // ========== EXISTING METHODS (REST OF THE CODE) ==========

    initSocket() {
        if (this.token) {
            try {
                this.socket = io('http://localhost:3001', {
                    auth: {
                        token: this.token
                    },
                    transports: ['websocket', 'polling']
                });

                this.socket.on('connect', () => {
                    console.log('🔌 Connected to real-time news feed');
                    this.isSocketConnected = true;
                    this.updateSocketStatus('connected', 'Connected to real-time news feed');
                    
                    if (this.user.id) {
                        this.socket.emit('join_news_feed', this.user.id);
                    }
                    
                    this.simulateRealTimeNews();
                });

                this.socket.on('news_update', (data) => {
                    console.log('📢 Received real-time news update:', data);
                    this.handleNewsUpdate(data);
                });

                this.socket.on('news_feed', (data) => {
                    console.log('📢 Received full news feed:', data.news.length, 'articles');
                    this.handleNewsFeed(data);
                });

                this.socket.on('disconnect', () => {
                    console.log('🔌 Disconnected from real-time news feed');
                    this.isSocketConnected = false;
                    this.updateSocketStatus('disconnected', 'Disconnected from real-time news feed');
                });

                this.socket.on('connect_error', (error) => {
                    console.error('🔌 Socket connection error:', error);
                    this.updateSocketStatus('disconnected', 'Connection failed');
                });

            } catch (error) {
                console.error('Socket initialization error:', error);
            }
        }
    }

    updateSocketStatus(status, message) {
        const socketStatus = document.getElementById('socket-status');
        const socketStatusText = document.getElementById('socket-status-text');
        const newsManagementStatus = document.getElementById('news-management-status');
        const newsFeedIndicator = document.getElementById('news-feed-indicator');

        if (socketStatus && socketStatusText) {
            socketStatus.className = `socket-status ${status}`;
            socketStatusText.textContent = message;
            socketStatus.classList.remove('hidden');
        }

        if (newsManagementStatus) {
            newsManagementStatus.className = `socket-status ${status}`;
            newsManagementStatus.innerHTML = `<i class="fas fa-plug"></i><span>Real-time: ${status.charAt(0).toUpperCase() + status.slice(1)}</span>`;
        }

        if (newsFeedIndicator) {
            if (status === 'connected') {
                newsFeedIndicator.classList.remove('hidden');
            } else {
                newsFeedIndicator.classList.add('hidden');
            }
        }
    }

    handleNewsUpdate(data) {
        const { action, news, message, timestamp } = data;
        
        let notificationMessage = '';
        let notificationType = 'info';
        
        switch (action) {
            case 'added':
                notificationMessage = `📰 New article: ${news.title}`;
                notificationType = 'success';
                break;
            case 'updated':
                notificationMessage = `✏️ Updated: ${news.title}`;
                notificationType = 'info';
                break;
            case 'deleted':
                notificationMessage = `🗑️ Deleted: ${news.title}`;
                notificationType = 'warning';
                break;
            case 'connected':
                notificationMessage = message || 'Connected to real-time news feed';
                notificationType = 'success';
                break;
            default:
                notificationMessage = message || 'News feed updated';
        }
        
        this.showNotification(notificationMessage, notificationType);
        
        if (this.currentSection === 'dashboard-overview') {
            this.loadNews();
        }
        
        if (this.currentSection === 'news-management') {
            this.loadNewsManagement();
        }
    }

    handleNewsFeed(data) {
        if (data && data.news) {
            if (this.currentSection === 'dashboard-overview') {
                this.renderNews(data.news);
            }
            
            if (this.currentSection === 'news-management') {
                this.renderNewsManagement(data.news);
            }
        }
    }

    checkAuthStatus() {
        if (this.token && this.user.email) {
            this.showDashboard();
            this.loadDashboardData();
            this.initSocket();
        } else {
            this.showLogin();
        }
    }

    async handleLogin() {
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const errorDiv = document.getElementById('login-error');

        try {
            const response = await fetch('/api/admin/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (data.success) {
                this.token = data.data.token;
                this.user = data.data.user;
                
                localStorage.setItem('adminToken', this.token);
                localStorage.setItem('adminUser', JSON.stringify(this.user));
                
                this.showDashboard();
                this.loadDashboardData();
                this.initSocket();
                this.hideError(errorDiv);
                this.showNotification('Login successful!', 'success');
            } else {
                this.showError(errorDiv, data.message || 'Login failed');
            }
        } catch (error) {
            console.error('Login error:', error);
            this.showError(errorDiv, 'Network error. Please try again.');
        }
    }

    handleLogout() {
        if (this.socket) {
            this.socket.disconnect();
        }
        localStorage.removeItem('adminToken');
        localStorage.removeItem('adminUser');
        this.token = null;
        this.user = {};
        this.showLogin();
    }

    showLogin() {
        document.getElementById('login-screen').classList.remove('hidden');
        document.getElementById('dashboard').classList.add('hidden');
    }

    showDashboard() {
        document.getElementById('login-screen').classList.add('hidden');
        document.getElementById('dashboard').classList.remove('hidden');
        const usernameElement = document.getElementById('username');
        if (usernameElement) {
            usernameElement.textContent = this.user.name;
        }
        const userAvatar = document.getElementById('user-avatar');
        if (userAvatar) {
            userAvatar.textContent = this.user.name ? this.user.name.charAt(0).toUpperCase() : 'U';
        }
    }

    showSection(sectionId) {
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.remove('active');
        });

        document.querySelectorAll('.sidebar a').forEach(link => {
            link.classList.remove('nav-active');
        });

        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');
            
            const activeLink = document.querySelector(`[data-section="${sectionId}"]`);
            if (activeLink) {
                activeLink.classList.add('nav-active');
            }

            this.loadSectionData(sectionId);
        }

        this.currentSection = sectionId;
    }

    showTab(tabId, container) {
        container.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });

        container.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });

        const targetTab = container.querySelector(`#${tabId}`);
        if (targetTab) {
            targetTab.classList.add('active');
            
            const activeBtn = container.querySelector(`[data-tab="${tabId}"]`);
            if (activeBtn) {
                activeBtn.classList.add('active');
            }

            this.loadTabData(tabId);
        }
    }

    async loadDashboardData() {
        await this.loadDashboardStats();
        await this.loadCarFleet();
        await this.loadBoatFleet();
        await this.loadUserTodos();
        await this.loadNews();
    }

    async loadDashboardStats() {
        try {
            const response = await this.apiCall('/api/admin/dashboard-stats');
            if (response && response.success) {
                const stats = response.data;
                this.updateElementText('today-bookings', stats.todayBookings);
                this.updateElementText('active-boats', stats.activeBoats);
                this.updateElementText('revenue-today', `$${stats.revenueToday}`);
                this.updateElementText('pending-actions', stats.pendingActions);
            } else {
                console.error('Failed to load dashboard stats:', response?.message);
            }
        } catch (error) {
            console.error('Error loading dashboard stats:', error);
            this.showNotification('Error loading dashboard statistics', 'error');
        }
    }

    async loadCarFleet() {
        try {
            const response = await this.apiCall('/api/admin/car-fleet');
            if (response && response.success) {
                this.renderCarFleet(response.data);
                this.renderCarFleetList(response.data);
            } else {
                console.error('Failed to load car fleet:', response?.message);
            }
        } catch (error) {
            console.error('Error loading car fleet:', error);
        }
    }

    async loadBoatFleet() {
        try {
            const response = await this.apiCall('/api/admin/boat-fleet');
            if (response && response.success) {
                this.renderBoatFleet(response.data);
                this.renderBoatFleetList(response.data);
            } else {
                console.error('Failed to load boat fleet:', response?.message);
            }
        } catch (error) {
            console.error('Error loading boat fleet:', error);
        }
    }

    async loadUserTodos() {
        try {
            const response = await this.apiCall('/api/admin/todos');
            if (response && response.success) {
                this.renderTodos(response.data, 'user-todos');
            } else {
                console.error('Failed to load todos:', response?.message);
            }
        } catch (error) {
            console.error('Error loading todos:', error);
        }
    }

    async loadNews() {
        try {
            const response = await this.apiCall('/api/admin/news');
            if (response && response.success) {
                this.renderNews(response.data);
            } else {
                console.error('Failed to load news:', response?.message);
                this.showFallbackNews();
            }
        } catch (error) {
            console.error('Error loading news:', error);
            this.showFallbackNews();
        }
    }

    renderCarFleet(cars) {
        const container = document.getElementById('car-fleet-status');
        if (!container) return;

        const available = cars.filter(car => car.status === 'available').length;
        const total = cars.length;

        container.innerHTML = `
            <div class="fleet-summary">
                <div class="fleet-stat">
                    <span class="stat-value">${available}/${total}</span>
                    <span class="stat-label">Available</span>
                </div>
                <div class="fleet-details">
                    ${cars.map(car => `
                        <div class="fleet-item ${car.status}">
                            <strong>${car.name}</strong>
                            <span class="status-badge ${car.status}">${car.status}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    renderBoatFleet(boats) {
        const container = document.getElementById('boats-available');
        if (!container) return;

        const available = boats.filter(boat => boat.status === 'available').length;
        const total = boats.length;

        container.innerHTML = `
            <div class="fleet-summary">
                <div class="fleet-stat">
                    <span class="stat-value">${available}/${total}</span>
                    <span class="stat-label">Available</span>
                </div>
                <div class="fleet-details">
                    ${boats.map(boat => `
                        <div class="fleet-item ${boat.status}">
                            <strong>${boat.name}</strong>
                            <span class="status-badge ${boat.status}">${boat.status}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    renderCarFleetList(cars) {
        const container = document.getElementById('car-fleet-list');
        if (!container) return;
        
        if (cars.length === 0) {
            container.innerHTML = '<p class="no-data">No cars in fleet</p>';
            return;
        }

        container.innerHTML = cars.map(car => `
            <div class="fleet-item">
                <div>
                    <strong>${car.name}</strong>
                    <div class="text-sm text-gray-500">${car.type}</div>
                </div>
                <span class="status-badge ${car.status}">${car.status}</span>
            </div>
        `).join('');
    }

    renderBoatFleetList(boats) {
        const container = document.getElementById('boat-fleet-list');
        if (!container) return;
        
        if (boats.length === 0) {
            container.innerHTML = '<p class="no-data">No boats in fleet</p>';
            return;
        }

        container.innerHTML = boats.map(boat => `
            <div class="fleet-item">
                <div>
                    <strong>${boat.name}</strong>
                    <div class="text-sm text-gray-500">${boat.type}</div>
                </div>
                <span class="status-badge ${boat.status}">${boat.status}</span>
            </div>
        `).join('');
    }

    renderTodos(todos, containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        if (todos.length === 0) {
            container.innerHTML = '<p class="no-data">No todos found</p>';
            return;
        }

        container.innerHTML = todos.map(todo => `
            <div class="todo-item ${todo.completed ? 'completed' : ''}">
                <label class="todo-checkbox">
                    <input type="checkbox" ${todo.completed ? 'checked' : ''} 
                           onchange="adminApp.toggleTodo('${todo.id}', this.checked)">
                    <span class="checkmark"></span>
                </label>
                <div class="todo-content">
                    <div class="todo-task">${todo.task}</div>
                    ${todo.dueDate ? `<div class="todo-due">Due: ${new Date(todo.dueDate).toLocaleDateString()}</div>` : ''}
                </div>
            </div>
        `).join('');
    }

    renderNews(news) {
        const container = document.getElementById('newsroom-feed');
        if (!container) return;
        
        const sortedNews = news.sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5);
        
        container.innerHTML = sortedNews.map(item => `
            <div class="news-item ${this.isRecentNews(item) ? 'new' : ''}">
                <h4 class="font-semibold text-gray-800">${item.title}</h4>
                <p class="text-sm text-gray-600 mt-1">${item.summary}</p>
                <div class="news-meta flex justify-between items-center mt-2">
                    <span class="text-xs text-gray-500">${item.source}</span>
                    <span class="text-xs text-gray-500">${new Date(item.date).toLocaleDateString()}</span>
                    ${this.isSocketConnected ? '<span class="real-time-indicator">LIVE</span>' : ''}
                </div>
                ${item.url ? `<a href="${item.url}" target="_blank" class="text-xs brand-text mt-1 inline-block">Read more</a>` : ''}
            </div>
        `).join('');
    }

    isRecentNews(newsItem) {
        const newsDate = new Date(newsItem.date);
        const now = new Date();
        const hoursDiff = (now - newsDate) / (1000 * 60 * 60);
        return hoursDiff < 24 && this.isSocketConnected;
    }

    showFallbackNews() {
        const fallbackNews = [
            {
                id: '1',
                title: 'Welcome to Island Time BVI Admin',
                summary: 'This is your admin dashboard. Real-time news will appear here when connected.',
                source: 'System',
                date: new Date().toISOString()
            }
        ];
        
        const newsContainer = document.getElementById('newsroom-feed');
        const managementContainer = document.getElementById('news-management-list');
        
        if (newsContainer) {
            this.renderNews(fallbackNews);
        }
        
        if (managementContainer && this.currentSection === 'news-management') {
            this.renderNewsManagement(fallbackNews);
        }
    }

    async toggleTodo(todoId, completed) {
        try {
            const response = await this.apiCall(`/api/admin/todos/${todoId}`, 'PUT', { completed });
            if (response && response.success) {
                await this.loadUserTodos();
                if (this.currentSection === 'todos') {
                    await this.loadTodos();
                }
            } else {
                console.error('Failed to update todo:', response?.message);
            }
        } catch (error) {
            console.error('Error updating todo:', error);
            this.showNotification('Error updating todo', 'error');
        }
    }

    async loadSectionData(sectionId) {
        switch (sectionId) {
            case 'todos':
                await this.loadTodos();
                break;
            case 'boat-names':
                await this.loadBoatNames();
                break;
            case 'calendar':
                await this.loadCalendarEvents();
                break;
            case 'messaging':
                await this.loadMessages();
                break;
            case 'users':
                await this.loadUsers();
                break;
            case 'news-management':
                await this.loadNewsManagement();
                break;
            case 'settings':
                await this.loadSettings();
                break;
            case 'slow-season':
                await this.loadSlowSeasonSettings();
                break;
            case 'bookings':
                await this.loadBookings();
                break;
            case 'crm':
                await this.loadCRM();
                break;
            case 'newsletters':
                await this.loadNewsletters();
                break;
            case 'faqs':
                await this.loadFAQs();
                break;
            case 'tickets':
                await this.loadTickets();
                break;
            case 'rates':
                await this.loadRates();
                break;
            case 'files':
                await this.loadFiles();
                break;
            case 'quickbooks':
                await this.loadQuickBooks();
                break;
            case 'water-taxi':
                await this.loadWaterTaxiData();
                break;
        }
    }

    async loadTabData(tabId) {
        // Tab-specific data loading can be implemented here
    }

    async loadTodos() {
        try {
            const response = await this.apiCall('/api/admin/todos');
            if (response && response.success) {
                this.renderTodos(response.data, 'todos-list');
            } else {
                console.error('Failed to load todos:', response?.message);
            }
        } catch (error) {
            console.error('Error loading todos:', error);
            this.showNotification('Error loading todos', 'error');
        }
    }

    async loadBoatNames() {
        try {
            const response = await this.apiCall('/api/admin/boat-names');
            if (response && response.success) {
                this.renderBoatNames(response.data);
            } else {
                console.error('Failed to load boat names:', response?.message);
            }
        } catch (error) {
            console.error('Error loading boat names:', error);
            this.showNotification('Error loading boat names', 'error');
        }
    }

    renderBoatNames(boatNames) {
        const container = document.getElementById('boat-names-list');
        if (!container) return;
        
        container.innerHTML = boatNames.map(boat => `
            <div class="boat-name-card">
                <h4>${boat.name}</h4>
                <div class="boat-status ${boat.status}">${boat.status}</div>
                <p class="boat-notes">${boat.notes || 'No notes'}</p>
                <div class="boat-meta">
                    Added: ${new Date(boat.createdAt).toLocaleDateString()}
                </div>
            </div>
        `).join('');
    }

    async loadCalendarEvents() {
        try {
            const response = await this.apiCall('/api/admin/calendar');
            if (response && response.success) {
                this.renderCalendarEvents(response.data);
            } else {
                console.error('Failed to load calendar events:', response?.message);
            }
        } catch (error) {
            console.error('Error loading calendar events:', error);
            this.showNotification('Error loading calendar events', 'error');
        }
    }

    renderCalendarEvents(events) {
        const container = document.getElementById('calendar-events-list');
        if (!container) return;
        
        if (events.length === 0) {
            container.innerHTML = '<p class="no-data">No events scheduled</p>';
            return;
        }

        container.innerHTML = events.map(event => `
            <div class="calendar-event">
                <div class="event-date">
                    ${new Date(event.start).toLocaleDateString()}
                </div>
                <div class="event-details">
                    <h4>${event.title}</h4>
                    <p class="event-type ${event.type}">${event.type}</p>
                    ${event.description ? `<p class="event-description">${event.description}</p>` : ''}
                </div>
            </div>
        `).join('');
    }

    async loadMessages() {
        try {
            const response = await this.apiCall('/api/admin/messages');
            if (response && response.success) {
                this.renderMessages(response.data);
            } else {
                console.error('Failed to load messages:', response?.message);
            }
        } catch (error) {
            console.error('Error loading messages:', error);
            this.showNotification('Error loading messages', 'error');
        }
    }

    renderMessages(messages) {
        const container = document.getElementById('messages-list');
        if (!container) return;
        
        if (messages.length === 0) {
            container.innerHTML = '<p class="no-data">No messages</p>';
            return;
        }

        container.innerHTML = messages.map(message => `
            <div class="message-item ${message.read ? 'read' : 'unread'}">
                <div class="message-header">
                    <strong>${message.subject}</strong>
                    <span class="message-date">${new Date(message.createdAt).toLocaleDateString()}</span>
                </div>
                <div class="message-preview">
                    ${message.message.substring(0, 100)}...
                </div>
            </div>
        `).join('');
    }

    async loadUsers() {
        try {
            const response = await this.apiCall('/api/admin/users');
            if (response && response.success) {
                this.renderUsers(response.data);
            } else {
                console.error('Failed to load users:', response?.message);
            }
        } catch (error) {
            console.error('Error loading users:', error);
            this.showNotification('Error loading users', 'error');
        }
    }

    renderUsers(users) {
        const container = document.getElementById('users-list');
        if (!container) return;
        
        container.innerHTML = users.map(user => `
            <div class="user-card">
                <div class="user-info">
                    <h4>${user.name}</h4>
                    <p class="user-email">${user.email}</p>
                    <span class="user-role ${user.role}">${user.role}</span>
                </div>
                <div class="user-meta">
                    <div>Last Login: ${user.lastLogin ? new Date(user.lastLogin).toLocaleDateString() : 'Never'}</div>
                    <div>Created: ${new Date(user.createdAt).toLocaleDateString()}</div>
                </div>
            </div>
        `).join('');
    }

    async loadNewsManagement() {
        try {
            const response = await this.apiCall('/api/admin/news');
            if (response && response.success) {
                this.renderNewsManagement(response.data);
            } else {
                console.error('Failed to load news management:', response?.message);
                this.showFallbackNews();
            }
        } catch (error) {
            console.error('Error loading news management:', error);
            this.showFallbackNews();
        }
    }

    renderNewsManagement(news) {
        const container = document.getElementById('news-management-list');
        if (!container) return;
        
        if (news.length === 0) {
            container.innerHTML = '<p class="no-data">No news articles found</p>';
            return;
        }

        container.innerHTML = news.map(item => `
            <div class="news-management-item" data-news-id="${item.id}">
                <div class="news-management-content">
                    <h4 class="font-semibold text-gray-800">${item.title}</h4>
                    <p class="text-gray-600 mt-1">${item.summary}</p>
                    <div class="news-management-meta mt-2">
                        <span class="text-sm text-gray-500">Source: ${item.source}</span>
                        <span class="text-sm text-gray-500">Date: ${new Date(item.date).toLocaleDateString()}</span>
                        ${this.isSocketConnected ? '<span class="real-time-indicator">LIVE</span>' : ''}
                    </div>
                </div>
                <div class="news-management-actions">
                    <button onclick="adminApp.editNews('${item.id}')" class="px-3 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 flex items-center">
                        <span class="material-symbols-outlined text-sm mr-1">edit</span>
                        Edit
                    </button>
                    <button onclick="adminApp.deleteNews('${item.id}')" class="px-3 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 flex items-center">
                        <span class="material-symbols-outlined text-sm mr-1">delete</span>
                        Delete
                    </button>
                </div>
            </div>
        `).join('');
    }

    async editNews(newsId) {
        try {
            const response = await this.apiCall('/api/admin/news');
            if (response && response.success) {
                const newsItem = response.data.find(item => item.id == newsId);
                if (newsItem) {
                    this.populateNewsForm(newsItem);
                    this.showModal('edit-news-modal');
                }
            }
        } catch (error) {
            console.error('Error loading news for edit:', error);
            this.showNotification('Error loading news article', 'error');
        }
    }

    populateNewsForm(newsItem) {
        document.getElementById('edit-news-id').value = newsItem.id;
        document.getElementById('edit-news-title').value = newsItem.title;
        document.getElementById('edit-news-source').value = newsItem.source;
        document.getElementById('edit-news-date').value = newsItem.date;
        document.getElementById('edit-news-summary').value = newsItem.summary;
        document.getElementById('edit-news-url').value = newsItem.url;
    }

    async updateNews() {
        try {
            const formData = {
                title: document.getElementById('edit-news-title').value,
                source: document.getElementById('edit-news-source').value,
                date: document.getElementById('edit-news-date').value,
                summary: document.getElementById('edit-news-summary').value,
                url: document.getElementById('edit-news-url').value
            };

            const newsId = document.getElementById('edit-news-id').value;
            const response = await this.apiCall(`/api/admin/news/${newsId}`, 'PUT', formData);
            if (response && response.success) {
                this.closeModal('edit-news-modal');
                this.showNotification('News article updated successfully!', 'success');
                await this.loadNews();
                await this.loadNewsManagement();
            } else {
                this.showNotification('Error updating news article: ' + (response?.message || 'Unknown error'), 'error');
            }
        } catch (error) {
            console.error('Error updating news article:', error);
            this.showNotification('Error updating news article', 'error');
        }
    }

    async deleteNews(newsId) {
        if (confirm('Are you sure you want to delete this news article?')) {
            try {
                const response = await this.apiCall(`/api/admin/news/${newsId}`, 'DELETE');
                if (response && response.success) {
                    this.showNotification('News article deleted successfully!', 'success');
                    await this.loadNews();
                    await this.loadNewsManagement();
                } else {
                    this.showNotification('Error deleting news article: ' + (response?.message || 'Unknown error'), 'error');
                }
            } catch (error) {
                console.error('Error deleting news article:', error);
                this.showNotification('Error deleting news article', 'error');
            }
        }
    }

    async addNews() {
        try {
            const formData = {
                title: document.getElementById('news-title').value,
                source: document.getElementById('news-source').value,
                date: document.getElementById('news-date').value,
                summary: document.getElementById('news-summary').value,
                url: document.getElementById('news-url').value
            };

            const response = await this.apiCall('/api/admin/news', 'POST', formData);
            if (response && response.success) {
                this.closeModal('add-news-modal');
                this.showNotification('News article added successfully!', 'success');
                await this.loadNews();
                await this.loadNewsManagement();
            } else {
                this.showNotification('Error adding news article: ' + (response?.message || 'Unknown error'), 'error');
            }
        } catch (error) {
            console.error('Error adding news article:', error);
            this.showNotification('Error adding news article', 'error');
        }
    }

    async fetchRSSNews() {
        try {
            this.showNotification('Fetching latest BVI news from RSS feeds...', 'info');
            
            const response = await this.apiCall('/api/admin/news/fetch-rss', 'POST');
            if (response && response.success) {
                this.showNotification(`Successfully fetched ${response.data.count} new articles`, 'success');
                await this.loadNewsManagement();
                await this.loadNews();
                
                this.updateRSSStats(response.data.stats);
            } else {
                this.showNotification('Failed to fetch RSS news: ' + (response?.message || 'Unknown error'), 'error');
            }
        } catch (error) {
            console.error('Error fetching RSS news:', error);
            this.showNotification('Error fetching RSS news', 'error');
        }
    }

    async viewRSSStatus() {
        try {
            const response = await this.apiCall('/api/admin/news/rss-status');
            if (response && response.success) {
                this.showRSSStatusModal(response.data);
            } else {
                this.showNotification('Failed to load RSS status', 'error');
            }
        } catch (error) {
            console.error('Error fetching RSS status:', error);
            this.showNotification('Error loading RSS status', 'error');
        }
    }

    showRSSStatusModal(statusData) {
        let modal = document.getElementById('rss-status-modal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'rss-status-modal';
            modal.className = 'modal-overlay active';
            modal.innerHTML = `
                <div class="modal-content">
                    <div class="p-6 border-b border-gray-200">
                        <h2 class="text-xl font-semibold">BVI RSS Feed Status</h2>
                    </div>
                    <div class="p-6">
                        <div id="rss-status-content">
                            Loading RSS feed status...
                        </div>
                        <div class="flex justify-end mt-6">
                            <button onclick="closeModal('rss-status-modal')" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
        } else {
            modal.classList.add('active');
        }
        
        const content = document.getElementById('rss-status-content');
        if (content && statusData) {
            content.innerHTML = `
                <div class="space-y-4">
                    <div class="grid grid-cols-2 gap-4">
                        <div class="text-center p-4 bg-blue-50 rounded-lg">
                            <div class="text-2xl font-bold text-blue-600">${statusData.totalFeeds || 0}</div>
                            <div class="text-sm text-gray-600">Total Feeds</div>
                        </div>
                        <div class="text-center p-4 bg-green-50 rounded-lg">
                            <div class="text-2xl font-bold text-green-600">${statusData.activeFeeds || 0}</div>
                            <div class="text-sm text-gray-600">Active Feeds</div>
                        </div>
                    </div>
                    
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <h4 class="font-semibold mb-2">BVI News Sources:</h4>
                        <ul class="space-y-2">
                            ${statusData.feeds ? statusData.feeds.map(feed => `
                                <li class="flex justify-between items-center">
                                    <span>${feed.name}</span>
                                    <span class="status-badge ${feed.status === 'active' ? 'available' : 'maintenance'}">
                                        ${feed.status}
                                    </span>
                                </li>
                            `).join('') : '<li>No feeds configured</li>'}
                        </ul>
                    </div>
                    
                    ${statusData.lastFetch ? `
                        <div class="text-sm text-gray-600">
                            Last fetched: ${new Date(statusData.lastFetch).toLocaleString()}
                        </div>
                    ` : ''}
                </div>
            `;
        }
    }

    updateRSSStats(stats) {
        if (stats) {
            this.updateElementText('total-articles', stats.totalArticles || 0);
            this.updateElementText('auto-fetched', stats.autoFetched || 0);
            this.updateElementText('active-feeds', stats.activeFeeds || 0);
        }
    }

    simulateRealTimeNews() {
        if (this.isSocketConnected) {
            setInterval(() => {
                const mockNews = {
                    id: 'mock-' + Date.now(),
                    title: 'Live BVI News Update',
                    summary: 'This is a simulated real-time news update from BVI news sources.',
                    source: 'BVI News Network',
                    date: new Date().toISOString(),
                    url: '#'
                };
                
                this.handleNewsUpdate({
                    action: 'added',
                    news: mockNews,
                    message: 'New BVI news article received',
                    timestamp: new Date()
                });
            }, 30000);
        }
    }

    setupNewsAutoRefresh() {
        setInterval(() => {
            if (!this.isSocketConnected) {
                if (this.currentSection === 'dashboard-overview') {
                    this.loadNews();
                }
                if (this.currentSection === 'news-management') {
                    this.loadNewsManagement();
                }
            }
        }, 60000);
    }

    async loadSettings() {
        try {
            const response = await this.apiCall('/api/admin/settings');
            if (response && response.success) {
                this.populateSettingsForm(response.data);
            } else {
                console.error('Failed to load settings:', response?.message);
            }
        } catch (error) {
            console.error('Error loading settings:', error);
            this.showNotification('Error loading settings', 'error');
        }
    }

    populateSettingsForm(settings) {
        this.setFormValue('company-name', settings.companyName);
        this.setFormValue('contact-email', settings.contactEmail);
        this.setFormValue('phone', settings.phone);
        this.setFormValue('address', settings.address);
        this.setFormValue('business-hours', settings.businessHours);
    }

    async saveSettings() {
        try {
            const formData = {
                companyName: document.getElementById('company-name').value,
                contactEmail: document.getElementById('contact-email').value,
                phone: document.getElementById('phone').value,
                address: document.getElementById('address').value,
                businessHours: document.getElementById('business-hours').value
            };

            const response = await this.apiCall('/api/admin/settings', 'PUT', formData);
            if (response && response.success) {
                this.showNotification('Settings saved successfully!', 'success');
            } else {
                this.showNotification('Error saving settings: ' + (response?.message || 'Unknown error'), 'error');
            }
        } catch (error) {
            console.error('Error saving settings:', error);
            this.showNotification('Error saving settings', 'error');
        }
    }

    async loadSlowSeasonSettings() {
        try {
            const response = await this.apiCall('/api/admin/slow-season');
            if (response && response.success) {
                this.populateSlowSeasonForm(response.data);
            } else {
                console.error('Failed to load slow season settings:', response?.message);
            }
        } catch (error) {
            console.error('Error loading slow season settings:', error);
            this.showNotification('Error loading slow season settings', 'error');
        }
    }

    populateSlowSeasonForm(settings) {
        this.setFormValue('slow-season-active', settings.active, 'checkbox');
        this.setFormValue('slow-season-start', settings.start);
        this.setFormValue('slow-season-end', settings.end);
        this.setFormValue('water-taxi-discount', (settings.waterTaxiDiscount || 0) * 100);
        this.setFormValue('boat-rental-discount', (settings.boatRentalDiscount || 0) * 100);
        this.setFormValue('day-charter-discount', (settings.dayCharterDiscount || 0) * 100);
    }

    async saveSlowSeasonSettings() {
        try {
            const formData = {
                active: document.getElementById('slow-season-active').checked,
                start: document.getElementById('slow-season-start').value,
                end: document.getElementById('slow-season-end').value,
                waterTaxiDiscount: parseFloat(document.getElementById('water-taxi-discount').value) / 100,
                boatRentalDiscount: parseFloat(document.getElementById('boat-rental-discount').value) / 100,
                dayCharterDiscount: parseFloat(document.getElementById('day-charter-discount').value) / 100
            };

            const response = await this.apiCall('/api/admin/slow-season', 'PUT', formData);
            if (response && response.success) {
                this.showNotification('Slow season settings saved successfully!', 'success');
            } else {
                this.showNotification('Error saving slow season settings: ' + (response?.message || 'Unknown error'), 'error');
            }
        } catch (error) {
            console.error('Error saving slow season settings:', error);
            this.showNotification('Error saving slow season settings', 'error');
        }
    }

    async addUser() {
        try {
            const formData = {
                name: document.getElementById('new-user-name').value,
                email: document.getElementById('new-user-email').value,
                role: document.getElementById('new-user-role').value
            };

            const response = await this.apiCall('/api/admin/users', 'POST', formData);
            if (response && response.success) {
                this.closeModal('add-user-modal');
                this.showNotification('User added successfully!', 'success');
                await this.loadUsers();
            } else {
                this.showNotification('Error adding user: ' + (response?.message || 'Unknown error'), 'error');
            }
        } catch (error) {
            console.error('Error adding user:', error);
            this.showNotification('Error adding user', 'error');
        }
    }

    async sendMessage() {
        try {
            const formData = {
                to: document.getElementById('message-to').value,
                subject: document.getElementById('message-subject').value,
                content: document.getElementById('message-content').value
            };

            const response = await this.apiCall('/api/admin/messages', 'POST', formData);
            if (response && response.success) {
                this.closeModal('message-modal');
                this.showNotification('Message sent successfully!', 'success');
                await this.loadMessages();
            } else {
                this.showNotification('Error sending message: ' + (response?.message || 'Unknown error'), 'error');
            }
        } catch (error) {
            console.error('Error sending message:', error);
            this.showNotification('Error sending message', 'error');
        }
    }

    async addBoatName() {
        try {
            const formData = {
                name: document.getElementById('boat-name').value,
                status: document.getElementById('boat-name-status').value,
                notes: document.getElementById('boat-name-notes').value
            };

            const response = await this.apiCall('/api/admin/boat-names', 'POST', formData);
            if (response && response.success) {
                this.closeModal('boat-name-modal');
                this.showNotification('Boat name added successfully!', 'success');
                await this.loadBoatNames();
            } else {
                this.showNotification('Error adding boat name: ' + (response?.message || 'Unknown error'), 'error');
            }
        } catch (error) {
            console.error('Error adding boat name:', error);
            this.showNotification('Error adding boat name', 'error');
        }
    }

    async addCalendarEvent() {
        try {
            const formData = {
                title: document.getElementById('event-title').value,
                start: document.getElementById('event-start').value,
                end: document.getElementById('event-end').value,
                type: document.getElementById('event-type').value,
                description: document.getElementById('event-description').value
            };

            const response = await this.apiCall('/api/admin/calendar', 'POST', formData);
            if (response && response.success) {
                this.closeModal('calendar-event-modal');
                this.showNotification('Event added successfully!', 'success');
                await this.loadCalendarEvents();
            } else {
                this.showNotification('Error adding event: ' + (response?.message || 'Unknown error'), 'error');
            }
        } catch (error) {
            console.error('Error adding calendar event:', error);
            this.showNotification('Error adding event', 'error');
        }
    }

    async addTodo() {
        try {
            const formData = {
                task: document.getElementById('todo-task').value,
                dueDate: document.getElementById('todo-due-date').value,
                assignedTo: parseInt(document.getElementById('todo-assigned-to').value)
            };

            const response = await this.apiCall('/api/admin/todos', 'POST', formData);
            if (response && response.success) {
                this.closeModal('todo-modal');
                this.showNotification('Todo added successfully!', 'success');
                await this.loadUserTodos();
                if (this.currentSection === 'todos') {
                    await this.loadTodos();
                }
            } else {
                this.showNotification('Error adding todo: ' + (response?.message || 'Unknown error'), 'error');
            }
        } catch (error) {
            console.error('Error adding todo:', error);
            this.showNotification('Error adding todo', 'error');
        }
    }

    async createBooking() {
        try {
            const formData = {
                serviceType: document.getElementById('booking-service-type').value,
                customerName: `${document.getElementById('customer-first-name').value} ${document.getElementById('customer-last-name').value}`,
                customerEmail: document.getElementById('customer-email').value,
                customerPhone: document.getElementById('customer-phone').value,
                date: document.getElementById('booking-date').value,
                specialRequests: document.getElementById('booking-message').value,
                estimatedPrice: parseFloat(document.getElementById('booking-price').value)
            };

            const response = await this.apiCall('/api/admin/bookings', 'POST', formData);
            if (response && response.success) {
                this.closeModal('booking-modal');
                this.showNotification('Booking created successfully!', 'success');
            } else {
                this.showNotification('Error creating booking: ' + (response?.message || 'Unknown error'), 'error');
            }
        } catch (error) {
            console.error('Error creating booking:', error);
            this.showNotification('Error creating booking', 'error');
        }
    }

    async apiCall(endpoint, method = 'GET', data = null) {
        try {
            const options = {
                method,
                headers: {
                    'Content-Type': 'application/json',
                }
            };

            if (this.token) {
                options.headers.Authorization = `Bearer ${this.token}`;
            }

            if (data && method !== 'GET') {
                options.body = JSON.stringify(data);
            }

            const response = await fetch(endpoint, options);
            
            if (!response.ok) {
                if (response.status === 401) {
                    this.handleLogout();
                    throw new Error('Authentication failed. Please login again.');
                } else if (response.status === 403) {
                    throw new Error('Access forbidden. You do not have permission.');
                } else if (response.status === 404) {
                    if (endpoint.includes('/news')) {
                        return { success: true, data: [] };
                    }
                    throw new Error('Endpoint not found.');
                } else if (response.status >= 500) {
                    throw new Error('Server error. Please try again later.');
                } else {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
            }

            const result = await response.json();
            return result;
        } catch (error) {
            console.error('API call error:', error);
            
            if (!endpoint.includes('/news')) {
                if (error.message.includes('Authentication failed')) {
                    this.showNotification('Session expired. Please login again.', 'error');
                    this.handleLogout();
                } else if (error.message.includes('Network error')) {
                    this.showNotification('Network error. Please check your connection.', 'error');
                } else {
                    this.showNotification('Error: ' + error.message, 'error');
                }
            }
            
            if (endpoint.includes('/news')) {
                return { success: true, data: [] };
            }
            
            return { success: false, message: error.message };
        }
    }

    updateElementText(elementId, text) {
        const element = document.getElementById(elementId);
        if (element) {
            element.textContent = text;
        }
    }

    setFormValue(elementId, value, type = 'text') {
        const element = document.getElementById(elementId);
        if (element) {
            if (type === 'checkbox') {
                element.checked = value;
            } else {
                element.value = value || '';
            }
        }
    }

    showError(element, message) {
        if (element) {
            element.textContent = message;
            element.classList.remove('hidden');
        }
    }

    hideError(element) {
        if (element) {
            element.classList.add('hidden');
        }
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;

        if (!document.querySelector('.notification')) {
            const style = document.createElement('style');
            style.textContent = `
                .notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    padding: 15px 20px;
                    border-radius: 5px;
                    color: white;
                    z-index: 10000;
                    max-width: 300px;
                    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                }
                .notification.success { background-color: #4CAF50; }
                .notification.error { background-color: #f44336; }
                .notification.info { background-color: #2196F3; }
                .notification.warning { background-color: #ff9800; }
            `;
            document.head.appendChild(style);
        }

        document.body.appendChild(notification);

        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }

    updateCurrentDate() {
        const now = new Date();
        const dateElement = document.getElementById('current-date');
        if (dateElement) {
            dateElement.textContent = now.toLocaleDateString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        }
    }

    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('active');
        }
    }

    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
            const form = modal.querySelector('form');
            if (form) {
                form.reset();
            }
        }
    }

    async loadBookings() {
        try {
            const response = await this.apiCall('/api/admin/bookings');
            if (response && response.success) {
                this.renderBookings(response.data);
            }
        } catch (error) {
            console.error('Error loading bookings:', error);
        }
    }

    async loadCRM() {
        try {
            const response = await this.apiCall('/api/admin/crm');
            if (response && response.success) {
                this.renderCRM(response.data);
            }
        } catch (error) {
            console.error('Error loading CRM:', error);
        }
    }

    async loadNewsletters() {
        try {
            const response = await this.apiCall('/api/admin/newsletters');
            if (response && response.success) {
                this.renderNewsletters(response.data);
            }
        } catch (error) {
            console.error('Error loading newsletters:', error);
        }
    }

    async loadFAQs() {
        try {
            const response = await this.apiCall('/api/admin/faqs');
            if (response && response.success) {
                this.renderFAQs(response.data);
            }
        } catch (error) {
            console.error('Error loading FAQs:', error);
        }
    }

    async loadTickets() {
        try {
            const response = await this.apiCall('/api/admin/tickets');
            if (response && response.success) {
                this.renderTickets(response.data);
            }
        } catch (error) {
            console.error('Error loading tickets:', error);
        }
    }

    async loadRates() {
        try {
            const response = await this.apiCall('/api/admin/rates');
            if (response && response.success) {
                this.renderRates(response.data);
            }
        } catch (error) {
            console.error('Error loading rates:', error);
        }
    }

    async loadFiles() {
        try {
            const response = await this.apiCall('/api/admin/files');
            if (response && response.success) {
                this.renderFiles(response.data);
            }
        } catch (error) {
            console.error('Error loading files:', error);
        }
    }

    async loadQuickBooks() {
        try {
            const response = await this.apiCall('/api/admin/quickbooks/status');
            if (response && response.success) {
                this.renderQuickBooks(response.data);
            }
        } catch (error) {
            console.error('Error loading QuickBooks:', error);
        }
    }

    renderBookings(bookings) {
        const container = document.getElementById('bookings-list');
        if (!container) return;
        
        if (bookings.length === 0) {
            container.innerHTML = '<p class="no-data">No bookings found</p>';
            return;
        }

        container.innerHTML = bookings.map(booking => `
            <div class="booking-card">
                <h4>${booking.customerName} - ${booking.serviceType}</h4>
                <p>Date: ${new Date(booking.date).toLocaleDateString()}</p>
                <p>Status: <span class="status-badge ${booking.status}">${booking.status}</span></p>
            </div>
        `).join('');
    }

    renderCRM(contacts) {
        const container = document.getElementById('crm-list');
        if (!container) return;
        
        if (contacts.length === 0) {
            container.innerHTML = '<p class="no-data">No CRM contacts found</p>';
            return;
        }

        container.innerHTML = contacts.map(contact => `
            <div class="crm-card">
                <h4>${contact.name}</h4>
                <p>${contact.email}</p>
                <p>${contact.phone || 'No phone'}</p>
            </div>
        `).join('');
    }

    renderNewsletters(newsletters) {
        const container = document.getElementById('newsletters-list');
        if (!container) return;
        
        if (newsletters.length === 0) {
            container.innerHTML = '<p class="no-data">No newsletters found</p>';
            return;
        }

        container.innerHTML = newsletters.map(newsletter => `
            <div class="newsletter-card">
                <h4>${newsletter.name}</h4>
                <p>Subject: ${newsletter.subject}</p>
                <p>Status: ${newsletter.status}</p>
            </div>
        `).join('');
    }

    renderFAQs(faqs) {
        const container = document.getElementById('faqs-list');
        if (!container) return;
        
        if (faqs.length === 0) {
            container.innerHTML = '<p class="no-data">No FAQs found</p>';
            return;
        }

        container.innerHTML = faqs.map(faq => `
            <div class="faq-card">
                <h4>${faq.question}</h4>
                <p>${faq.answer}</p>
            </div>
        `).join('');
    }

    renderTickets(tickets) {
        const container = document.getElementById('tickets-list');
        if (!container) return;
        
        if (tickets.length === 0) {
            container.innerHTML = '<p class="no-data">No tickets found</p>';
            return;
        }

        container.innerHTML = tickets.map(ticket => `
            <div class="ticket-card">
                <h4>${ticket.subject}</h4>
                <p>Status: <span class="status-badge ${ticket.status}">${ticket.status}</span></p>
            </div>
        `).join('');
    }

    renderRates(rates) {
        const container = document.getElementById('rates-content');
        if (!container) return;
        
        container.innerHTML = `
            <h3>Water Taxi Rates</h3>
            <pre>${JSON.stringify(rates.waterTaxi, null, 2)}</pre>
            
            <h3>Boat Rental Rates</h3>
            <pre>${JSON.stringify(rates.boatRental, null, 2)}</pre>
            
            <h3>Day Charter Rates</h3>
            <pre>${JSON.stringify(rates.dayCharter, null, 2)}</pre>
            
            <h3>Car Rental Rates</h3>
            <pre>${JSON.stringify(rates.carRental, null, 2)}</pre>
        `;
    }

    renderFiles(files) {
        const container = document.getElementById('files-list');
        if (!container) return;
        
        if (files.length === 0) {
            container.innerHTML = '<p class="no-data">No files found</p>';
            return;
        }

        container.innerHTML = files.map(file => `
            <div class="file-card">
                <h4>${file.name}</h4>
                <p>Type: ${file.type}</p>
                <p>Size: ${file.size}</p>
            </div>
        `).join('');
    }

    renderQuickBooks(quickbooks) {
        const container = document.getElementById('quickbooks-status');
        if (!container) return;
        
        container.innerHTML = `
            <div class="quickbooks-card">
                <h4>QuickBooks Status: ${quickbooks.connected ? 'Connected' : 'Disconnected'}</h4>
                ${quickbooks.connected ? `
                    <p>Company: ${quickbooks.companyName}</p>
                    <p>Last Sync: ${quickbooks.lastSync ? new Date(quickbooks.lastSync).toLocaleDateString() : 'Never'}</p>
                ` : `
                    <p>Not connected to QuickBooks</p>
                `}
            </div>
        `;
    }
}

// Global functions for HTML onclick handlers
function showAddUserForm() {
    if (adminApp) adminApp.showModal('add-user-modal');
}

function showNewMessageForm() {
    if (adminApp) adminApp.showModal('message-modal');
}

function showAddBoatNameForm() {
    if (adminApp) adminApp.showModal('boat-name-modal');
}

function showAddEventForm() {
    if (adminApp) adminApp.showModal('calendar-event-modal');
}

function showAddTodoForm() {
    if (adminApp) adminApp.showModal('todo-modal');
}

function showAddNewsForm() {
    if (adminApp) adminApp.showModal('add-news-modal');
}

function showEditTemplateModal() {
    if (adminApp) adminApp.showModal('water-taxi-edit-template-modal');
}

function showAddRouteModal() {
    if (adminApp) adminApp.showModal('water-taxi-add-route-modal');
}

function showSendAuthorizationModal() {
    if (adminApp) adminApp.showModal('send-authorization-modal');
}

function createNewBooking(serviceType) {
    if (!adminApp) return;
    
    const modal = document.getElementById('booking-modal');
    const title = document.getElementById('booking-modal-title');
    const serviceSelect = document.getElementById('booking-service-type');
    
    if (modal && title && serviceSelect) {
        serviceSelect.value = serviceType;
        
        const serviceTitles = {
            'water-taxi': 'New Water Taxi Booking',
            'boat-rental': 'New Boat Rental',
            'day-charter': 'New Day Charter',
            'car-rental': 'New Car Rental'
        };
        
        title.textContent = serviceTitles[serviceType] || 'New Booking';
        adminApp.showModal('booking-modal');
    }
}

function closeModal(modalId) {
    if (adminApp) adminApp.closeModal(modalId);
}

function refreshBookings(serviceType) {
    if (adminApp) {
        adminApp.showNotification('Refreshing bookings...', 'info');
        adminApp.loadBookings();
    }
}

function connectQuickBooks() {
    if (adminApp) adminApp.showModal('quickbooks-modal');
}

function initiateQuickBooksAuth() {
    if (adminApp) {
        adminApp.showNotification('QuickBooks connection initiated', 'info');
    }
}

function updateNews() {
    if (adminApp) adminApp.updateNews();
}

let adminApp;
document.addEventListener('DOMContentLoaded', () => {
    adminApp = new AdminApp();
});