-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users and Authentication
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    phone VARCHAR(20),
    role VARCHAR(20) DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- BVI Boat Types
CREATE TABLE IF NOT EXISTS boat_types (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    capacity INTEGER NOT NULL,
    base_price_per_hour DECIMAL(10,2),
    image_url VARCHAR(500)
);

-- BVI Boats
CREATE TABLE IF NOT EXISTS boats (
    id SERIAL PRIMARY KEY,
    boat_type_id INTEGER REFERENCES boat_types(id),
    name VARCHAR(100) NOT NULL,
    registration_number VARCHAR(100) UNIQUE,
    status VARCHAR(20) DEFAULT 'active',
    current_location VARCHAR(100),
    features TEXT[],
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- BVI Destinations (British Virgin Islands specific)
CREATE TABLE IF NOT EXISTS destinations (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(50), -- marina, beach, resort, island
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    description TEXT
);

-- BVI Routes
CREATE TABLE IF NOT EXISTS routes (
    id SERIAL PRIMARY KEY,
    from_destination_id INTEGER REFERENCES destinations(id),
    to_destination_id INTEGER REFERENCES destinations(id),
    estimated_duration_minutes INTEGER,
    base_price DECIMAL(10,2),
    distance_nautical_miles DECIMAL(8,2)
);

-- Bookings
CREATE TABLE IF NOT EXISTS bookings (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER REFERENCES users(id),
    booking_type VARCHAR(20) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    total_amount DECIMAL(10,2),
    payment_status VARCHAR(20) DEFAULT 'pending',
    special_requests TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Water Taxi Bookings
CREATE TABLE IF NOT EXISTS water_taxi_bookings (
    id SERIAL PRIMARY KEY,
    booking_id INTEGER REFERENCES bookings(id),
    route_id INTEGER REFERENCES routes(id),
    boat_type_id INTEGER REFERENCES boat_types(id),
    departure_time TIMESTAMP NOT NULL,
    passengers_count INTEGER NOT NULL,
    price DECIMAL(10,2)
);

-- Insert BVI-specific sample data

-- Sample admin user (password: admin123)
INSERT INTO users (email, password_hash, first_name, last_name, role) 
VALUES ('admin@islandtimebvi.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Island', 'Admin', 'admin')
ON CONFLICT (email) DO NOTHING;

-- Sample BVI boat types
INSERT INTO boat_types (name, description, capacity, base_price_per_hour, image_url) VALUES
('BVI Speedboat', 'Perfect for quick island hopping', 8, 200.00, '/images/bvi-speedboat.jpg'),
('Luxury Catamaran', 'Spacious and comfortable for groups', 16, 600.00, '/images/catamaran.jpg'),
('Fishing Boat', 'Equipped for BVI fishing adventures', 6, 250.00, '/images/fishing-boat.jpg'),
('Dinghy', 'Small boat for short distances', 4, 80.00, '/images/dinghy.jpg')
ON CONFLICT DO NOTHING;

-- Sample BVI boats
INSERT INTO boats (boat_type_id, name, registration_number, status, current_location, features) VALUES
(1, 'Island Hopper', 'BVI-SP001', 'active', 'Tortola', '{"GPS", "Snorkel Gear", "Cooler"}'),
(1, 'Caribbean Breeze', 'BVI-SP002', 'active', 'Virgin Gorda', '{"Bluetooth Audio", "Shade Cover", "Ladder"}'),
(2, 'Paradise Cat', 'BVI-CT001', 'active', 'Tortola', '{"Restroom", "Kitchen", "Sun Deck"}'),
(3, 'Catch of the Day', 'BVI-FB001', 'maintenance', 'Jost Van Dyke', '{"Fishing Rods", "Bait Cooler", "Fish Finder"}'),
(4, 'Little Runner', 'BVI-DG001', 'active', 'Tortola', '{"Oars", "Life Jackets"}')
ON CONFLICT DO NOTHING;

-- Sample BVI destinations
INSERT INTO destinations (name, type, latitude, longitude, description) VALUES
('Road Town, Tortola', 'marina', 18.4269, -64.6208, 'Main harbor and capital of BVI'),
('The Baths, Virgin Gorda', 'beach', 18.4286, -64.4467, 'Famous granite boulder formations'),
('White Bay, Jost Van Dyke', 'beach', 18.4456, -64.7519, 'Home of the Soggy Dollar Bar'),
('Cane Garden Bay, Tortola', 'beach', 18.4278, -64.6531, 'Beautiful sandy beach with amenities'),
('Marina Cay', 'island', 18.4667, -64.5333, 'Small island with resort and marina'),
('Cooper Island', 'island', 18.3833, -64.5167, 'Known for eco-resort and beach club')
ON CONFLICT DO NOTHING;

-- Sample BVI routes (in nautical miles)
INSERT INTO routes (from_destination_id, to_destination_id, estimated_duration_minutes, base_price, distance_nautical_miles) VALUES
(1, 2, 45, 180.00, 12.5),  -- Road Town to The Baths
(1, 3, 30, 120.00, 8.2),   -- Road Town to White Bay
(1, 4, 20, 80.00, 5.5),    -- Road Town to Cane Garden Bay
(1, 5, 25, 100.00, 6.8),   -- Road Town to Marina Cay
(1, 6, 35, 140.00, 9.5),   -- Road Town to Cooper Island
(2, 3, 40, 160.00, 11.0),  -- The Baths to White Bay
(3, 4, 25, 100.00, 7.0)    -- White Bay to Cane Garden Bay
ON CONFLICT DO NOTHING;