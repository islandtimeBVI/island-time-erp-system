require('dotenv').config({ path: __dirname + '/.env' });

const express = require('express');
const path = require('path');
const fs = require('fs').promises;
const jwt = require('jsonwebtoken');
const cors = require('cors');
const bcrypt = require('bcrypt');
const http = require('http');
const socketIo = require('socket.io');
const Parser = require('rss-parser');
const OAuthClient = require('intuit-oauth');
const QuickBooks = require('node-quickbooks');
const multer = require('multer');
const axios = require('axios'); 
const crypto = require('crypto'); // Added for CC Auth Encryption

// QuickBooks OAuth Configuration
const oauthClient = new OAuthClient({
    clientId: process.env.QUICKBOOKS_CLIENT_ID,
    clientSecret: process.env.QUICKBOOKS_CLIENT_SECRET,
    environment: process.env.QUICKBOOKS_ENVIRONMENT || 'sandbox',
    redirectUri: process.env.QUICKBOOKS_REDIRECT_URI || 'http://localhost:3001/api/admin/quickbooks/callback'
});

console.log('🔐 QuickBooks OAuth configured:', {
    clientId: process.env.QUICKBOOKS_CLIENT_ID ? '✓ Set' : '✗ Missing',
    clientSecret: process.env.QUICKBOOKS_CLIENT_SECRET ? '✓ Set' : '✗ Missing',
    environment: process.env.QUICKBOOKS_ENVIRONMENT || 'sandbox (default)',
    redirectUri: process.env.QUICKBOOKS_REDIRECT_URI || 'http://localhost:3001/api/admin/quickbooks/callback (default)'
});
// ======== END QUICKBOOKS OAUTH CONFIGURATION ========

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "http://localhost:3000",
        methods: ["GET", "POST"]
    }
});

// Create RSS parser instance
const rssParser = new Parser({
    timeout: 10000,
    customFields: {
        item: [
            ['content:encoded', 'contentEncoded'],
            ['description', 'description'],
            ['pubDate', 'pubDate']
        ]
    }
});

// ======== INSERT RSS FEED CONFIGURATION HERE ========
// BVI RSS News Feeds Configuration
const BVI_RSS_FEEDS = [
    {
        name: 'BVI Beacon',
        url: 'https://www.bvibeacon.com/feed/',
        category: 'Local News'
    },
    {
        name: 'Caribbean News Global',
        url: 'https://caribbeannewsglobal.com/category/bvi/feed/',
        category: 'Regional News'
    },
    {
        name: 'BVI News',
        url: 'https://bvinews.com/feed/',
        category: 'Local News'
    },
    {
        name: 'Caribbean Journal',
        url: 'https://www.caribjournal.com/feed/',
        category: 'Regional News'
    },
    {
        name: 'The Virgin Islands Daily News',
        url: 'https://www.virginislandsdailynews.com/feed/',
        category: 'Local News'
    }
];

// Weather and Alert Feeds
const WEATHER_FEEDS = [
    {
        name: 'BVI Weather Alerts',
        url: 'https://alert.bvi.gov.vg/feed',
        category: 'Weather & Alerts'
    }
];
// ======== END RSS FEED CONFIGURATION ========

const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'islandtimebvi_secret_key_2024';

// --- ENCRYPTION SETTINGS (NEW) ---
const ENCRYPTION_KEY = crypto.scryptSync(JWT_SECRET, 'salt', 32);
const IV_LENGTH = 16;
const activePins = new Map(); // Store temporary PINs for CC Reveal

app.use(cors({
    origin: 'http://localhost:3000',
    credentials: true
}));
app.use(express.json({ limit: '50mb' })); // Increased limit for Signature Images
app.use('/admin', express.static(path.join(__dirname, 'admin')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/islandtime-access', express.static(path.join(__dirname, 'islandtime-access')));

const dataDir = path.join(__dirname, 'data');
const usersFile = path.join(dataDir, 'users.json');
const bookingsFile = path.join(dataDir, 'bookings.json');
const messagesFile = path.join(dataDir, 'messages.json');
const boatNamesFile = path.join(dataDir, 'boatNames.json');
const calendarFile = path.join(dataDir, 'calendar.json');
const filesFile = path.join(dataDir, 'files.json');
const todosFile = path.join(dataDir, 'todos.json');
const crmFile = path.join(dataDir, 'crm.json');
const newslettersFile = path.join(dataDir, 'newsletters.json');
const settingsFile = path.join(dataDir, 'settings.json');
const faqsFile = path.join(dataDir, 'faqs.json');
const ticketsFile = path.join(dataDir, 'tickets.json');
const ratesFile = path.join(dataDir, 'rates.json');
const slowSeasonFile = path.join(dataDir, 'slowSeason.json');
const carFleetFile = path.join(dataDir, 'carFleet.json');
const vehicleRegistrationsFile = path.join(dataDir, 'vehicleRegistrations.json');
const boatFleetFile = path.join(dataDir, 'boatFleet.json');
const newsFile = path.join(dataDir, 'news.json');
const quickbooksFile = path.join(dataDir, 'quickbooks.json');
const maintenanceFile = path.join(dataDir, 'maintenance.json');
const passportsFile = path.join(dataDir, 'passports.json');
const sailclearFile = path.join(dataDir, 'sailclear.json');
const contentPlansFile = path.join(dataDir, 'contentPlans.json');
const creatorNotesFile = path.join(dataDir, 'creatorNotes.json');
const socialConnectionsFile = path.join(dataDir, 'socialConnections.json');
const reportsFile = path.join(dataDir, 'reports.json');
const contentCalendarFile = path.join(dataDir, 'contentCalendar.json');
const contentIdeasFile = path.join(dataDir, 'contentIdeas.json');
const ccAuthsFile = path.join(dataDir, 'ccAuths.json'); // NEW: CC Auth File

function generateId() {
    return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

// --- ENCRYPTION HELPERS (NEW) ---
function encrypt(text) {
    let iv = crypto.randomBytes(IV_LENGTH);
    let cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY), iv);
    let encrypted = cipher.update(text);
    encrypted = Buffer.concat([encrypted, cipher.final()]);
    return iv.toString('hex') + ':' + encrypted.toString('hex');
}

function decrypt(text) {
    let textParts = text.split(':');
    let iv = Buffer.from(textParts.shift(), 'hex');
    let encryptedText = Buffer.from(textParts.join(':'), 'hex');
    let decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY), iv);
    let decrypted = decipher.update(encryptedText);
    decrypted = Buffer.concat([decrypted, decipher.final()]);
    return decrypted.toString();
}

async function ensureDataFiles() {
    try {
        await fs.access(dataDir);
    } catch {
        await fs.mkdir(dataDir, { recursive: true });
    }

    const [adminHashedPassword, boatsHashedPassword, carsHashedPassword, creatorHashedPassword] = await Promise.all([
        bcrypt.hash('admin123', 10),
        bcrypt.hash('boats123', 10),
        bcrypt.hash('cars123', 10),
        bcrypt.hash('content123', 10)
    ]);

    const defaultFiles = {
        [usersFile]: [
            { 
                id: 1, 
                name: 'Admin User', 
                email: 'admin@islandtimebvi.com', 
                password: adminHashedPassword,
                role: 'admin', 
                isActive: true,
                lastLogin: new Date().toISOString(),
                createdAt: new Date().toISOString(),
                permissions: ['all'],
                accessLevel: 'admin'
            },
            { 
                id: 2, 
                name: 'Boat Rentals', 
                email: 'boats@islandtimebvi.com', 
                password: boatsHashedPassword,
                role: 'staff', 
                isActive: true,
                lastLogin: new Date().toISOString(),
                createdAt: new Date().toISOString(),
                permissions: ['view_bookings', 'manage_bookings', 'view_customers', 'manage_customers', 'view_fleet', 'view_fleet_details', 'manage_water_taxi', 'manage_boat_rental', 'manage_car_rental', 'view_schedule', 'manage_tasks'],
                accessLevel: 'captain'
            },
            { 
                id: 3,
                name: 'Car Rentals LTD', 
                email: 'cars@islandtimeltd.com',
                password: carsHashedPassword,
                role: 'staff', 
                isActive: true,
                lastLogin: new Date().toISOString(),
                createdAt: new Date().toISOString(),
                permissions: ['view_car_rentals', 'manage_car_rentals', 'view_fleet', 'manage_fleet', 'view_maintenance', 'manage_maintenance', 'view_registrations', 'manage_registrations', 'create_bookings', 'view_reports', 'export_data'],
                accessLevel: 'car-rental'
            },
            { 
                id: 4, 
                name: 'Content Creator', 
                email: 'content@islandtimeltd.com', 
                password: creatorHashedPassword,
                role: 'staff', 
                isActive: true,
                lastLogin: new Date().toISOString(),
                createdAt: new Date().toISOString(),
                permissions: ['manage_content', 'view_content', 'create_content', 'schedule_content', 'manage_calendar', 'manage_notes', 'view_reports', 'create_reports', 'social_integration', 'view_analytics'],
                accessLevel: 'creator'
            }
        ],
        [bookingsFile]: [],
        [messagesFile]: [],
        [boatNamesFile]: [
            { id: 1, name: 'Island Time', status: 'active', notes: 'Main charter boat', createdAt: new Date().toISOString() },
            { id: 2, name: 'Caribbean Dream', status: 'active', notes: 'Backup boat', createdAt: new Date().toISOString() }
        ],
        [calendarFile]: [],
        [filesFile]: [],
        [todosFile]: [
            { id: 1, task: 'Update boat maintenance schedules', completed: false, dueDate: '2024-02-15', assignedTo: 1, createdAt: new Date().toISOString() }
        ],
        [crmFile]: [],
        [newslettersFile]: [
            {
                id: 1,
                name: 'Winter Specials',
                subject: 'Winter Getaway Specials - Island Time BVI',
                content: 'Special winter rates available...',
                sentTo: 150,
                sentDate: '2024-01-15',
                status: 'sent',
                createdAt: new Date().toISOString()
            }
        ],
        [settingsFile]: {
            companyName: 'Island Time BVI',
            contactEmail: 'info@islandtimebvi.com',
            phone: '+1-284-495-1234',
            address: 'Road Town, Tortola, British Virgin Islands',
            businessHours: '8:00 AM - 6:00 PM',
            currency: 'USD',
            taxRate: 0.10,
            author: 'Jason I, the Master of None'
        },
        [faqsFile]: [
            {
                id: 1,
                question: 'What is your cancellation policy?',
                answer: 'We offer free cancellation up to 48 hours before your scheduled service.',
                createdAt: new Date().toISOString()
            }
        ],
        [ticketsFile]: [],
        [ratesFile]: {
            waterTaxi: {
                baseRate: 180,
                perPerson: 25,
                minimumPassengers: 2,
                routes: [
                    { from: 'Road Town, Tortola', to: 'The Baths, Virgin Gorda', price: 180, duration: 45 },
                    { from: 'Road Town, Tortola', to: 'White Bay, Jost Van Dyke', price: 120, duration: 30 }
                ]
            },
            boatRental: {
                sizes: [
                    { size: "15' RIB", dailyRate: 150, hourlyRate: 50, capacity: 4 },
                    { size: "17' RIB", dailyRate: 200, hourlyRate: 65, capacity: 6 },
                    { size: "23' Cobia", dailyRate: 250, hourlyRate: 80, capacity: 4 },
                    { size: "28' Cobia", dailyRate: 400, hourlyRate: 120, capacity: 6 }
                ]
            },
            dayCharter: {
                baseRates: [
                    { boatSize: "23' Cobia", halfDay: 400, fullDay: 600 },
                    { boatSize: "28' Cobia", halfDay: 500, fullDay: 750 },
                    { boatSize: "32' Seafox", halfDay: 650, fullDay: 950 }
                ],
                includes: ['Captain', 'Fuel', 'Snorkel Gear', 'Cooler with Ice']
            },
            carRental: {
                vehicles: [
                    { type: 'Compact Car', dailyRate: 65, weeklyRate: 400 },
                    { type: 'Compact SUV', dailyRate: 75, weeklyRate: 450 },
                    { type: 'SUV', dailyRate: 95, weeklyRate: 570 },
                    { type: '2DR Jimny', dailyRate: 85, weeklyRate: 500 },
                    { type: '4DR Jimny', dailyRate: 95, weeklyRate: 550 },
                    { type: '2DR Wrangler', dailyRate: 110, weeklyRate: 650 },
                    { type: '4DR Wrangler', dailyRate: 130, weeklyRate: 750 }
                ]
            }
        },
        [slowSeasonFile]: {
            active: true,
            start: '2024-09-01',
            end: '2024-11-30',
            waterTaxiDiscount: 0.15,
            boatRentalDiscount: 0.10,
            dayCharterDiscount: 0.12
        },
        [carFleetFile]: [
            { id: 1, name: 'Toyota Corolla', type: 'Compact Car', status: 'available', location: 'Nanny Cay', lastMaintenance: '2024-01-15', nextMaintenance: '2024-04-15' },
            { id: 2, name: 'Honda CR-V', type: 'Compact SUV', status: 'available', location: 'Road Town', lastMaintenance: '2024-01-20', nextMaintenance: '2024-04-20' },
            { id: 3, name: 'Jeep Wrangler', type: '4x4', status: 'rented', location: 'Beef Island', lastMaintenance: '2024-01-10', nextMaintenance: '2024-04-10' },
            { id: 4, name: 'Toyota RAV4', type: 'SUV', status: 'maintenance', location: 'Road Town', lastMaintenance: '2024-01-05', nextMaintenance: '2024-02-05' }
        ],
        [vehicleRegistrationsFile]: [
            { id: 1, carId: 1, vehicleDetails: 'Toyota Corolla (BVI-1234)', registrationNumber: 'BVI-1234', expiryDate: '2025-06-30', insuranceExpiry: '2025-06-30', status: 'valid', lastRenewal: '2024-06-30', renewalFee: 350, createdAt: new Date().toISOString() },
            { id: 2, carId: 2, vehicleDetails: 'Honda CR-V (BVI-5678)', registrationNumber: 'BVI-5678', expiryDate: '2025-07-15', insuranceExpiry: '2025-07-15', status: 'valid', lastRenewal: '2024-07-15', renewalFee: 450, createdAt: new Date().toISOString() },
            { id: 3, carId: 3, vehicleDetails: 'Jeep Wrangler (BVI-9012)', registrationNumber: 'BVI-9012', expiryDate: '2025-05-31', insuranceExpiry: '2025-05-31', status: 'expiring_soon', lastRenewal: '2024-05-31', renewalFee: 550, createdAt: new Date().toISOString() },
            { id: 4, carId: 4, vehicleDetails: 'BMW X5 (BVI-3456)', registrationNumber: 'BVI-3456', expiryDate: '2025-08-20', insuranceExpiry: '2025-08-20', status: 'valid', lastRenewal: '2024-08-20', renewalFee: 750, createdAt: new Date().toISOString() }
        ],
        [boatFleetFile]: [
            { id: 1, name: 'Island Hopper', type: ['Speedboat', 'Water Taxi'], status: 'available', capacity: 8, location: 'Tortola', lastMaintenance: '2024-01-18', nextMaintenance: '2024-03-18' },
            { id: 2, name: 'Sea Breeze', type: ['Boat Rental'], status: 'available', capacity: 6, location: 'Soper\'s Hole', lastMaintenance: '2024-01-22', nextMaintenance: '2024-03-22' },
            { id: 3, name: 'Caribbean Dream', type: ['Day Charter'], status: 'chartered', capacity: 12, location: 'Virgin Gorda', lastMaintenance: '2024-01-12', nextMaintenance: '2024-03-12' },
            { id: 4, name: 'Trade Winds', type: ['Water Taxi'], status: 'maintenance', capacity: 6, location: 'Road Town Marina', lastMaintenance: '2024-01-08', nextMaintenance: '2024-02-08' }
        ],
        [newsFile]: [
            { id: '1', title: 'BVI Tourism Shows Strong Recovery in 2024', source: 'BVI Beacon', date: '2024-01-20', summary: 'The British Virgin Islands tourism sector continues to show strong recovery with increased visitor numbers.', url: '#' },
            { id: '2', title: 'New Marina Developments in Road Town', source: 'Virgin Islands Daily News', date: '2024-01-18', summary: 'Road Town marina expansion project set to begin in Q2 2024.', url: '#' },
            { id: '3', title: 'Sustainable Tourism Initiatives Launched', source: 'BVI Government', date: '2024-01-15', summary: 'New sustainable tourism programs to protect BVI natural resources.', url: '#' },
            { id: '4', title: 'Weather Alert: High Winds Expected', source: 'BVI Meteorological Service', date: '2024-01-22', summary: 'High wind warning in effect for the next 48 hours.', url: '#' }
        ],
        [quickbooksFile]: {
            connected: false,
            lastSync: null,
            companyName: '',
            syncSettings: { autoSyncBookings: true, autoSyncInvoices: true, syncInterval: 'daily' },
            financialData: { totalRevenue: 0, totalExpenses: 0, outstandingInvoices: 0, recentTransactions: [] }
        },
        [maintenanceFile]: [
            { id: 1, boatId: 1, boatName: 'Island Hopper', type: 'routine', description: 'Engine oil change and filter replacement', scheduledDate: '2024-03-18', completedDate: null, status: 'scheduled', assignedTo: 1, estimatedHours: 2, partsRequired: ['Engine oil', 'Oil filter'], cost: 150, createdAt: new Date().toISOString() },
            { id: 2, boatId: 4, boatName: 'Trade Winds', type: 'repair', description: 'Hull inspection and repair', scheduledDate: '2024-02-08', completedDate: null, status: 'in-progress', assignedTo: 1, estimatedHours: 8, partsRequired: ['Fiberglass kit', 'Marine paint'], cost: 1200, createdAt: new Date().toISOString() }
        ],
        [passportsFile]: [],
        [sailclearFile]: { connected: false, apiKey: null, lastSync: null, submissions: [], settings: { autoSubmit: false, notifyOnSuccess: true, notifyOnFailure: true } },
        [contentPlansFile]: [],
        [creatorNotesFile]: [],
        [socialConnectionsFile]: { facebook: false, instagram: false, lastUpdated: new Date().toISOString() },
        [reportsFile]: [],
        [contentCalendarFile]: [],
        [contentIdeasFile]: [],
        [ccAuthsFile]: [] // New CC Auth Storage
    };
    
    const createdFiles = [];
    const existingFiles = [];

    for (const [file, defaultData] of Object.entries(defaultFiles)) {
        try {
            await fs.access(file);
            existingFiles.push(path.basename(file));
            
            if (file === usersFile) {
                const existingUsers = await readData(usersFile);
                const adminUser = existingUsers.find(u => u.email === 'admin@islandtimebvi.com');
                
                if (adminUser) {
                    const testPassword = await bcrypt.compare('admin123', adminUser.password);
                    if (!testPassword) {
                        adminUser.password = adminHashedPassword;
                        await writeData(usersFile, existingUsers);
                    }
                }
            }
        } catch {
            await fs.writeFile(file, JSON.stringify(defaultData, null, 2));
            createdFiles.push(path.basename(file));
        }
    }

    if (createdFiles.length > 0) {
        console.log(`📁 Created data files: ${createdFiles.join(', ')}`);
    }
    
    if (createdFiles.length > 0 || existingFiles.length === 0) {
        console.log('🔐 Admin user verified and ready');
    }
}

// ==========================================
// USER ACCOUNT FIXER (HANDLES ALL 5 ACCOUNTS)
// ==========================================
async function fixUserPasswords() {
    try {
        const users = await readData(usersFile);
        let fixed = false;

        // Define the Master Accounts
        const definedAccounts = [
            {
                email: 'admin@islandtimebvi.com',
                password: 'admin123',
                name: 'Admin User',
                role: 'admin',
                accessLevel: 'admin',
                permissions: ['all']
            },
            {
                email: 'content@islandtimeltd.com',
                password: 'content123',
                name: 'Content Creator',
                role: 'staff',
                accessLevel: 'creator',
                permissions: ['manage_content', 'view_content', 'create_content', 'schedule_content', 'social_integration']
            },
            {
                email: 'cars@islandtimeltd.com',
                password: 'cars123',
                name: 'Car Rentals LTD',
                role: 'staff',
                accessLevel: 'car-rental',
                permissions: ['view_car_rentals', 'manage_car_rentals', 'view_fleet', 'manage_fleet', 'create_bookings']
            },
            {
                email: 'boats@islandtimebvi.com',
                password: 'boats123',
                name: 'Boat Rentals',
                role: 'staff',
                accessLevel: 'captain',
                permissions: ['manage_water_taxi', 'manage_boat_rental', 'view_schedule']
            },
            {
                email: 'fleetmanager@islandtimeltd.com',
                password: 'fleet123',
                name: 'Fleet Manager',
                role: 'manager',
                accessLevel: 'fleet_manager',
                permissions: ['view_fleet', 'manage_fleet', 'view_maintenance', 'manage_maintenance', 'view_reports', 'manage_inventory']
            },
            {
                email: 'accounting@islandtimeltd.com',
                password: 'accounting123',
                name: 'Accounting Dept',
                role: 'accountant',
                accessLevel: 'accountant',
                permissions: ['view_financials', 'manage_accounting', 'export_reports', 'manage_quickbooks']
            }
        ];

        // Loop through each required account
        for (const account of definedAccounts) {
            let user = users.find(u => u.email === account.email);

            if (!user) {
                // CREATE IF MISSING
                console.log(`🔧 Creating missing account: ${account.email}`);
                const hashedPassword = await bcrypt.hash(account.password, 10);
                
                // Find next ID
                const maxId = users.length > 0 ? Math.max(...users.map(u => u.id)) : 0;

                users.push({
                    id: maxId + 1,
                    name: account.name,
                    email: account.email,
                    password: hashedPassword,
                    role: account.role,
                    isActive: true,
                    lastLogin: new Date().toISOString(),
                    createdAt: new Date().toISOString(),
                    permissions: account.permissions,
                    accessLevel: account.accessLevel
                });
                fixed = true;
            } else {
                // UPDATE PERMISSIONS & ROLE IF EXIST (Ensures they have the right access)
                if (user.accessLevel !== account.accessLevel || user.role !== account.role) {
                    console.log(`🔧 Updating permissions for: ${account.email}`);
                    user.accessLevel = account.accessLevel;
                    user.role = account.role;
                    user.permissions = account.permissions;
                    fixed = true;
                }
            }
        }

        if (fixed) {
            await writeData(usersFile, users);
            console.log('✅ All system accounts synced.');
        } else {
            console.log('✅ User system healthy.');
        }

    } catch (error) {
        console.error('Error fixing user accounts:', error);
    }
}

async function readData(file) {
    try {
        const data = await fs.readFile(file, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error(`Error reading ${file}:`, error);
        return null;
    }
}

async function writeData(file, data) {
    try {
        await fs.writeFile(file, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error(`Error writing ${file}:`, error);
        return false;
    }
}

function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ success: false, message: 'Access token required' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ success: false, message: 'Invalid or expired token' });
        }
        req.user = user;
        next();
    });
}

function requireRole(roles) {
    return (req, res, next) => {
        if (!roles.includes(req.user.role)) {
            return res.status(403).json({ success: false, message: 'Insufficient permissions' });
        }
        next();
    };
}

io.on('connection', (socket) => {
    console.log('🔌 Client connected to real-time news feed:', socket.id);

    socket.on('join_news_feed', (userId) => {
        socket.join('news_feed');
        console.log(`👤 User ${userId} joined news feed`);
        
        const welcomeNews = {
            action: 'connected',
            message: 'Connected to real-time news feed',
            timestamp: new Date().toISOString()
        };
        socket.emit('news_update', welcomeNews);
    });

    socket.on('leave_news_feed', (userId) => {
        socket.leave('news_feed');
        console.log(`👤 User ${userId} left news feed`);
    });

    socket.on('disconnect', () => {
        console.log('🔌 Client disconnected:', socket.id);
    });
});

function broadcastNewsUpdate(newsItem, action = 'added') {
    io.to('news_feed').emit('news_update', {
        action: action,
        news: newsItem,
        timestamp: new Date().toISOString()
    });
    console.log(`📢 Broadcasted news ${action}: ${newsItem.title}`);
}

function broadcastNewsFeed(news) {
    io.to('news_feed').emit('news_feed', {
        news: news,
        timestamp: new Date().toISOString()
    });
    console.log(`📢 Broadcasted full news feed with ${news.length} articles`);
}

app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'OK', 
        message: 'Island Time BVI Booking API is running',
        timestamp: new Date().toISOString(),
        author: 'Jason I, the Master of None'
    });
});

app.get('/api/services', async (req, res) => {
    try {
        const rates = await readData(ratesFile);
        const boatFleet = await readData(boatFleetFile);
        const carFleet = await readData(carFleetFile);
        
        const availableBoats = boatFleet.filter(boat => boat.status === 'available');
        const availableCars = carFleet.filter(car => car.status === 'available');
        
        res.json({
            success: true,
            data: {
                waterTaxi: rates.waterTaxi,
                boatRental: {
                    ...rates.boatRental,
                    availableBoats: availableBoats
                },
                dayCharter: {
                    ...rates.dayCharter,
                    availableBoats: availableBoats.filter(boat => boat.type.includes('Charter'))
                },
                carRental: {
                    ...rates.carRental,
                    availableCars: availableCars
                }
            }
        });
    } catch (error) {
        console.error('Services error:', error);
        res.status(500).json({ success: false, message: 'Failed to load services' });
    }
});

// ======== CC AUTHORIZATION ENDPOINTS (NEW) ========

// 1. Submit Auth (Public/Customer Endpoint)
app.post('/api/submit-auth', async (req, res) => {
    try {
        const { name, email, amount, dates, cardType, cardNumber, expiry, cvv, zip, signature } = req.body;

        if (!name || !email || !cardNumber || !signature) {
            return res.status(400).json({ success: false, message: 'Missing required fields' });
        }

        const ccAuths = await readData(ccAuthsFile);

        // SECURITY: Mask card number (keep only last 4)
        const last4 = cardNumber.replace(/\D/g, '').slice(-4);
        
        // ENCRYPT THE CARD NUMBER
        const encryptedData = encrypt(cardNumber);

        const newAuth = {
            id: generateId(),
            name,
            email,
            amount: parseFloat(amount),
            dates,
            cardType,
            cardLast4: last4, 
            encryptedData: encryptedData, // Store Encrypted Data
            expiry, 
            billingZip: zip,
            signature, 
            submittedAt: new Date().toISOString(),
            status: 'Authorized', 
            sourceIP: req.ip
        };

        ccAuths.push(newAuth);
        await writeData(ccAuthsFile, ccAuths);

        res.json({ 
            success: true, 
            message: 'Authorization received securely.',
            refId: newAuth.id
        });

    } catch (error) {
        console.error('CC Auth Submit Error:', error);
        res.status(500).json({ success: false, message: 'Submission failed' });
    }
});

// 2. View Auths (Protected Endpoint for Cars Dashboard)
app.get('/api/access/car-rental/cc-auths', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && req.user.role !== 'admin') {
            return res.status(403).json({ success: false, message: 'Access denied' });
        }

        const ccAuths = await readData(ccAuthsFile);
        
        // Remove sensitive encrypted data before sending to list
        const safeData = ccAuths.map(auth => ({
            id: auth.id,
            name: auth.name,
            submittedAt: auth.submittedAt,
            cardType: auth.cardType,
            cardLast4: auth.cardLast4,
            amount: auth.amount,
            signature: auth.signature
        }));

        safeData.sort((a, b) => new Date(b.submittedAt) - new Date(a.submittedAt));

        res.json({ success: true, data: safeData });
    } catch (error) {
        console.error('CC Auth Fetch Error:', error);
        res.status(500).json({ success: false, message: 'Failed to load authorizations' });
    }
});

// 3. Request Reveal PIN
app.post('/api/access/request-reveal-pin', authenticateAccess, async (req, res) => {
    const userEmail = req.user.email;
    const pin = Math.floor(1000 + Math.random() * 9000).toString();
    
    // Store PIN with 5 min expiration
    activePins.set(userEmail, { pin, expires: Date.now() + 300000 });

    console.log('================================================');
    console.log(`🔐 SECURITY ALERT: Reveal PIN for ${userEmail}`);
    console.log(`🔑 PIN CODE: ${pin}`);
    console.log('================================================');

    res.json({ success: true, message: `Security PIN sent to ${userEmail} (Check Server Log)` });
});

// 4. Reveal Card Number
app.post('/api/access/reveal-card', authenticateAccess, async (req, res) => {
    const { authId, pin } = req.body;
    const userEmail = req.user.email;

    const stored = activePins.get(userEmail);
    if (!stored || stored.pin !== pin || Date.now() > stored.expires) {
        return res.status(403).json({ success: false, message: 'Invalid or expired PIN' });
    }

    const ccAuths = await readData(ccAuthsFile);
    const record = ccAuths.find(a => a.id === authId);
    
    if (!record) return res.status(404).json({ success: false, message: 'Record not found' });

    try {
        const fullCardNumber = decrypt(record.encryptedData);
        activePins.delete(userEmail); // One-time use
        
        res.json({ success: true, fullCardNumber });
    } catch (e) {
        res.status(500).json({ success: false, message: 'Decryption failed' });
    }
});

// ======== END CC AUTHORIZATION ENDPOINTS ========
// ======== FIX #2: ADD GET ENDPOINT FOR BOOKINGS ========

// GET endpoint for fetching bookings (used by cars.html backend)
app.get('/api/bookings', authenticateToken, async (req, res) => {
    try {
        const bookings = await readData(bookingsFile);
        
        // Filter to car rentals if requested
        const serviceType = req.query.serviceType;
        let filteredBookings = bookings;
        
        if (serviceType) {
            filteredBookings = bookings.filter(booking => booking.serviceType === serviceType);
        }
        
        // Filter by date if provided
        const startDate = req.query.startDate;
        const endDate = req.query.endDate;
        if (startDate || endDate) {
            filteredBookings = filteredBookings.filter(booking => {
                const bookingDate = new Date(booking.date || booking.startDate || booking.createdAt);
                if (startDate && bookingDate < new Date(startDate)) return false;
                if (endDate && bookingDate > new Date(endDate)) return false;
                return true;
            });
        }
        
        // Sort by date (newest first)
        filteredBookings.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        
        res.json({
            success: true,
            data: filteredBookings,
            count: filteredBookings.length,
            message: `${filteredBookings.length} bookings found`
        });
        
    } catch (error) {
        console.error('Fetch bookings error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch bookings'
        });
    }
});
// Specific endpoint for car rental bookings (used by cars.html)
app.get('/api/access/car-rental/bookings', authenticateAccess, async (req, res) => {
    try {
        // Check if user has car rental permissions
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_car_rentals')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Car rental access required' 
            });
        }

        const bookings = await readData(bookingsFile);
        
        // Filter for car rentals only
        const carBookings = bookings.filter(booking => 
            booking.serviceType === 'car-rental' || 
            booking.carPreference || 
            (booking.metadata && booking.metadata.isCarRental)
        );
        
        // Format for cars.html
        const formattedBookings = carBookings.map(booking => ({
            id: booking.id,
            customerName: booking.customerName,
            customerEmail: booking.customerEmail,
            customerPhone: booking.customerPhone,
            startDate: booking.startDate || booking.date,
            endDate: booking.endDate || booking.startDate || booking.date,
            vehicle: booking.carPreference || 'Unassigned',
            pickup: booking.pickupLocation || 'Nanny Cay',
            dropoff: booking.dropoffLocation || booking.pickupLocation || 'Nanny Cay',
            source: booking.source || 'website',
            status: booking.status || 'pending',
            ccStatus: 'Pending', // Default for new bookings
            notes: booking.specialRequests || '',
            estimatedPrice: booking.estimatedPrice || '$0',
            created: booking.createdAt,
            server_id: booking.id // For cars.html to track
        }));
        
        // Sort by date (newest first)
        formattedBookings.sort((a, b) => new Date(b.created) - new Date(a.created));
        
        res.json({
            success: true,
            data: formattedBookings,
            count: formattedBookings.length,
            message: `${formattedBookings.length} car rental bookings found`
        });
        
    } catch (error) {
        console.error('Car rental bookings fetch error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch car rental bookings'
        });
    }
});
app.post('/api/bookings', async (req, res) => {
    try {
        const {
            serviceType,
            customerName,
            customerEmail,
            customerPhone,
            date,
            passengers,
            specialRequests,
            boatPreference,
            carPreference,
            estimatedPrice,
            fromLocation,
            toLocation,
            pickupLocation,
            dropoffLocation,
            charterLocation,
            restaurant,
            carType,
            carPickup,
            carDropoff,
            startDate,
            endDate,
            carDates
        } = req.body;

        // ✅ ADD THIS DEBUG LOGGING
        console.log('🚗 ========== CAR RENTAL BOOKING RECEIVED ==========');
        console.log('📧 Service Type:', serviceType);
        console.log('👤 Customer:', customerName);
        console.log('📧 Email:', customerEmail);
        console.log('🚗 Car Preference:', carPreference);
        console.log('📅 Start Date:', startDate);
        console.log('📅 End Date:', endDate);
        console.log('💰 Estimated Price:', estimatedPrice);
        console.log('🔍 Is Car Rental:', serviceType === 'car-rental');
        console.log('==================================================');

        if (!serviceType || !customerName || !customerEmail) {
            return res.status(400).json({ 
                success: false, 
                message: 'Missing required fields: serviceType, customerName, customerEmail' 
            });
        }

        const bookings = await readData(bookingsFile);
        
        // ✅ CRITICAL FIX: Calculate the primary date correctly
        // For car rentals, use startDate. For others, use date or today.
        const primaryDate = serviceType === 'car-rental' 
            ? (startDate || date || new Date().toISOString().split('T')[0])
            : (date || new Date().toISOString().split('T')[0]);

        const newBooking = {
            id: generateId(),
            serviceType,
            customerName,
            customerEmail,
            customerPhone: customerPhone || '',
            date: primaryDate,
            passengers: passengers || 1,
            specialRequests: specialRequests || '',
            boatPreference: boatPreference || '',
            carPreference: carPreference || '',
            estimatedPrice: estimatedPrice || 0,
            fromLocation: fromLocation || '',
            toLocation: toLocation || '',
            pickupLocation: pickupLocation || '',
            dropoffLocation: dropoffLocation || '',
            charterLocation: charterLocation || '',
            restaurant: restaurant || '',
            // ADD CAR RENTAL SPECIFIC FIELDS
            // ✅ CAR RENTAL SPECIFIC FIELDS - FIXED LOGIC
            carType: carType || '',
            // ✅ Use submitted startDate, fall back to primaryDate, then today
            startDate: startDate || (serviceType === 'car-rental' ? primaryDate : date || new Date().toISOString().split('T')[0]),
            // ✅ Use submitted endDate, fall back to startDate, then primaryDate, then today
            endDate: endDate || startDate || (serviceType === 'car-rental' ? primaryDate : date || new Date().toISOString().split('T')[0]),
            // ✅ Store the carDates display text
            dates: carDates || (startDate && endDate ? `${startDate} to ${endDate}` : ''),
            
            status: 'pending',
            createdAt: new Date().toISOString(),
            source: 'website',
            // Add source detection
            sourcePage: req.headers.referer || 'direct',
            // Add metadata for car rental ops
            metadata: {
                isCarRental: serviceType === 'car-rental',
                processedByCarPortal: false,
                lastProcessed: null,
                // ✅ Store original dates for debugging
                originalDates: {
                    submittedStart: startDate,
                    submittedEnd: endDate,
                    submittedCarDates: carDates,
                    receivedDate: new Date().toISOString()
                }
            }
        };
        
        bookings.push(newBooking);
        await writeData(bookingsFile, bookings);

        // ✅ IMPROVED DEBUG LOGGING
        console.log('📝 New booking received:', {
            id: newBooking.id,
            serviceType: newBooking.serviceType,
            customerName: newBooking.customerName,
            carPreference: newBooking.carPreference,
            // ✅ Show dates clearly
            dates: {
                primaryDate: newBooking.date,
                startDate: newBooking.startDate,
                endDate: newBooking.endDate,
                displayDates: newBooking.dates
            },
            isCarRental: newBooking.metadata.isCarRental,
            source: newBooking.source,
            timestamp: new Date().toISOString()
        });
        
        res.json({ 
            success: true, 
            message: 'Booking submitted successfully! We will contact you to confirm.',
            data: { 
                bookingId: newBooking.id,
                booking: newBooking
            }
        });
        
    } catch (error) {
        console.error('Booking submission error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Failed to submit booking. Please try again or call us directly.' 
        });
    }
});

app.post('/api/contact', async (req, res) => {
    try {
        const { name, email, phone, message, subject } = req.body;

        if (!name || !email || !message) {
            return res.status(400).json({ 
                success: false, 
                message: 'Name, email, and message are required' 
            });
        }

        const messages = await readData(messagesFile);
        
        const newMessage = {
            id: generateId(),
            name,
            email,
            phone: phone || '',
            subject: subject || 'Website Contact Form',
            message,
            read: false,
            createdAt: new Date().toISOString(),
            type: 'contact'
        };
        
        messages.push(newMessage);
        await writeData(messagesFile, messages);
        
        res.json({ 
            success: true, 
            message: 'Thank you for your message! We will get back to you soon.' 
        });
        
    } catch (error) {
        console.error('Contact form error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Failed to send message. Please try again or call us directly.' 
        });
    }
});

app.post('/api/admin/login', async (req, res) => {
    const { email, password } = req.body;

    console.log('Login attempt:', { email });

    if (!email || !password) {
        return res.status(400).json({ success: false, message: 'Email and password required' });
    }

    try {
        const users = await readData(usersFile);
        console.log('Total users in system:', users.length);
        
        const normalizedEmail = email.toLowerCase().trim();
        const user = users.find(u => u.email.toLowerCase() === normalizedEmail && u.isActive !== false);
        
        if (!user) {
            console.log('User not found or inactive for email:', normalizedEmail);
            return res.status(401).json({ 
                success: false, 
                message: 'Invalid email or password. Please check your credentials.' 
            });
        }

        console.log('Found user:', user.email);
        console.log('Stored password hash:', user.password.substring(0, 20) + '...');
        console.log('Password starts with $2a$ (bcrypt):', user.password.startsWith('$2a$'));

        const passwordValid = await bcrypt.compare(password, user.password);
        console.log('Password validation result:', passwordValid);

        if (!passwordValid) {
            console.log('Invalid password for user:', user.email);
            return res.status(401).json({ 
                success: false, 
                message: 'Invalid email or password. Please check your credentials.' 
            });
        }

        user.lastLogin = new Date().toISOString();
        await writeData(usersFile, users);

        const token = jwt.sign(
            { 
                id: user.id, 
                email: user.email, 
                role: user.role,
                name: user.name
            },
            JWT_SECRET,
            { expiresIn: '24h' }
        );

        console.log('Login successful for user:', user.email);
        console.log('Token generated successfully');

        res.json({
            success: true,
            message: 'Login successful',
            data: {
                user: {
                    id: user.id,
                    name: user.name,
                    email: user.email,
                    role: user.role
                },
                token
            }
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Server error during login. Please try again.' 
        });
    }
});

app.get('/api/admin/dashboard-stats', authenticateToken, async (req, res) => {
    try {
        const bookings = await readData(bookingsFile);
        const carFleet = await readData(carFleetFile);
        const boatFleet = await readData(boatFleetFile);
        const todos = await readData(todosFile);

        const today = new Date().toISOString().split('T')[0];
        const todayBookings = bookings.filter(booking => booking.date === today);
        const activeBoats = boatFleet.filter(boat => boat.status === 'available' || boat.status === 'chartered').length;
        const revenueToday = todayBookings.reduce((sum, booking) => sum + (parseFloat(booking.estimatedPrice) || 0), 0);
        const userTodos = todos.filter(todo => todo.assignedTo === req.user.id && !todo.completed);

        const availableCars = carFleet.filter(car => car.status === 'available');
        const availableBoats = boatFleet.filter(boat => boat.status === 'available');

        res.json({
            success: true,
            data: {
                todayBookings: todayBookings.length,
                activeBoats,
                revenueToday,
                pendingActions: userTodos.length,
                carFleet: {
                    total: carFleet.length,
                    available: availableCars.length,
                    rented: carFleet.filter(car => car.status === 'rented').length,
                    maintenance: carFleet.filter(car => car.status === 'maintenance').length
                },
                boatFleet: {
                    total: boatFleet.length,
                    available: availableBoats.length,
                    chartered: boatFleet.filter(boat => boat.status === 'chartered').length,
                    maintenance: boatFleet.filter(boat => boat.status === 'maintenance').length
                }
            }
        });
    } catch (error) {
        console.error('Dashboard stats error:', error);
        res.status(500).json({ success: false, message: 'Failed to load dashboard statistics' });
    }
});

// ======== ACCESS PORTAL ENDPOINTS ========

// Access Portal Login - FIXED VERSION
app.post('/api/access/login', async (req, res) => {
    const { email, password } = req.body;

    console.log('Access portal login attempt:', { email });

    if (!email || !password) {
        return res.status(400).json({ success: false, message: 'Email and password required' });
    }

    try {
        const users = await readData(usersFile);
        console.log('Total users in system:', users.length);
        
        const normalizedEmail = email.toLowerCase().trim();
        
        // Find user - allow ALL users with isActive = true
        const user = users.find(u => 
            u.email.toLowerCase() === normalizedEmail && 
            u.isActive !== false
        );
        
        if (!user) {
            console.log('User not found or inactive for email:', normalizedEmail);
            console.log('Available users:', users.map(u => ({ 
                email: u.email, 
                role: u.role, 
                accessLevel: u.accessLevel,
                isActive: u.isActive 
            })));
            return res.status(401).json({ 
                success: false, 
                message: 'Invalid email or password' 
            });
        }

        console.log('Found user:', user.email);
        console.log('User role:', user.role);
        console.log('User access level:', user.accessLevel);
        console.log('User permissions:', user.permissions);
        console.log('Password starts with $2a$ (bcrypt):', user.password.startsWith('$2a$'));

        // Debug: Check password
        console.log('Testing password validation...');
        const passwordValid = await bcrypt.compare(password, user.password);
        console.log('Password validation result:', passwordValid);

        if (!passwordValid) {
            console.log('Invalid password for user:', user.email);
            return res.status(401).json({ 
                success: false, 
                message: 'Invalid email or password' 
            });
        }

        // Update last login
        user.lastLogin = new Date().toISOString();
        await writeData(usersFile, users);

        // Create JWT token with user info
        const tokenPayload = {
            id: user.id, 
            email: user.email, 
            role: user.role, 
            name: user.name,
            accessLevel: user.accessLevel || 'staff',
            permissions: user.permissions || []
        };
        
        console.log('Creating JWT with payload:', tokenPayload);
        
        const token = jwt.sign(
            tokenPayload,
            JWT_SECRET,
            { expiresIn: '12h' }
        );

        console.log('Access portal login successful for user:', user.email);
        console.log('Generated token (first 20 chars):', token.substring(0, 20) + '...');

        res.json({
            success: true,
            message: 'Access granted',
            data: {
                user: {
                    id: user.id,
                    name: user.name,
                    email: user.email,
                    role: user.role
                },
                permissions: user.permissions || [],
                accessLevel: user.accessLevel || 'staff',
                token
            }
        });
    } catch (error) {
        console.error('Access portal login error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Server error during login: ' + error.message 
        });
    }
});

// Access Portal Authentication Middleware - FIXED VERSION
function authenticateAccess(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    console.log('🔐 Access portal auth check - Token present:', !!token);
    console.log('Authorization header:', authHeader);

    if (!token) {
        console.log('❌ No token provided');
        return res.status(401).json({ success: false, message: 'Access token required' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            console.log('❌ Token verification failed:', err.message);
            return res.status(403).json({ success: false, message: 'Invalid or expired access token' });
        }
        
        console.log('✅ Token verified successfully');
        console.log('User from token:', {
            id: user.id,
            email: user.email,
            accessLevel: user.accessLevel,
            permissions: user.permissions
        });
        
        // Allow ALL authenticated users (removed restrictive accessLevel check)
        req.user = user;
        next();
    });
}

// Access Portal Dashboard Stats
app.get('/api/access/dashboard/stats', authenticateAccess, async (req, res) => {
    try {
        const bookings = await readData(bookingsFile);
        const boatFleet = await readData(boatFleetFile);
        const todos = await readData(todosFile);
        const carFleet = await readData(carFleetFile);

        const today = new Date().toISOString().split('T')[0];
        
        // Base stats for all access levels
        const baseStats = {
            myTasks: 0,
            upcoming: 0,
            todayBookings: 0,
            availableBoats: 0
        };

        // User-specific tasks
        const userTodos = todos.filter(todo => todo.assignedTo === req.user.id && !todo.completed);
        baseStats.myTasks = userTodos.length;

        // Today's bookings (filtered by access level)
        const todayBookings = bookings.filter(booking => booking.date === today);
        baseStats.todayBookings = todayBookings.length;
        baseStats.upcoming = todayBookings.length;

        // Available boats
        const availableBoats = boatFleet.filter(boat => boat.status === 'available');
        baseStats.availableBoats = availableBoats.length;

        // Add access-level specific stats
        if (req.user.accessLevel === 'frontdesk' || req.user.permissions.includes('view_bookings')) {
            const pendingBookings = bookings.filter(booking => booking.status === 'pending');
            baseStats.pendingBookings = pendingBookings.length;
        }

        if (req.user.accessLevel === 'crew' || req.user.permissions.includes('view_fleet')) {
            const boatsInMaintenance = boatFleet.filter(boat => boat.status === 'maintenance');
            baseStats.boatsInMaintenance = boatsInMaintenance.length;
        }

        if (req.user.accessLevel === 'captain' || req.user.permissions.includes('manage_water_taxi')) {
            const activeCharters = bookings.filter(booking => 
                booking.serviceType === 'day-charter' && 
                booking.status === 'confirmed'
            );
            baseStats.activeCharters = activeCharters.length;
        }

        // Content creator specific stats
        if (req.user.accessLevel === 'creator' || req.user.permissions.includes('manage_content')) {
            const contentPlans = await readData(contentPlansFile);
            const notes = await readData(creatorNotesFile);
            
            baseStats.scheduledPosts = contentPlans.filter(c => c.status === 'scheduled').length;
            baseStats.publishedWeek = contentPlans.filter(c => 
                c.status === 'published' && 
                new Date(c.scheduleDate) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
            ).length;
            baseStats.engagementRate = '4.2%';
            baseStats.pendingApprovals = contentPlans.filter(c => c.status === 'pending_review').length;
            baseStats.totalNotes = notes.filter(n => n.createdBy === req.user.id).length;
        }

        res.json({
            success: true,
            data: baseStats
        });
    } catch (error) {
        console.error('Access dashboard stats error:', error);
        res.status(500).json({ success: false, message: 'Failed to load dashboard statistics' });
    }
});

// Access Portal - Today's Bookings (filtered by permissions)
app.get('/api/access/bookings/today', authenticateAccess, async (req, res) => {
    try {
        const bookings = await readData(bookingsFile);
        const today = new Date().toISOString().split('T')[0];
        
        let todayBookings = bookings.filter(booking => booking.date === today);

        // Filter based on access level
        if (req.user.accessLevel === 'crew' && !req.user.permissions.includes('view_all_bookings')) {
            // Crew can only see bookings they're assigned to
            todayBookings = todayBookings.filter(booking => 
                booking.assignedCrew && booking.assignedCrew.includes(req.user.id)
            );
        }

        // Limit sensitive information based on access level
        const safeBookings = todayBookings.map(booking => ({
            id: booking.id,
            customerName: booking.customerName,
            serviceType: booking.serviceType,
            time: booking.time || '09:00',
            status: booking.status,
            passengers: booking.passengers || 1,
            // Only include contact info for frontdesk/managers
            ...((req.user.accessLevel === 'frontdesk' || req.user.accessLevel === 'manager' || req.user.permissions.includes('view_customer_details')) && {
                customerEmail: booking.customerEmail,
                customerPhone: booking.customerPhone
            })
        }));

        res.json({
            success: true,
            data: safeBookings
        });
    } catch (error) {
        console.error('Error loading today\'s bookings for access portal:', error);
        res.status(500).json({ success: false, message: 'Failed to load today\'s bookings' });
    }
});

// Access Portal - Fleet Status
app.get('/api/access/fleet/status', authenticateAccess, async (req, res) => {
    try {
        const boatFleet = await readData(boatFleetFile);
        const carFleet = await readData(carFleetFile);

        // Basic fleet status available to all access levels
        const fleetStatus = {
            boats: {
                total: boatFleet.length,
                available: boatFleet.filter(boat => boat.status === 'available').length,
                inUse: boatFleet.filter(boat => boat.status === 'chartered' || boat.status === 'rented').length,
                maintenance: boatFleet.filter(boat => boat.status === 'maintenance').length
            },
            cars: {
                total: carFleet.length,
                available: carFleet.filter(car => car.status === 'available').length,
                rented: carFleet.filter(car => car.status === 'rented').length,
                maintenance: carFleet.filter(car => car.status === 'maintenance').length
            }
        };

        // Add detailed info for crew/captain access
        if (req.user.accessLevel === 'crew' || req.user.accessLevel === 'captain' || req.user.permissions.includes('view_fleet_details')) {
            fleetStatus.boatDetails = boatFleet.map(boat => ({
                id: boat.id,
                name: boat.name,
                type: boat.type,
                status: boat.status,
                location: boat.location,
                capacity: boat.capacity
            }));

            fleetStatus.carDetails = carFleet.map(car => ({
                id: car.id,
                name: car.name,
                type: car.type,
                status: car.status,
                location: car.location
            }));
        }

        res.json({
            success: true,
            data: fleetStatus
        });
    } catch (error) {
        console.error('Error loading fleet status for access portal:', error);
        res.status(500).json({ success: false, message: 'Failed to load fleet status' });
    }
});

// Access Portal - User's Tasks
app.get('/api/access/tasks', authenticateAccess, async (req, res) => {
    try {
        const todos = await readData(todosFile);
        const userTasks = todos.filter(todo => 
            todo.assignedTo === req.user.id && 
            !todo.completed
        );

        res.json({
            success: true,
            data: userTasks
        });
    } catch (error) {
        console.error('Error loading user tasks:', error);
        res.status(500).json({ success: false, message: 'Failed to load tasks' });
    }
});

// Access Portal - Complete Task
app.put('/api/access/tasks/:id/complete', authenticateAccess, async (req, res) => {
    try {
        const { id } = req.params;
        const todos = await readData(todosFile);
        
        const todoIndex = todos.findIndex(todo => todo.id === id && todo.assignedTo === req.user.id);
        if (todoIndex === -1) {
            return res.status(404).json({ success: false, message: 'Task not found' });
        }
        
        todos[todoIndex].completed = true;
        todos[todoIndex].completedAt = new Date().toISOString();
        todos[todoIndex].completedBy = req.user.id;
        
        await writeData(todosFile, todos);
        
        res.json({ 
            success: true, 
            message: 'Task marked as completed', 
            data: todos[todoIndex] 
        });
    } catch (error) {
        console.error('Error completing task:', error);
        res.status(500).json({ success: false, message: 'Failed to complete task' });
    }
});

// ======== CONTENT CREATOR ENDPOINTS ========

// Content Creator Dashboard
app.get('/api/access/creator/dashboard', authenticateAccess, async (req, res) => {
    try {
        // Check if user is content creator
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_content')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content creator access required' 
            });
        }

        const contentPlans = await readData(contentPlansFile);
        const notes = await readData(creatorNotesFile);
        const reports = await readData(reportsFile);
        const socialConnections = await readData(socialConnectionsFile);
        
        const userContent = contentPlans.filter(c => c.createdBy === req.user.id);
        const userNotes = notes.filter(n => n.createdBy === req.user.id);
        const userReports = reports.filter(r => r.createdBy === req.user.id);

        const stats = {
            scheduledPosts: userContent.filter(c => c.status === 'scheduled').length,
            publishedWeek: userContent.filter(c => 
                c.status === 'published' && 
                new Date(c.scheduleDate) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
            ).length,
            engagementRate: '4.2%',
            pendingApprovals: userContent.filter(c => c.status === 'pending_review').length,
            totalNotes: userNotes.length,
            totalReports: userReports.length,
            socialConnections: {
                facebook: socialConnections.facebook || false,
                instagram: socialConnections.instagram || false
            }
        };

        // Recent content
        const recentContent = userContent
            .sort((a, b) => new Date(b.scheduleDate) - new Date(a.scheduleDate))
            .slice(0, 5);

        // Recent notes
        const recentNotes = userNotes
            .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
            .slice(0, 5);

        res.json({
            success: true,
            data: {
                stats,
                recentContent,
                recentNotes,
                upcomingContent: userContent.filter(c => 
                    c.status === 'scheduled' && 
                    new Date(c.scheduleDate) >= new Date()
                ).slice(0, 3)
            }
        });
    } catch (error) {
        console.error('Content creator dashboard error:', error);
        res.status(500).json({ success: false, message: 'Failed to load content creator dashboard' });
    }
});

// Content Calendar
app.get('/api/access/creator/calendar', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_content')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content creator access required' 
            });
        }

        const { month, year } = req.query;
        const contentPlans = await readData(contentPlansFile);
        
        let userContent = contentPlans.filter(c => c.createdBy === req.user.id);

        // Filter by month/year if specified
        if (month && year) {
            userContent = userContent.filter(content => {
                const contentDate = new Date(content.scheduleDate);
                return contentDate.getMonth() === parseInt(month) && 
                       contentDate.getFullYear() === parseInt(year);
            });
        }

        // Group by day for calendar view
        const calendarData = {};
        userContent.forEach(content => {
            const date = new Date(content.scheduleDate).toISOString().split('T')[0];
            if (!calendarData[date]) {
                calendarData[date] = [];
            }
            calendarData[date].push({
                id: content.id,
                title: content.title,
                type: content.type,
                status: content.status,
                time: new Date(content.scheduleDate).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
                platforms: content.platforms
            });
        });

        res.json({ 
            success: true, 
            data: {
                calendar: calendarData,
                total: userContent.length
            }
        });
    } catch (error) {
        console.error('Content calendar error:', error);
        res.status(500).json({ success: false, message: 'Failed to load content calendar' });
    }
});

// Content Plans Management
app.get('/api/access/creator/content', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_content')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content creator access required' 
            });
        }

        const contentPlans = await readData(contentPlansFile);
        const userContent = contentPlans.filter(c => c.createdBy === req.user.id);

        res.json({ success: true, data: userContent });
    } catch (error) {
        console.error('Content plans error:', error);
        res.status(500).json({ success: false, message: 'Failed to load content plans' });
    }
});

app.post('/api/access/creator/content', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_content')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content creator access required' 
            });
        }

        const contentData = req.body;
        const contentPlans = await readData(contentPlansFile);
        
        const newContent = {
            id: generateId(),
            ...contentData,
            status: contentData.status || 'draft',
            createdBy: req.user.id,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        
        contentPlans.push(newContent);
        await writeData(contentPlansFile, contentPlans);
        
        res.json({ success: true, message: 'Content plan created successfully', data: newContent });
    } catch (error) {
        console.error('Create content error:', error);
        res.status(500).json({ success: false, message: 'Failed to create content plan' });
    }
});

app.put('/api/access/creator/content/:id', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_content')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content creator access required' 
            });
        }

        const { id } = req.params;
        const contentData = req.body;
        const contentPlans = await readData(contentPlansFile);
        
        const contentIndex = contentPlans.findIndex(c => c.id == id && c.createdBy === req.user.id);
        if (contentIndex === -1) {
            return res.status(404).json({ success: false, message: 'Content plan not found' });
        }
        
        const updatedContent = {
            ...contentPlans[contentIndex],
            ...contentData,
            updatedAt: new Date().toISOString()
        };
        
        contentPlans[contentIndex] = updatedContent;
        await writeData(contentPlansFile, contentPlans);
        
        res.json({ success: true, message: 'Content plan updated successfully', data: updatedContent });
    } catch (error) {
        console.error('Update content error:', error);
        res.status(500).json({ success: false, message: 'Failed to update content plan' });
    }
});

app.delete('/api/access/creator/content/:id', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_content')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content creator access required' 
            });
        }

        const { id } = req.params;
        const contentPlans = await readData(contentPlansFile);
        
        const contentIndex = contentPlans.findIndex(c => c.id == id && c.createdBy === req.user.id);
        if (contentIndex === -1) {
            return res.status(404).json({ success: false, message: 'Content plan not found' });
        }
        
        const deletedContent = contentPlans[contentIndex];
        contentPlans.splice(contentIndex, 1);
        await writeData(contentPlansFile, contentPlans);
        
        res.json({ success: true, message: 'Content plan deleted successfully' });
    } catch (error) {
        console.error('Delete content error:', error);
        res.status(500).json({ success: false, message: 'Failed to delete content plan' });
    }
});

// Notes Management
app.get('/api/access/creator/notes', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_notes')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content creator access required' 
            });
        }

        const notes = await readData(creatorNotesFile);
        const userNotes = notes.filter(n => n.createdBy === req.user.id);
        
        res.json({ success: true, data: userNotes });
    } catch (error) {
        console.error('Notes error:', error);
        res.status(500).json({ success: false, message: 'Failed to load notes' });
    }
});

app.post('/api/access/creator/notes', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_notes')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content creator access required' 
            });
        }

        const noteData = req.body;
        const notes = await readData(creatorNotesFile);
        
        const newNote = {
            id: generateId(),
            ...noteData,
            createdBy: req.user.id,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        
        notes.push(newNote);
        await writeData(creatorNotesFile, notes);
        
        res.json({ success: true, message: 'Note created successfully', data: newNote });
    } catch (error) {
        console.error('Create note error:', error);
        res.status(500).json({ success: false, message: 'Failed to create note' });
    }
});

app.put('/api/access/creator/notes/:id', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_notes')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content creator access required' 
            });
        }

        const { id } = req.params;
        const noteData = req.body;
        const notes = await readData(creatorNotesFile);
        
        const noteIndex = notes.findIndex(n => n.id == id && n.createdBy === req.user.id);
        if (noteIndex === -1) {
            return res.status(404).json({ success: false, message: 'Note not found' });
        }
        
        const updatedNote = {
            ...notes[noteIndex],
            ...noteData,
            updatedAt: new Date().toISOString()
        };
        
        notes[noteIndex] = updatedNote;
        await writeData(creatorNotesFile, notes);
        
        res.json({ success: true, message: 'Note updated successfully', data: updatedNote });
    } catch (error) {
        console.error('Update note error:', error);
        res.status(500).json({ success: false, message: 'Failed to update note' });
    }
});

app.delete('/api/access/creator/notes/:id', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_notes')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content creator access required' 
            });
        }

        const { id } = req.params;
        const notes = await readData(creatorNotesFile);
        
        const noteIndex = notes.findIndex(n => n.id == id && n.createdBy === req.user.id);
        if (noteIndex === -1) {
            return res.status(404).json({ success: false, message: 'Note not found' });
        }
        
        notes.splice(noteIndex, 1);
        await writeData(creatorNotesFile, notes);
        
        res.json({ success: true, message: 'Note deleted successfully' });
    } catch (error) {
        console.error('Delete note error:', error);
        res.status(500).json({ success: false, message: 'Failed to delete note' });
    }
});

// Content Ideas
app.get('/api/access/creator/ideas', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_content')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content creator access required' 
            });
        }

        const ideas = await readData(contentIdeasFile);
        const userIdeas = ideas.filter(i => i.createdBy === req.user.id);
        
        res.json({ success: true, data: userIdeas });
    } catch (error) {
        console.error('Content ideas error:', error);
        res.status(500).json({ success: false, message: 'Failed to load content ideas' });
    }
});

app.post('/api/access/creator/ideas', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_content')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content creator access required' 
            });
        }

        const ideaData = req.body;
        const ideas = await readData(contentIdeasFile);
        
        const newIdea = {
            id: generateId(),
            ...ideaData,
            status: 'pending',
            createdBy: req.user.id,
            createdAt: new Date().toISOString()
        };
        
        ideas.push(newIdea);
        await writeData(contentIdeasFile, ideas);
        
        res.json({ success: true, message: 'Content idea added successfully', data: newIdea });
    } catch (error) {
        console.error('Create idea error:', error);
        res.status(500).json({ success: false, message: 'Failed to add content idea' });
    }
});

// Social Media Integration
app.get('/api/access/creator/social', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('social_integration')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Social integration access required' 
            });
        }

        const socialConnections = await readData(socialConnectionsFile);
        
        res.json({ 
            success: true, 
            data: {
                connections: socialConnections,
                stats: {
                    facebookFollowers: 1250,
                    instagramFollowers: 2850,
                    engagementRate: '4.2%',
                    growthRate: '+12.5%'
                }
            }
        });
    } catch (error) {
        console.error('Social integration error:', error);
        res.status(500).json({ success: false, message: 'Failed to load social integration data' });
    }
});

app.post('/api/access/creator/social/connect', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('social_integration')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Social integration access required' 
            });
        }

        const { platform } = req.body;
        const socialConnections = await readData(socialConnectionsFile);
        
        if (platform === 'facebook' || platform === 'instagram') {
            socialConnections[platform] = true;
            socialConnections.lastUpdated = new Date().toISOString();
            
            await writeData(socialConnectionsFile, socialConnections);
            
            res.json({ 
                success: true, 
                message: `${platform} connected successfully`,
                data: socialConnections
            });
        } else {
            res.status(400).json({ success: false, message: 'Invalid platform' });
        }
    } catch (error) {
        console.error('Social connect error:', error);
        res.status(500).json({ success: false, message: 'Failed to connect social platform' });
    }
});

// Reports
app.get('/api/access/creator/reports', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('view_reports')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Report access required' 
            });
        }

        const reports = await readData(reportsFile);
        const userReports = reports.filter(r => r.createdBy === req.user.id);
        
        res.json({ success: true, data: userReports });
    } catch (error) {
        console.error('Reports error:', error);
        res.status(500).json({ success: false, message: 'Failed to load reports' });
    }
});

app.post('/api/access/creator/reports', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('create_reports')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Report creation access required' 
            });
        }

        const reportData = req.body;
        const reports = await readData(reportsFile);
        
        const newReport = {
            id: generateId(),
            ...reportData,
            generatedAt: new Date().toISOString(),
            createdBy: req.user.id
        };
        
        reports.push(newReport);
        await writeData(reportsFile, reports);
        
        res.json({ success: true, message: 'Report generated successfully', data: newReport });
    } catch (error) {
        console.error('Create report error:', error);
        res.status(500).json({ success: false, message: 'Failed to generate report' });
    }
});

// ======== END CONTENT CREATOR ENDPOINTS ========

// ======== NEW CONTENT MANAGEMENT ENDPOINTS ========

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadDir = path.join(__dirname, 'uploads/content');
        // Create directory if it doesn't exist
        fs.mkdir(uploadDir, { recursive: true }, (err) => {
            if (err) {
                console.error('Error creating upload directory:', err);
            }
        });
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({ 
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
    fileFilter: function (req, file, cb) {
        const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'video/mp4', 'video/quicktime', 'application/pdf'];
        if (allowedTypes.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error('Invalid file type. Only images, videos, and PDFs are allowed.'));
        }
    }
});

// Content management endpoints
app.post('/api/content/upload', authenticateAccess, upload.single('file'), async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_content')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content creator access required' 
            });
        }

        if (!req.file) {
            return res.status(400).json({ 
                success: false, 
                message: 'No file uploaded' 
            });
        }

        const files = await readData(filesFile);
        
        const newFile = {
            id: generateId(),
            filename: req.file.filename,
            originalname: req.file.originalname,
            mimetype: req.file.mimetype,
            size: req.file.size,
            path: `/uploads/content/${req.file.filename}`,
            uploadedBy: req.user.id,
            uploadedAt: new Date().toISOString(),
            category: 'content',
            metadata: {
                title: req.body.title || req.file.originalname,
                description: req.body.description || '',
                tags: req.body.tags ? req.body.tags.split(',') : []
            }
        };
        
        files.push(newFile);
        await writeData(filesFile, files);
        
        res.json({
            success: true,
            message: 'File uploaded successfully',
            data: {
                file: newFile,
                url: `http://localhost:${PORT}${newFile.path}`
            }
        });
    } catch (error) {
        console.error('File upload error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Failed to upload file: ' + error.message 
        });
    }
});

app.get('/api/content', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('view_content')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content access required' 
            });
        }

        const { type, status, platform, startDate, endDate } = req.query;
        const contentPlans = await readData(contentPlansFile);
        
        let content = contentPlans.filter(c => c.createdBy === req.user.id);
        
        // Apply filters
        if (type) {
            content = content.filter(c => c.type === type);
        }
        
        if (status) {
            content = content.filter(c => c.status === status);
        }
        
        if (platform) {
            content = content.filter(c => c.platforms && c.platforms.includes(platform));
        }
        
        if (startDate) {
            content = content.filter(c => new Date(c.scheduleDate) >= new Date(startDate));
        }
        
        if (endDate) {
            content = content.filter(c => new Date(c.scheduleDate) <= new Date(endDate));
        }
        
        // Sort by schedule date (newest first)
        content.sort((a, b) => new Date(b.scheduleDate) - new Date(a.scheduleDate));
        
        res.json({ 
            success: true, 
            data: content,
            pagination: {
                total: content.length,
                page: 1,
                limit: content.length
            }
        });
    } catch (error) {
        console.error('Get content error:', error);
        res.status(500).json({ success: false, message: 'Failed to load content' });
    }
});

app.post('/api/content', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('create_content')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content creation access required' 
            });
        }

        const contentData = req.body;
        const contentPlans = await readData(contentPlansFile);
        const contentCalendar = await readData(contentCalendarFile);
        
        // Validate required fields
        if (!contentData.title || !contentData.type) {
            return res.status(400).json({ 
                success: false, 
                message: 'Title and type are required' 
            });
        }
        
        const newContent = {
            id: generateId(),
            title: contentData.title,
            type: contentData.type,
            description: contentData.description || '',
            content: contentData.content || '',
            platforms: contentData.platforms || ['instagram'],
            status: contentData.status || 'draft',
            scheduleDate: contentData.scheduleDate || new Date().toISOString(),
            tags: contentData.tags || [],
            attachments: contentData.attachments || [],
            analytics: {
                impressions: 0,
                engagement: 0,
                clicks: 0,
                shares: 0
            },
            createdBy: req.user.id,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            publishedDate: contentData.status === 'published' ? new Date().toISOString() : null
        };
        
        contentPlans.push(newContent);
        await writeData(contentPlansFile, contentPlans);
        
        // If scheduled, add to content calendar
        if (newContent.status === 'scheduled' && newContent.scheduleDate) {
            const calendarEvent = {
                id: generateId(),
                contentId: newContent.id,
                title: newContent.title,
                type: newContent.type,
                platforms: newContent.platforms,
                date: newContent.scheduleDate.split('T')[0],
                time: new Date(newContent.scheduleDate).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
                status: 'scheduled',
                createdBy: req.user.id,
                createdAt: new Date().toISOString()
            };
            
            contentCalendar.push(calendarEvent);
            await writeData(contentCalendarFile, contentCalendar);
        }
        
        res.json({ 
            success: true, 
            message: 'Content created successfully', 
            data: newContent 
        });
    } catch (error) {
        console.error('Create content error:', error);
        res.status(500).json({ success: false, message: 'Failed to create content' });
    }
});

app.put('/api/content/:id', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_content')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content management access required' 
            });
        }

        const { id } = req.params;
        const contentData = req.body;
        const contentPlans = await readData(contentPlansFile);
        const contentCalendar = await readData(contentCalendarFile);
        
        const contentIndex = contentPlans.findIndex(c => c.id == id && c.createdBy === req.user.id);
        if (contentIndex === -1) {
            return res.status(404).json({ success: false, message: 'Content not found' });
        }
        
        const contentToUpdate = contentPlans[contentIndex];
        const previousStatus = contentToUpdate.status;
        const previousScheduleDate = contentToUpdate.scheduleDate;
        
        const updatedContent = {
            ...contentToUpdate,
            ...contentData,
            updatedAt: new Date().toISOString()
        };
        
        // Update published date if status changed to published
        if (previousStatus !== 'published' && contentData.status === 'published') {
            updatedContent.publishedDate = new Date().toISOString();
        }
        
        contentPlans[contentIndex] = updatedContent;
        await writeData(contentPlansFile, contentPlans);
        
        // Update content calendar if schedule date or status changed
        const calendarIndex = contentCalendar.findIndex(event => event.contentId == id);
        if (calendarIndex !== -1) {
            if (contentData.status === 'scheduled' && contentData.scheduleDate) {
                contentCalendar[calendarIndex] = {
                    ...contentCalendar[calendarIndex],
                    title: updatedContent.title,
                    type: updatedContent.type,
                    platforms: updatedContent.platforms,
                    date: updatedContent.scheduleDate.split('T')[0],
                    time: new Date(updatedContent.scheduleDate).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
                    status: 'scheduled',
                    updatedAt: new Date().toISOString()
                };
            } else if (contentData.status === 'published') {
                contentCalendar[calendarIndex].status = 'published';
                contentCalendar[calendarIndex].updatedAt = new Date().toISOString();
            } else if (contentData.status === 'draft' || contentData.status === 'cancelled') {
                // Remove from calendar if no longer scheduled
                contentCalendar.splice(calendarIndex, 1);
            }
        } else if (contentData.status === 'scheduled' && contentData.scheduleDate) {
            // Add to calendar if newly scheduled
            const calendarEvent = {
                id: generateId(),
                contentId: updatedContent.id,
                title: updatedContent.title,
                type: updatedContent.type,
                platforms: updatedContent.platforms,
                date: updatedContent.scheduleDate.split('T')[0],
                time: new Date(updatedContent.scheduleDate).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
                status: 'scheduled',
                createdBy: req.user.id,
                createdAt: new Date().toISOString()
            };
            contentCalendar.push(calendarEvent);
        }
        
        await writeData(contentCalendarFile, contentCalendar);
        
        res.json({ 
            success: true, 
            message: 'Content updated successfully', 
            data: updatedContent 
        });
    } catch (error) {
        console.error('Update content error:', error);
        res.status(500).json({ success: false, message: 'Failed to update content' });
    }
});

app.delete('/api/content/:id', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_content')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Content management access required' 
            });
        }

        const { id } = req.params;
        const contentPlans = await readData(contentPlansFile);
        const contentCalendar = await readData(contentCalendarFile);
        
        const contentIndex = contentPlans.findIndex(c => c.id == id && c.createdBy === req.user.id);
        if (contentIndex === -1) {
            return res.status(404).json({ success: false, message: 'Content not found' });
        }
        
        const deletedContent = contentPlans[contentIndex];
        
        // Don't allow deletion of published content
        if (deletedContent.status === 'published') {
            return res.status(400).json({ 
                success: false, 
                message: 'Cannot delete published content. Archive it instead.' 
            });
        }
        
        contentPlans.splice(contentIndex, 1);
        await writeData(contentPlansFile, contentPlans);
        
        // Remove from calendar if exists
        const calendarIndex = contentCalendar.findIndex(event => event.contentId == id);
        if (calendarIndex !== -1) {
            contentCalendar.splice(calendarIndex, 1);
            await writeData(contentCalendarFile, contentCalendar);
        }
        
        res.json({ 
            success: true, 
            message: 'Content deleted successfully',
            data: { id: deletedContent.id, title: deletedContent.title }
        });
    } catch (error) {
        console.error('Delete content error:', error);
        res.status(500).json({ success: false, message: 'Failed to delete content' });
    }
});

// ======== SOCIAL MEDIA INTEGRATION ENDPOINTS ========

app.post('/api/social/connect', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('social_integration')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Social integration access required' 
            });
        }

        const { platform, apiKey, apiSecret, accessToken, pageId } = req.body;
        const socialConnections = await readData(socialConnectionsFile);
        
        if (!['facebook', 'instagram', 'twitter', 'linkedin'].includes(platform)) {
            return res.status(400).json({ 
                success: false, 
                message: 'Invalid platform. Supported: facebook, instagram, twitter, linkedin' 
            });
        }
        
        // In a real implementation, you would validate the credentials with the platform's API
        // For this demo, we'll just store them
        
        const connectionData = {
            platform,
            apiKey: apiKey || null,
            apiSecret: apiSecret || null,
            accessToken: accessToken || null,
            pageId: pageId || null,
            connected: true,
            connectedAt: new Date().toISOString(),
            lastTested: new Date().toISOString(),
            connectedBy: req.user.id
        };
        
        // Store connection data
        if (!socialConnections.connections) {
            socialConnections.connections = [];
        }
        
        // Update or add connection
        const existingIndex = socialConnections.connections.findIndex(c => c.platform === platform);
        if (existingIndex !== -1) {
            socialConnections.connections[existingIndex] = connectionData;
        } else {
            socialConnections.connections.push(connectionData);
        }
        
        // Update platform-specific status
        socialConnections[platform] = true;
        socialConnections.lastUpdated = new Date().toISOString();
        
        await writeData(socialConnectionsFile, socialConnections);
        
        res.json({ 
            success: true, 
            message: `${platform.charAt(0).toUpperCase() + platform.slice(1)} connected successfully`,
            data: connectionData
        });
    } catch (error) {
        console.error('Social connect error:', error);
        res.status(500).json({ success: false, message: 'Failed to connect social platform' });
    }
});

// ======== REAL SOCIAL PUBLISHING LOGIC ========

async function publishToFacebook(connection, content) {
    try {
        console.log(`📱 Attempting to publish to Facebook: ${content.title}`);
        
        // Check if we have required connection data
        if (!connection || !connection.accessToken) {
            console.log('⚠️ Facebook connection missing access token');
            return { 
                success: false, 
                error: 'Facebook not properly connected. Missing access token.' 
            };
        }
        
        // For demo/simulation purposes - in production, you would use the actual Facebook Graph API
        if (process.env.NODE_ENV === 'production' && connection.pageId && connection.accessToken) {
            // Real Facebook API integration would go here
            // const url = `https://graph.facebook.com/${connection.pageId}/feed`;
            // const response = await axios.post(url, null, {
            //     params: {
            //         message: content.description || content.title,
            //         link: content.mediaUrl || 'https://islandtimebvi.com',
            //         access_token: connection.accessToken
            //     }
            // });
            // return { success: true, id: response.data.id };
            
            console.log(`📱 Would publish to Facebook API: ${content.title}`);
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
        
        // For development/demo, return a simulated success
        const postId = `fb_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        console.log(`✅ Simulated Facebook publish: ${content.title} (ID: ${postId})`);
        
        return { 
            success: true, 
            id: postId,
            message: 'Published to Facebook (simulated for demo)',
            note: 'In production, this would use the actual Facebook Graph API'
        };
        
    } catch (error) {
        console.error("❌ Facebook publish error:", error.message);
        return { 
            success: false, 
            error: error.message,
            details: error.response ? error.response.data : null
        };
    }
}

// Endpoint: Triggered when you click "Post Now"
app.post('/api/social/publish', authenticateAccess, async (req, res) => {
    try {
        // 1. Get Data
        const { contentId, platforms, scheduleTime } = req.body;
        const contentPlans = await readData(contentPlansFile);
        const connections = await readData(socialConnectionsFile);
        
        // 2. Find the content
        const index = contentPlans.findIndex(c => c.id == contentId);
        if (index === -1) return res.status(404).json({ success: false, message: 'Content not found' });
        
        const content = contentPlans[index];
        const results = [];

        // 3. IMMEDIATE POSTING
        if (!scheduleTime) {
            for (const platform of platforms) {
                // Check if we have credentials stored in socialConnections.json
                const connection = connections.connections?.find(c => c.platform === platform);
                
                if (platform === 'facebook' && connection) {
                    const result = await publishToFacebook(connection, content);
                    results.push({ platform, ...result });
                } else {
                    // Mock success for other platforms if no API key present (to prevent crashing)
                    console.log(`⚠️ Simulating post to ${platform} (No API Token found in socialConnections.json)`);
                    results.push({ platform, success: true, id: 'simulated_id', note: 'Simulated - Add API Token to Server' });
                }
            }
            
            content.status = 'published';
            content.publishedDate = new Date().toISOString();
        } 
        // 4. SCHEDULING
        else {
            content.status = 'scheduled';
            content.scheduleDate = scheduleTime;
            console.log(`⏰ Content scheduled for ${scheduleTime}`);
        }

        // 5. Save Changes
        contentPlans[index] = content;
        await writeData(contentPlansFile, contentPlans);

        res.json({ success: true, data: content, results });

    } catch (error) {
        console.error('Publish error:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// ======== BACKGROUND SCHEDULER (HOOTSUITE STYLE) ========
function setupSocialCron() {
    console.log('⏰ Social media scheduler initialized');
    // Check for scheduled posts every minute
    setInterval(async () => {
        try {
            console.log('⏰ Checking for scheduled social posts...');
            const contentPlans = await readData(contentPlansFile);
            const connections = await readData(socialConnectionsFile);
            const now = new Date();
            let changed = false;

            for (let content of contentPlans) {
                // If content is Scheduled AND the time has passed
                if (content.status === 'scheduled' && 
                    content.scheduleDate && 
                    new Date(content.scheduleDate) <= now) {
                    
                    console.log(`🚀 Auto-Posting: ${content.title}`);
                    
                    // Attempt to post to Facebook if selected
                    if (content.platforms && content.platforms.includes('facebook')) {
                        const conn = connections.connections?.find(c => c.platform === 'facebook');
                        if (conn) {
                            try {
                                const result = await publishToFacebook(conn, content);
                                if (result.success) {
                                    content.status = 'published';
                                    content.publishedDate = now.toISOString();
                                    content.publishedResults = content.publishedResults || [];
                                    content.publishedResults.push({
                                        platform: 'facebook',
                                        publishedAt: now.toISOString(),
                                        postId: result.id
                                    });
                                    changed = true;
                                    console.log(`✅ Published to Facebook: ${content.title}`);
                                }
                            } catch (error) {
                                console.error(`❌ Failed to publish to Facebook: ${error.message}`);
                            }
                        }
                    }
                    
                    // Add other platforms here (Instagram, Twitter, etc.)
                }
            }

            if (changed) {
                await writeData(contentPlansFile, contentPlans);
                console.log(`✅ Updated ${changed} published posts`);
            }
        } catch (error) {
            console.error('Social cron error:', error);
        }
    }, 60000); // Check every minute
}

// CALL THIS IN startServer()
// setupSocialCron();
// ======== NOTES ENDPOINTS ============= NOTES ENDPOINTS ========

app.get('/api/notes', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_notes')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Notes access required' 
            });
        }

        const { category, search, archived } = req.query;
        const notes = await readData(creatorNotesFile);
        
        let userNotes = notes.filter(n => n.createdBy === req.user.id);
        
        // Apply filters
        if (category) {
            userNotes = userNotes.filter(n => n.category === category);
        }
        
        if (search) {
            const searchLower = search.toLowerCase();
            userNotes = userNotes.filter(n => 
                n.title.toLowerCase().includes(searchLower) || 
                n.content.toLowerCase().includes(searchLower)
            );
        }
        
        if (archived === 'true') {
            userNotes = userNotes.filter(n => n.archived === true);
        } else if (archived === 'false') {
            userNotes = userNotes.filter(n => !n.archived);
        }
        
        // Sort by update date (newest first)
        userNotes.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
        
        res.json({ 
            success: true, 
            data: userNotes,
            total: userNotes.length
        });
    } catch (error) {
        console.error('Get notes error:', error);
        res.status(500).json({ success: false, message: 'Failed to load notes' });
    }
});

app.post('/api/notes', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_notes')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Notes creation access required' 
            });
        }

        const noteData = req.body;
        const notes = await readData(creatorNotesFile);
        
        // Validate required fields
        if (!noteData.title) {
            return res.status(400).json({ 
                success: false, 
                message: 'Title is required' 
            });
        }
        
        const newNote = {
            id: generateId(),
            title: noteData.title,
            content: noteData.content || '',
            category: noteData.category || 'general',
            tags: noteData.tags || [],
            pinned: noteData.pinned || false,
            archived: false,
            createdBy: req.user.id,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            lastEditedBy: req.user.id,
            attachments: noteData.attachments || []
        };
        
        notes.push(newNote);
        await writeData(creatorNotesFile, notes);
        
        res.json({ 
            success: true, 
            message: 'Note created successfully', 
            data: newNote 
        });
    } catch (error) {
        console.error('Create note error:', error);
        res.status(500).json({ success: false, message: 'Failed to create note' });
    }
});

// Note: The PUT and DELETE endpoints for notes already exist in your content creator endpoints
// They are at /api/access/creator/notes/:id

// ======== EMAIL ENDPOINTS ========

// Note: For email functionality, you would typically use an email service like SendGrid, Mailgun, etc.
// This is a simplified version that stores email drafts and tracks sent emails

app.post('/api/email/send', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_content')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Email access required' 
            });
        }

        const { to, subject, body, templateId, scheduleTime } = req.body;
        
        if (!to || !subject || !body) {
            return res.status(400).json({ 
                success: false, 
                message: 'To, subject, and body are required' 
            });
        }
        
        // In a real implementation, you would:
        // 1. Validate email addresses
        // 2. Use an email service to send the email
        // 3. Handle attachments, templates, etc.
        // 4. Track delivery status
        
        // For this demo, we'll simulate sending
        const emailId = `email_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        const emailRecord = {
            id: emailId,
            to: Array.isArray(to) ? to : [to],
            subject,
            body,
            templateId: templateId || null,
            status: scheduleTime ? 'scheduled' : 'sent',
            sentBy: req.user.id,
            sentAt: scheduleTime ? null : new Date().toISOString(),
            scheduledFor: scheduleTime || null,
            createdAt: new Date().toISOString(),
            metadata: {
                openCount: 0,
                clickCount: 0,
                bounce: false,
                unsubscribe: false
            }
        };
        
        // In a real app, you would store emails in a database
        // For now, we'll use the newsletters file as a placeholder
        const newsletters = await readData(newslettersFile);
        newsletters.push(emailRecord);
        await writeData(newslettersFile, newsletters);
        
        // Simulate email sending
        const success = Math.random() > 0.1; // 90% success rate for demo
        
        if (success) {
            res.json({
                success: true,
                message: scheduleTime ? 'Email scheduled successfully' : 'Email sent successfully',
                data: {
                    emailId,
                    status: scheduleTime ? 'scheduled' : 'sent',
                    estimatedDelivery: scheduleTime || 'immediate'
                }
            });
        } else {
            res.status(500).json({
                success: false,
                message: 'Failed to send email. Please try again.'
            });
        }
    } catch (error) {
        console.error('Send email error:', error);
        res.status(500).json({ success: false, message: 'Failed to send email' });
    }
});

app.get('/api/emails', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_content')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Email access required' 
            });
        }

        const { status, startDate, endDate, search } = req.query;
        const newsletters = await readData(newslettersFile);
        
        let emails = newsletters.filter(email => email.sentBy === req.user.id);
        
        // Apply filters
        if (status) {
            emails = emails.filter(email => email.status === status);
        }
        
        if (startDate) {
            emails = emails.filter(email => new Date(email.createdAt) >= new Date(startDate));
        }
        
        if (endDate) {
            emails = emails.filter(email => new Date(email.createdAt) <= new Date(endDate));
        }
        
        if (search) {
            const searchLower = search.toLowerCase();
            emails = emails.filter(email => 
                email.subject.toLowerCase().includes(searchLower) ||
                email.body.toLowerCase().includes(searchLower)
            );
        }
        
        // Sort by date (newest first)
        emails.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        
        // Format response
        const formattedEmails = emails.map(email => ({
            id: email.id,
            to: email.to,
            subject: email.subject,
            status: email.status,
            sentAt: email.sentAt,
            scheduledFor: email.scheduledFor,
            createdAt: email.createdAt,
            metadata: email.metadata
        }));
        
        res.json({ 
            success: true, 
            data: formattedEmails,
            total: formattedEmails.length,
            stats: {
                sent: emails.filter(e => e.status === 'sent').length,
                scheduled: emails.filter(e => e.status === 'scheduled').length,
                failed: emails.filter(e => e.status === 'failed').length
            }
        });
    } catch (error) {
        console.error('Get emails error:', error);
        res.status(500).json({ success: false, message: 'Failed to load emails' });
    }
});

// Additional endpoint for email templates
app.get('/api/email/templates', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'creator' && !req.user.permissions.includes('manage_content')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Email access required' 
            });
        }

        // In a real app, you would fetch templates from a database
        // For demo, return some sample templates
        const templates = [
            {
                id: 'welcome',
                name: 'Welcome Email',
                subject: 'Welcome to Island Time BVI!',
                body: 'Welcome {{name}}! Thank you for choosing Island Time BVI...',
                variables: ['name', 'bookingDate', 'serviceType']
            },
            {
                id: 'booking_confirmation',
                name: 'Booking Confirmation',
                subject: 'Booking Confirmation - Island Time BVI',
                body: 'Your booking has been confirmed! Details: {{bookingDetails}}',
                variables: ['bookingDetails', 'date', 'time', 'location']
            },
            {
                id: 'newsletter',
                name: 'Monthly Newsletter',
                subject: 'Island Time BVI - {{month}} Newsletter',
                body: 'Check out our latest updates and special offers...',
                variables: ['month', 'year', 'specialOffer']
            }
        ];
        
        res.json({ 
            success: true, 
            data: templates 
        });
    } catch (error) {
        console.error('Get email templates error:', error);
        res.status(500).json({ success: false, message: 'Failed to load email templates' });
    }
});

// ======== END NEW ENDPOINTS ========

// ======== CAR RENTAL ENDPOINTS ========

// Car Rental Dashboard Stats
app.get('/api/access/car-rental/dashboard', authenticateAccess, async (req, res) => {
    try {
        // Check if user has car rental permissions
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_car_rentals')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Car rental access required' 
            });
        }

        const carFleet = await readData(carFleetFile);
        const bookings = await readData(bookingsFile);
        const maintenance = await readData(maintenanceFile);
        const registrations = await readData(vehicleRegistrationsFile || 'data/vehicleRegistrations.json');

        const today = new Date().toISOString().split('T')[0];
        const thirtyDaysFromNow = new Date();
        thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);

        // Calculate stats
        const stats = {
            totalFleet: carFleet.length,
            availableCars: carFleet.filter(car => car.status === 'available').length,
            rentedCars: carFleet.filter(car => car.status === 'rented').length,
            maintenanceCars: carFleet.filter(car => car.status === 'maintenance').length,
            
            todayRentals: bookings.filter(booking => 
                booking.date === today && 
                booking.serviceType === 'car-rental' &&
                (booking.status === 'confirmed' || booking.status === 'active')
            ).length,
            
            upcomingMaintenance: maintenance.filter(m => 
                m.status === 'scheduled' && 
                new Date(m.scheduledDate) <= thirtyDaysFromNow &&
                m.type === 'car'
            ).length,
            
            registrationsDue: (registrations || []).filter(r => {
                const expiryDate = new Date(r.expiryDate);
                return expiryDate <= thirtyDaysFromNow && r.status !== 'overdue';
            }).length,
            
            occupancyRate: carFleet.length > 0 ? 
                Math.round((carFleet.filter(car => car.status === 'rented').length / carFleet.length) * 100) : 0,
            
            overdueReturns: bookings.filter(booking => {
                if (booking.serviceType === 'car-rental' && booking.status === 'active') {
                    const endDate = new Date(booking.endDate || booking.date);
                    return endDate < new Date();
                }
                return false;
            }).length
        };

        // Recent rentals
        const recentRentals = bookings
            .filter(b => b.serviceType === 'car-rental')
            .sort((a, b) => new Date(b.date) - new Date(a.date))
            .slice(0, 5)
            .map(booking => ({
                id: booking.id,
                customerName: booking.customerName,
                vehicle: booking.carPreference || 'Not specified',
                date: booking.date,
                status: booking.status,
                price: booking.estimatedPrice || 0
            }));

        // Urgent maintenance
        const urgentMaintenance = maintenance
            .filter(m => 
                m.type === 'car' && 
                m.status === 'scheduled' &&
                new Date(m.scheduledDate) <= new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
            )
            .slice(0, 3);

        // Registration alerts
        const registrationAlerts = (registrations || [])
            .filter(r => {
                const expiryDate = new Date(r.expiryDate);
                const daysUntil = Math.ceil((expiryDate - new Date()) / (1000 * 60 * 60 * 24));
                return daysUntil <= 30 || r.status === 'overdue';
            })
            .slice(0, 3);

        res.json({
            success: true,
            data: {
                stats,
                recentRentals,
                urgentMaintenance,
                registrationAlerts,
                availableCars: carFleet.filter(car => car.status === 'available').slice(0, 3)
            }
        });
    } catch (error) {
        console.error('Car rental dashboard error:', error);
        res.status(500).json({ success: false, message: 'Failed to load car rental dashboard' });
    }
});

// Car Fleet Management
app.get('/api/access/car-rental/fleet', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_car_rentals')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Car rental access required' 
            });
        }

        const carFleet = await readData(carFleetFile);
        
        res.json({ 
            success: true, 
            data: carFleet 
        });
    } catch (error) {
        console.error('Car fleet error:', error);
        res.status(500).json({ success: false, message: 'Failed to load car fleet' });
    }
});

app.get('/api/access/car-rental/fleet/:id', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_car_rentals')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Car rental access required' 
            });
        }

        const { id } = req.params;
        const carFleet = await readData(carFleetFile);
        const car = carFleet.find(c => c.id == id);
        
        if (!car) {
            return res.status(404).json({ success: false, message: 'Car not found' });
        }
        
        res.json({ success: true, data: car });
    } catch (error) {
        console.error('Car details error:', error);
        res.status(500).json({ success: false, message: 'Failed to load car details' });
    }
});

app.post('/api/access/car-rental/fleet', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_car_rentals')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Car rental access required' 
            });
        }

        const carData = req.body;
        const carFleet = await readData(carFleetFile);
        
        const newCar = {
            id: generateId(),
            ...carData,
            status: 'available',
            createdAt: new Date().toISOString(),
            createdBy: req.user.id,
            updatedAt: new Date().toISOString(),
            lastMaintenance: new Date().toISOString().split('T')[0],
            nextMaintenance: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
        };
        
        carFleet.push(newCar);
        await writeData(carFleetFile, carFleet);
        
        res.json({ 
            success: true, 
            message: 'Car added to fleet successfully', 
            data: newCar 
        });
    } catch (error) {
        console.error('Add car error:', error);
        res.status(500).json({ success: false, message: 'Failed to add car to fleet' });
    }
});

app.put('/api/access/car-rental/fleet/:id', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_car_rentals')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Car rental access required' 
            });
        }

        const { id } = req.params;
        const carData = req.body;
        const carFleet = await readData(carFleetFile);
        
        const carIndex = carFleet.findIndex(c => c.id == id);
        if (carIndex === -1) {
            return res.status(404).json({ success: false, message: 'Car not found' });
        }
        
        const updatedCar = {
            ...carFleet[carIndex],
            ...carData,
            updatedAt: new Date().toISOString(),
            updatedBy: req.user.id
        };
        
        carFleet[carIndex] = updatedCar;
        await writeData(carFleetFile, carFleet);
        
        res.json({ 
            success: true, 
            message: 'Car updated successfully', 
            data: updatedCar 
        });
    } catch (error) {
        console.error('Update car error:', error);
        res.status(500).json({ success: false, message: 'Failed to update car' });
    }
});

app.delete('/api/access/car-rental/fleet/:id', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_car_rentals')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Car rental access required' 
            });
        }

        const { id } = req.params;
        const carFleet = await readData(carFleetFile);
        
        const carIndex = carFleet.findIndex(c => c.id == id);
        if (carIndex === -1) {
            return res.status(404).json({ success: false, message: 'Car not found' });
        }
        
        // Check if car is currently rented
        const car = carFleet[carIndex];
        if (car.status === 'rented') {
            return res.status(400).json({ 
                success: false, 
                message: 'Cannot delete a car that is currently rented' 
            });
        }
        
        const deletedCar = carFleet[carIndex];
        carFleet.splice(carIndex, 1);
        await writeData(carFleetFile, carFleet);
        
        res.json({ 
            success: true, 
            message: 'Car removed from fleet successfully',
            data: deletedCar
        });
    } catch (error) {
        console.error('Delete car error:', error);
        res.status(500).json({ success: false, message: 'Failed to remove car from fleet' });
    }
});

// Car Bookings
app.get('/api/access/car-rental/bookings', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_car_rentals')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Car rental access required' 
            });
        }

        const bookings = await readData(bookingsFile);
        const carBookings = bookings.filter(b => b.serviceType === 'car-rental');
        
        res.json({ 
            success: true, 
            data: carBookings 
        });
    } catch (error) {
        console.error('Car bookings error:', error);
        res.status(500).json({ success: false, message: 'Failed to load car bookings' });
    }
});

app.get('/api/access/car-rental/bookings/today', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_car_rentals')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Car rental access required' 
            });
        }

        const bookings = await readData(bookingsFile);
        const today = new Date().toISOString().split('T')[0];
        
        const todayBookings = bookings.filter(b => 
            b.serviceType === 'car-rental' && 
            b.date === today &&
            (b.status === 'confirmed' || b.status === 'active')
        );
        
        res.json({ 
            success: true, 
            data: todayBookings 
        });
    } catch (error) {
        console.error('Today car bookings error:', error);
        res.status(500).json({ success: false, message: 'Failed to load today\'s car bookings' });
    }
});

app.post('/api/access/car-rental/bookings', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_car_rentals')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Car rental access required' 
            });
        }

        const bookingData = req.body;
        const bookings = await readData(bookingsFile);
        const carFleet = await readData(carFleetFile);
        
        // Check if car is available
        const selectedCar = carFleet.find(car => car.id == bookingData.carId);
        if (!selectedCar || selectedCar.status !== 'available') {
            return res.status(400).json({ 
                success: false, 
                message: 'Selected car is not available' 
            });
        }
        
        const newBooking = {
            id: generateId(),
            ...bookingData,
            serviceType: 'car-rental',
            status: 'confirmed',
            createdAt: new Date().toISOString(),
            createdBy: req.user.id,
            source: 'portal'
        };
        
        bookings.push(newBooking);
        await writeData(bookingsFile, bookings);
        
        // Update car status
        selectedCar.status = 'rented';
        selectedCar.nextAvailable = bookingData.endDate || bookingData.date;
        await writeData(carFleetFile, carFleet);
        
        res.json({ 
            success: true, 
            message: 'Car booking created successfully', 
            data: newBooking 
        });
    } catch (error) {
        console.error('Create car booking error:', error);
        res.status(500).json({ success: false, message: 'Failed to create car booking' });
    }
});

app.put('/api/access/car-rental/bookings/:id', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_car_rentals')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Car rental access required' 
            });
        }

        const { id } = req.params;
        const bookingData = req.body;
        const bookings = await readData(bookingsFile);
        
        const bookingIndex = bookings.findIndex(b => b.id == id && b.serviceType === 'car-rental');
        if (bookingIndex === -1) {
            return res.status(404).json({ success: false, message: 'Car booking not found' });
        }
        
        const updatedBooking = {
            ...bookings[bookingIndex],
            ...bookingData,
            updatedAt: new Date().toISOString(),
            updatedBy: req.user.id
        };
        
        bookings[bookingIndex] = updatedBooking;
        await writeData(bookingsFile, bookings);
        
        res.json({ 
            success: true, 
            message: 'Car booking updated successfully', 
            data: updatedBooking 
        });
    } catch (error) {
        console.error('Update car booking error:', error);
        res.status(500).json({ success: false, message: 'Failed to update car booking' });
    }
});

app.put('/api/access/car-rental/bookings/:id/status', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_car_rentals')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Car rental access required' 
            });
        }

        const { id } = req.params;
        const { status } = req.body;
        const bookings = await readData(bookingsFile);
        const carFleet = await readData(carFleetFile);
        
        const bookingIndex = bookings.findIndex(b => b.id == id && b.serviceType === 'car-rental');
        if (bookingIndex === -1) {
            return res.status(404).json({ success: false, message: 'Car booking not found' });
        }
        
        const booking = bookings[bookingIndex];
        const previousStatus = booking.status;
        booking.status = status;
        booking.updatedAt = new Date().toISOString();
        booking.updatedBy = req.user.id;
        
        // If changing from active to completed, free up the car
        if (previousStatus === 'active' && status === 'completed') {
            const car = carFleet.find(c => c.id == booking.carId);
            if (car) {
                car.status = 'available';
                car.nextAvailable = null;
            }
        }
        // If changing to active, mark car as rented
        else if (status === 'active') {
            const car = carFleet.find(c => c.id == booking.carId);
            if (car) {
                car.status = 'rented';
            }
        }
        
        await writeData(bookingsFile, bookings);
        await writeData(carFleetFile, carFleet);
        
        res.json({ 
            success: true, 
            message: 'Booking status updated successfully', 
            data: booking 
        });
    } catch (error) {
        console.error('Update booking status error:', error);
        res.status(500).json({ success: false, message: 'Failed to update booking status' });
    }
});

// Car Maintenance
app.get('/api/access/car-rental/maintenance', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_maintenance')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Maintenance access required' 
            });
        }

        const maintenance = await readData(maintenanceFile);
        const carMaintenance = maintenance.filter(m => m.type === 'car');
        
        res.json({ 
            success: true, 
            data: carMaintenance 
        });
    } catch (error) {
        console.error('Car maintenance error:', error);
        res.status(500).json({ success: false, message: 'Failed to load car maintenance' });
    }
});

app.post('/api/access/car-rental/maintenance', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_maintenance')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Maintenance access required' 
            });
        }

        const maintenanceData = req.body;
        const maintenance = await readData(maintenanceFile);
        const carFleet = await readData(carFleetFile);
        
        // Check if car exists
        const car = carFleet.find(c => c.id == maintenanceData.carId);
        if (!car) {
            return res.status(404).json({ success: false, message: 'Car not found' });
        }
        
        const newMaintenance = {
            id: generateId(),
            ...maintenanceData,
            type: 'car',
            status: 'scheduled',
            createdAt: new Date().toISOString(),
            createdBy: req.user.id,
            vehicleDetails: `${car.make} ${car.model} (${car.plateNumber || car.name})`
        };
        
        maintenance.push(newMaintenance);
        await writeData(maintenanceFile, maintenance);
        
        // Update car status if maintenance is immediate
        if (new Date(maintenanceData.scheduledDate) <= new Date()) {
            car.status = 'maintenance';
            await writeData(carFleetFile, carFleet);
        }
        
        res.json({ 
            success: true, 
            message: 'Maintenance scheduled successfully', 
            data: newMaintenance 
        });
    } catch (error) {
        console.error('Schedule maintenance error:', error);
        res.status(500).json({ success: false, message: 'Failed to schedule maintenance' });
    }
});

app.put('/api/access/car-rental/maintenance/:id/complete', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_maintenance')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Maintenance access required' 
            });
        }

        const { id } = req.params;
        const { actualCost, notes } = req.body;
        const maintenance = await readData(maintenanceFile);
        const carFleet = await readData(carFleetFile);
        
        const maintenanceIndex = maintenance.findIndex(m => m.id == id && m.type === 'car');
        if (maintenanceIndex === -1) {
            return res.status(404).json({ success: false, message: 'Maintenance record not found' });
        }
        
        const maintenanceRecord = maintenance[maintenanceIndex];
        maintenanceRecord.status = 'completed';
        maintenanceRecord.completedDate = new Date().toISOString().split('T')[0];
        maintenanceRecord.completedBy = req.user.id;
        maintenanceRecord.actualCost = actualCost || maintenanceRecord.estimatedCost;
        maintenanceRecord.notes = notes || maintenanceRecord.notes;
        
        // Update car status back to available
        const car = carFleet.find(c => c.id == maintenanceRecord.carId);
        if (car && car.status === 'maintenance') {
            car.status = 'available';
            car.lastMaintenance = maintenanceRecord.completedDate;
            car.nextMaintenance = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
        }
        
        await writeData(maintenanceFile, maintenance);
        await writeData(carFleetFile, carFleet);
        
        res.json({ 
            success: true, 
            message: 'Maintenance marked as completed', 
            data: maintenanceRecord 
        });
    } catch (error) {
        console.error('Complete maintenance error:', error);
        res.status(500).json({ success: false, message: 'Failed to complete maintenance' });
    }
});

// Registration Renewal
app.get('/api/access/car-rental/registrations', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_registrations')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Registration access required' 
            });
        }

        const registrations = await readData(vehicleRegistrationsFile || 'data/vehicleRegistrations.json');
        
        res.json({ 
            success: true, 
            data: registrations || [] 
        });
    } catch (error) {
        console.error('Car registrations error:', error);
        res.status(500).json({ success: false, message: 'Failed to load car registrations' });
    }
});

app.post('/api/access/car-rental/registrations', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_registrations')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Registration access required' 
            });
        }

        const registrationData = req.body;
        const registrations = await readData(vehicleRegistrationsFile || 'data/vehicleRegistrations.json');
        const carFleet = await readData(carFleetFile);
        
        // Check if car exists
        const car = carFleet.find(c => c.id == registrationData.carId);
        if (!car) {
            return res.status(404).json({ success: false, message: 'Car not found' });
        }
        
        const newRegistration = {
            id: generateId(),
            ...registrationData,
            createdAt: new Date().toISOString(),
            createdBy: req.user.id,
            vehicleDetails: `${car.make} ${car.model} (${car.plateNumber || car.name})`,
            status: 'valid',
            lastRenewal: new Date().toISOString().split('T')[0]
        };
        
        const updatedRegistrations = [...(registrations || []), newRegistration];
        await writeData(vehicleRegistrationsFile || 'data/vehicleRegistrations.json', updatedRegistrations);
        
        res.json({ 
            success: true, 
            message: 'Registration added successfully', 
            data: newRegistration 
        });
    } catch (error) {
        console.error('Add registration error:', error);
        res.status(500).json({ success: false, message: 'Failed to add registration' });
    }
});

app.put('/api/access/car-rental/registrations/:id/renew', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_registrations')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Registration access required' 
            });
        }

        const { id } = req.params;
        const { expiryDate, renewalFee, notes } = req.body;
        const registrations = await readData(vehicleRegistrationsFile || 'data/vehicleRegistrations.json');
        
        const registrationIndex = (registrations || []).findIndex(r => r.id == id);
        if (registrationIndex === -1) {
            return res.status(404).json({ success: false, message: 'Registration not found' });
        }
        
        const registration = registrations[registrationIndex];
        registration.expiryDate = expiryDate || registration.expiryDate;
        registration.renewalFee = renewalFee || registration.renewalFee;
        registration.status = 'valid';
        registration.lastRenewal = new Date().toISOString().split('T')[0];
        registration.notes = notes || registration.notes;
        registration.updatedAt = new Date().toISOString();
        registration.updatedBy = req.user.id;
        
        await writeData(vehicleRegistrationsFile || 'data/vehicleRegistrations.json', registrations);
        
        res.json({ 
            success: true, 
            message: 'Registration renewed successfully', 
            data: registration 
        });
    } catch (error) {
        console.error('Renew registration error:', error);
        res.status(500).json({ success: false, message: 'Failed to renew registration' });
    }
});

// Car Rental Reports
app.get('/api/access/car-rental/reports', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('view_reports')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Report access required' 
            });
        }

        const { reportType, startDate, endDate } = req.query;
        const bookings = await readData(bookingsFile);
        const carFleet = await readData(carFleetFile);
        
        // Filter bookings by date and type
        const filteredBookings = bookings.filter(booking => {
            if (booking.serviceType !== 'car-rental') return false;
            if (startDate && booking.date < startDate) return false;
            if (endDate && booking.date > endDate) return false;
            return true;
        });
        
        // Generate different reports based on type
        let report;
        
        switch (reportType) {
            case 'monthly':
                report = generateMonthlyReport(filteredBookings, carFleet);
                break;
            case 'fleet-utilization':
                report = generateFleetUtilizationReport(filteredBookings, carFleet);
                break;
            case 'maintenance':
                const maintenance = await readData(maintenanceFile);
                report = generateMaintenanceReport(maintenance.filter(m => m.type === 'car'));
                break;
            case 'financial':
                report = generateFinancialReport(filteredBookings);
                break;
            default:
                report = generateSummaryReport(filteredBookings, carFleet);
        }
        
        res.json({ 
            success: true, 
            data: {
                ...report,
                reportType: reportType || 'summary',
                period: { startDate, endDate },
                generatedAt: new Date().toISOString()
            }
        });
    } catch (error) {
        console.error('Car rental report error:', error);
        res.status(500).json({ success: false, message: 'Failed to generate report' });
    }
});

// Helper functions for reports
function generateMonthlyReport(bookings, fleet) {
    const revenueByMonth = {};
    const bookingsByMonth = {};
    
    bookings.forEach(booking => {
        const month = booking.date.substring(0, 7); // YYYY-MM format
        const revenue = parseFloat(booking.estimatedPrice) || 0;
        
        revenueByMonth[month] = (revenueByMonth[month] || 0) + revenue;
        bookingsByMonth[month] = (bookingsByMonth[month] || 0) + 1;
    });
    
    return {
        type: 'monthly',
        summary: {
            totalRevenue: Object.values(revenueByMonth).reduce((sum, val) => sum + val, 0),
            totalBookings: bookings.length,
            averageBookingValue: bookings.length > 0 ? 
                Object.values(revenueByMonth).reduce((sum, val) => sum + val, 0) / bookings.length : 0
        },
        monthlyData: {
            revenueByMonth,
            bookingsByMonth
        }
    };
}

function generateFleetUtilizationReport(bookings, fleet) {
    const utilizationByCar = {};
    
    fleet.forEach(car => {
        const carBookings = bookings.filter(b => b.carId == car.id);
        const totalDays = 30; // Assuming 30-day period
        
        utilizationByCar[car.id] = {
            name: `${car.make} ${car.model}`,
            totalBookings: carBookings.length,
            daysRented: carBookings.length * 2, // Assuming average 2-day rentals
            utilizationRate: Math.round((carBookings.length * 2 / totalDays) * 100),
            revenue: carBookings.reduce((sum, b) => sum + (parseFloat(b.estimatedPrice) || 0), 0)
        };
    });
    
    return {
        type: 'fleet-utilization',
        summary: {
            totalFleet: fleet.length,
            averageUtilization: Math.round(
                Object.values(utilizationByCar).reduce((sum, car) => sum + car.utilizationRate, 0) / fleet.length
            )
        },
        carUtilization: utilizationByCar
    };
}

function generateMaintenanceReport(maintenance) {
    const maintenanceByStatus = {
        scheduled: maintenance.filter(m => m.status === 'scheduled').length,
        inProgress: maintenance.filter(m => m.status === 'in-progress').length,
        completed: maintenance.filter(m => m.status === 'completed').length
    };
    
    const totalCost = maintenance.reduce((sum, m) => sum + (parseFloat(m.estimatedCost) || 0), 0);
    
    return {
        type: 'maintenance',
        summary: {
            totalMaintenance: maintenance.length,
            totalCost,
            averageCost: maintenance.length > 0 ? totalCost / maintenance.length : 0,
            byStatus: maintenanceByStatus
        },
        upcomingMaintenance: maintenance
            .filter(m => m.status === 'scheduled')
            .slice(0, 10)
    };
}

function generateFinancialReport(bookings) {
    const revenue = bookings.reduce((sum, b) => sum + (parseFloat(b.estimatedPrice) || 0), 0);
    const deposits = bookings.reduce((sum, b) => sum + (parseFloat(b.deposit) || 0), 0);
    
    return {
        type: 'financial',
        summary: {
            totalRevenue: revenue,
            totalDeposits: deposits,
            netRevenue: revenue - (deposits * 0.5), // Assuming 50% of deposits returned
            averageBookingValue: bookings.length > 0 ? revenue / bookings.length : 0
        },
        topCustomers: bookings
            .slice()
            .sort((a, b) => (parseFloat(b.estimatedPrice) || 0) - (parseFloat(a.estimatedPrice) || 0))
            .slice(0, 5)
            .map(b => ({
                customerName: b.customerName,
                totalSpent: parseFloat(b.estimatedPrice) || 0,
                bookings: 1
            }))
    };
}

function generateSummaryReport(bookings, fleet) {
    const availableCars = fleet.filter(c => c.status === 'available').length;
    const rentedCars = fleet.filter(c => c.status === 'rented').length;
    
    return {
        type: 'summary',
        fleetStatus: {
            total: fleet.length,
            available: availableCars,
            rented: rentedCars,
            maintenance: fleet.filter(c => c.status === 'maintenance').length,
            occupancyRate: Math.round((rentedCars / fleet.length) * 100)
        },
        bookingStats: {
            total: bookings.length,
            confirmed: bookings.filter(b => b.status === 'confirmed').length,
            active: bookings.filter(b => b.status === 'active').length,
            completed: bookings.filter(b => b.status === 'completed').length,
            cancelled: bookings.filter(b => b.status === 'cancelled').length
        },
        revenue: bookings.reduce((sum, b) => sum + (parseFloat(b.estimatedPrice) || 0), 0)
    };
}

// Export car rental data
app.post('/api/access/car-rental/export', authenticateAccess, async (req, res) => {
    try {
        if (req.user.accessLevel !== 'car-rental' && !req.user.permissions.includes('manage_car_rentals')) {
            return res.status(403).json({ 
                success: false, 
                message: 'Car rental access required' 
            });
        }

        const { exportType, startDate, endDate } = req.body;
        const bookings = await readData(bookingsFile);
        const carFleet = await readData(carFleetFile);
        
        // Filter data based on date range
        let filteredData;
        switch (exportType) {
            case 'bookings':
                filteredData = bookings.filter(b => {
                    if (b.serviceType !== 'car-rental') return false;
                    if (startDate && b.date < startDate) return false;
                    if (endDate && b.date > endDate) return false;
                    return true;
                });
                break;
            case 'fleet':
                filteredData = carFleet;
                break;
            case 'maintenance':
                const maintenance = await readData(maintenanceFile);
                filteredData = maintenance.filter(m => m.type === 'car');
                break;
            default:
                filteredData = [];
        }
        
        // In a real application, this would generate a CSV or Excel file
        // For now, we'll return JSON
        res.json({
            success: true,
            message: `Export of ${exportType} data generated successfully`,
            data: {
                exportType,
                recordCount: filteredData.length,
                data: filteredData.slice(0, 100), // Limit to 100 records for demo
                downloadUrl: `/api/access/car-rental/download/${generateId()}.json`,
                generatedAt: new Date().toISOString()
            }
        });
    } catch (error) {
        console.error('Export error:', error);
        res.status(500).json({ success: false, message: 'Failed to generate export' });
    }
});

// ======== END CAR RENTAL ENDPOINTS ========

// ======== EXISTING ADMIN ENDPOINTS ========

// Admin dashboard endpoints...
app.get('/api/admin/quickbooks/status', authenticateToken, async (req, res) => {
    try {
        const quickbooks = await readData(quickbooksFile);
        res.json({ success: true, data: quickbooks });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to load QuickBooks status' });
    }
});

app.post('/api/admin/quickbooks/connect', authenticateToken, async (req, res) => {
    try {
        const { companyName, accessToken, refreshToken } = req.body;
        const quickbooks = await readData(quickbooksFile);
        
        quickbooks.connected = true;
        quickbooks.companyName = companyName;
        quickbooks.lastSync = new Date().toISOString();
        quickbooks.accessToken = accessToken;
        quickbooks.refreshToken = refreshToken;
        
        await writeData(quickbooksFile, quickbooks);
        
        res.json({ 
            success: true, 
            message: 'Successfully connected to QuickBooks',
            data: quickbooks
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to connect to QuickBooks' });
    }
});

app.get('/api/admin/quickbooks/auth', authenticateToken, (req, res) => {
    try {
        const authUri = oauthClient.authorizeUri({
            scope: [OAuthClient.scopes.Accounting, OAuthClient.scopes.OpenId],
            state: 'islandtimebvi_' + generateId()
        });
        
        res.json({ 
            success: true, 
            data: { authUrl: authUri } 
        });
    } catch (error) {
        console.error('QuickBooks auth error:', error);
        res.status(500).json({ success: false, message: 'Failed to generate auth URL' });
    }
});

app.get('/api/admin/quickbooks/callback', async (req, res) => {
    try {
        const { code, state, realmId } = req.query;
        
        const authResponse = await oauthClient.createToken(code);
        const accessToken = authResponse.getToken().access_token;
        const refreshToken = authResponse.getToken().refresh_token;
        
        // Save tokens to your database
        const quickbooksData = await readData(quickbooksFile);
        quickbooksData.connected = true;
        quickbooksData.accessToken = accessToken;
        quickbooksData.refreshToken = refreshToken;
        quickbooksData.companyId = realmId;
        quickbooksData.lastSync = new Date().toISOString();
        
        // Get company info
        const companyInfo = await oauthClient.makeApiCall({
            url: `https://sandbox-quickbooks.api.intuit.com/v3/company/${realmId}/companyinfo/${realmId}`
        });
        
        quickbooksData.companyName = companyInfo.json.CompanyInfo.CompanyName;
        
        await writeData(quickbooksFile, quickbooksData);
        
        res.redirect('http://localhost:3000/admin#quickbooks?connected=true');
    } catch (error) {
        console.error('QuickBooks callback error:', error);
        res.redirect('http://localhost:3000/admin#quickbooks?error=auth_failed');
    }
});

app.post('/api/admin/quickbooks/sync/invoices', authenticateToken, async (req, res) => {
    try {
        const quickbooksData = await readData(quickbooksFile);
        
        if (!quickbooksData.connected) {
            return res.status(400).json({ success: false, message: 'QuickBooks not connected' });
        }

        const bookings = await readData(bookingsFile);
        const confirmedBookings = bookings.filter(b => b.status === 'confirmed' && !b.quickbooksSynced);

        let syncedCount = 0;
        let errors = [];

        for (const booking of confirmedBookings) {
            try {
                const invoiceData = {
                    Line: [{
                        DetailType: 'SalesItemLineDetail',
                        Amount: parseFloat(booking.estimatedPrice) || 0,
                        Description: `${booking.serviceType} - ${booking.customerName}`,
                        SalesItemLineDetail: {
                            ItemRef: {
                                value: '1' // Your service item ID in QuickBooks
                            }
                        }
                    }],
                    CustomerRef: {
                        value: await getOrCreateCustomer(booking, quickbooksData)
                    },
                    TxnDate: booking.date
                };

                const response = await oauthClient.makeApiCall({
                    method: 'POST',
                    url: `https://sandbox-quickbooks.api.intuit.com/v3/company/${quickbooksData.companyId}/invoice`,
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(invoiceData)
                });

                // Mark booking as synced
                booking.quickbooksSynced = true;
                booking.quickbooksInvoiceId = response.json.Invoice.Id;
                syncedCount++;
                
            } catch (invoiceError) {
                errors.push(`Booking ${booking.id}: ${invoiceError.message}`);
            }
        }

        // Update bookings file
        await writeData(bookingsFile, bookings);
        
        // Update sync stats
        quickbooksData.financialData.syncedInvoices = (quickbooksData.financialData.syncedInvoices || 0) + syncedCount;
        quickbooksData.financialData.syncErrors = (quickbooksData.financialData.syncErrors || 0) + errors.length;
        quickbooksData.lastSync = new Date().toISOString();
        await writeData(quickbooksFile, quickbooksData);

        res.json({ 
            success: true, 
            message: `Synced ${syncedCount} invoices to QuickBooks${errors.length > 0 ? ` with ${errors.length} errors` : ''}`,
            data: {
                syncedCount,
                errorCount: errors.length,
                errors: errors.length > 0 ? errors : undefined
            }
        });
        
    } catch (error) {
        console.error('QuickBooks sync error:', error);
        res.status(500).json({ success: false, message: 'Failed to sync with QuickBooks' });
    }
});

async function getOrCreateCustomer(booking, quickbooksData) {
    try {
        // First, search for existing customer by email
        const searchResponse = await oauthClient.makeApiCall({
            method: 'GET',
            url: `https://sandbox-quickbooks.api.intuit.com/v3/company/${quickbooksData.companyId}/query`,
            params: {
                query: `SELECT * FROM Customer WHERE PrimaryEmailAddr = '${booking.customerEmail}'`
            }
        });

        if (searchResponse.json.QueryResponse.Customer && searchResponse.json.QueryResponse.Customer.length > 0) {
            return searchResponse.json.QueryResponse.Customer[0].Id;
        }

        // Create new customer
        const customerData = {
            DisplayName: booking.customerName,
            PrimaryEmailAddr: {
                Address: booking.customerEmail
            },
            PrimaryPhone: {
                FreeFormNumber: booking.customerPhone || ''
            }
        };

        const createResponse = await oauthClient.makeApiCall({
            method: 'POST',
            url: `https://sandbox-quickbooks.api.intuit.com/v3/company/${quickbooksData.companyId}/customer`,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(customerData)
        });

        return createResponse.json.Customer.Id;
        
    } catch (error) {
        console.error('Customer creation error:', error);
        throw error;
    }
}

app.post('/api/admin/quickbooks/refresh-token', authenticateToken, async (req, res) => {
    try {
        const quickbooksData = await readData(quickbooksFile);
        
        if (!quickbooksData.refreshToken) {
            return res.status(400).json({ success: false, message: 'No refresh token available' });
        }

        const authResponse = await oauthClient.refreshUsingToken(quickbooksData.refreshToken);
        const newTokens = authResponse.getToken();
        
        quickbooksData.accessToken = newTokens.access_token;
        quickbooksData.refreshToken = newTokens.refresh_token;
        quickbooksData.lastSync = new Date().toISOString();
        
        await writeData(quickbooksFile, quickbooksData);
        
        res.json({ 
            success: true, 
            message: 'Token refreshed successfully' 
        });
        
    } catch (error) {
        console.error('Token refresh error:', error);
        res.status(500).json({ success: false, message: 'Failed to refresh token' });
    }
});

app.post('/api/admin/quickbooks/disconnect', authenticateToken, async (req, res) => {
    try {
        const quickbooks = await readData(quickbooksFile);
        
        quickbooks.connected = false;
        quickbooks.companyName = '';
        quickbooks.lastSync = null;
        delete quickbooks.accessToken;
        delete quickbooks.refreshToken;
        
        await writeData(quickbooksFile, quickbooks);
        
        res.json({ 
            success: true, 
            message: 'Successfully disconnected from QuickBooks'
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to disconnect from QuickBooks' });
    }
});

app.post('/api/admin/quickbooks/sync', authenticateToken, async (req, res) => {
    try {
        const { syncType } = req.body;
        const quickbooks = await readData(quickbooksFile);
        
        if (!quickbooks.connected) {
            return res.status(400).json({ success: false, message: 'QuickBooks not connected' });
        }
        
        const bookings = await readData(bookingsFile);
        const recentBookings = bookings.filter(b => b.status === 'confirmed');
        
        quickbooks.financialData.totalRevenue = recentBookings.reduce((sum, booking) => sum + (parseFloat(booking.estimatedPrice) || 0), 0);
        quickbooks.financialData.outstandingInvoices = recentBookings.filter(b => !b.paid).length;
        quickbooks.financialData.recentTransactions = recentBookings.slice(0, 10).map(booking => ({
            id: booking.id,
            date: booking.date,
            description: `${booking.serviceType} - ${booking.customerName}`,
            amount: parseFloat(booking.estimatedPrice) || 0,
            type: 'income'
        }));
        
        quickbooks.lastSync = new Date().toISOString();
        await writeData(quickbooksFile, quickbooks);
        
        res.json({ 
            success: true, 
            message: `Successfully synced ${syncType} with QuickBooks`,
            data: {
                syncedItems: recentBookings.length,
                financialData: quickbooks.financialData
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to sync with QuickBooks' });
    }
});

app.put('/api/admin/quickbooks/settings', authenticateToken, async (req, res) => {
    try {
        const { autoSyncBookings, autoSyncInvoices, syncInterval } = req.body;
        const quickbooks = await readData(quickbooksFile);
        
        quickbooks.syncSettings = {
            autoSyncBookings: autoSyncBookings !== undefined ? autoSyncBookings : quickbooks.syncSettings.autoSyncBookings,
            autoSyncInvoices: autoSyncInvoices !== undefined ? autoSyncInvoices : quickbooks.syncSettings.autoSyncInvoices,
            syncInterval: syncInterval || quickbooks.syncSettings.syncInterval
        };
        
        await writeData(quickbooksFile, quickbooks);
        
        res.json({ 
            success: true, 
            message: 'QuickBooks settings updated successfully',
            data: quickbooks.syncSettings
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to update QuickBooks settings' });
    }
});

app.get('/api/admin/quickbooks/reports', authenticateToken, async (req, res) => {
    try {
        const { reportType, startDate, endDate } = req.query;
        const quickbooks = await readData(quickbooksFile);
        const bookings = await readData(bookingsFile);
        
        if (!quickbooks.connected) {
            return res.status(400).json({ success: false, message: 'QuickBooks not connected' });
        }
        
        const filteredBookings = bookings.filter(booking => {
            if (startDate && booking.date < startDate) return false;
            if (endDate && booking.date > endDate) return false;
            return true;
        });
        
        const revenueByService = filteredBookings.reduce((acc, booking) => {
            const service = booking.serviceType;
            const amount = parseFloat(booking.estimatedPrice) || 0;
            acc[service] = (acc[service] || 0) + amount;
            return acc;
        }, {});
        
        const report = {
            reportType,
            period: { startDate, endDate },
            summary: {
                totalRevenue: Object.values(revenueByService).reduce((sum, amount) => sum + amount, 0),
                totalBookings: filteredBookings.length,
                revenueByService
            },
            generatedAt: new Date().toISOString()
        };
        
        res.json({ 
            success: true, 
            data: report
        });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to generate QuickBooks report' });
    }
});

// ======== FLEET MANAGEMENT ENDPOINTS ========
app.get('/api/admin/car-fleet', authenticateToken, async (req, res) => {
    try {
        const carFleet = await readData(carFleetFile);
        res.json({ success: true, data: carFleet });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to load car fleet' });
    }
});

app.get('/api/admin/boat-fleet', authenticateToken, async (req, res) => {
    try {
        const boatFleet = await readData(boatFleetFile);
        res.json({ success: true, data: boatFleet });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to load boat fleet' });
    }
});

app.put('/api/admin/boat-fleet/:id', authenticateToken, async (req, res) => {
    try {
        const { id } = req.params;
        const boatData = req.body;
        const boatFleet = await readData(boatFleetFile);
        
        const boatIndex = boatFleet.findIndex(boat => boat.id == id);
        if (boatIndex === -1) {
            return res.status(404).json({ success: false, message: 'Boat not found' });
        }
        
        boatFleet[boatIndex] = {
            ...boatFleet[boatIndex],
            ...boatData,
            updatedAt: new Date().toISOString(),
            updatedBy: req.user.id
        };
        
        await writeData(boatFleetFile, boatFleet);
        res.json({ success: true, message: 'Boat updated successfully', data: boatFleet[boatIndex] });
    } catch (error) {
        console.error('Error updating boat:', error);
        res.status(500).json({ success: false, message: 'Failed to update boat: ' + error.message });
    }
});

app.post('/api/admin/boat-fleet', authenticateToken, async (req, res) => {
    try {
        const boatData = req.body;
        const boatFleet = await readData(boatFleetFile);
        
        const newBoat = {
            id: generateId(),
            ...boatData,
            status: 'available',
            createdAt: new Date().toISOString(),
            createdBy: req.user.id
        };
        
        boatFleet.push(newBoat);
        await writeData(boatFleetFile, boatFleet);
        res.json({ success: true, message: 'Boat added successfully', data: newBoat });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to add boat' });
    }
});

// ======== MAINTENANCE ENDPOINTS ========
app.get('/api/admin/maintenance', authenticateToken, async (req, res) => {
    try {
        const maintenance = await readData(maintenanceFile);
        res.json({ success: true, data: maintenance });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to load maintenance schedules' });
    }
});

app.post('/api/admin/maintenance', authenticateToken, async (req, res) => {
    try {
        const maintenanceData = req.body;
        const maintenance = await readData(maintenanceFile);
        
        const newMaintenance = {
            id: generateId(),
            ...maintenanceData,
            status: 'scheduled',
            createdAt: new Date().toISOString(),
            createdBy: req.user.id
        };
        
        maintenance.push(newMaintenance);
        await writeData(maintenanceFile, maintenance);
        
        res.json({ success: true, message: 'Maintenance schedule created successfully', data: newMaintenance });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to create maintenance schedule' });
    }
});

// ======== TODO ENDPOINTS ========
app.get('/api/admin/todos', authenticateToken, async (req, res) => {
    try {
        const todos = await readData(todosFile);
        const userTodos = todos.filter(todo => todo.assignedTo === req.user.id);
        res.json({ success: true, data: userTodos });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to load todos' });
    }
});

app.post('/api/admin/todos', authenticateToken, async (req, res) => {
    try {
        const { task, dueDate, assignedTo } = req.body;
        const todos = await readData(todosFile);
        
        const newTodo = {
            id: generateId(),
            task,
            dueDate,
            assignedTo: assignedTo || req.user.id,
            completed: false,
            createdAt: new Date().toISOString(),
            createdBy: req.user.id
        };
        
        todos.push(newTodo);
        await writeData(todosFile, todos);
        res.json({ success: true, message: 'Todo created successfully', data: newTodo });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to create todo' });
    }
});

// ======== NEWS ENDPOINTS ========
app.get('/api/admin/news', authenticateToken, async (req, res) => {
    try {
        const news = await readData(newsFile);
        res.json({ success: true, data: news });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to load news' });
    }
});

app.post('/api/admin/news', authenticateToken, async (req, res) => {
    try {
        const { title, source, date, summary, url } = req.body;
        const news = await readData(newsFile);
        
        const newNews = {
            id: generateId(),
            title,
            source,
            date: date || new Date().toISOString().split('T')[0],
            summary,
            url: url || '#',
            createdAt: new Date().toISOString(),
            createdBy: req.user.id
        };
        
        news.push(newNews);
        await writeData(newsFile, news);
        
        broadcastNewsUpdate(newNews, 'added');
        broadcastNewsFeed(news);
        
        res.json({ 
            success: true, 
            message: 'News article added successfully', 
            data: newNews 
        });
    } catch (error) {
        console.error('Add news error:', error);
        res.json({ 
            success: false, 
            message: 'Failed to add news article' 
        });
    }
});

// ======== BOOKINGS ENDPOINTS ========
app.get('/api/admin/bookings', authenticateToken, async (req, res) => {
    try {
        const bookings = await readData(bookingsFile);
        res.json({ success: true, data: bookings });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to load bookings' });
    }
});

// ======== MESSAGES ENDPOINTS ========
app.get('/api/admin/messages', authenticateToken, async (req, res) => {
    try {
        const messages = await readData(messagesFile);
        res.json({ success: true, data: messages });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to load messages' });
    }
});

// ======== CALENDAR ENDPOINTS ========
app.get('/api/admin/calendar', authenticateToken, async (req, res) => {
    try {
        const calendarEvents = await readData(calendarFile);
        res.json({ success: true, data: calendarEvents });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to load calendar events' });
    }
});

// ======== SETTINGS ENDPOINTS ========
app.get('/api/admin/settings', authenticateToken, async (req, res) => {
    try {
        const settings = await readData(settingsFile);
        res.json({ success: true, data: settings });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to load settings' });
    }
});

// ======== USER MANAGEMENT ENDPOINTS ========
app.get('/api/admin/users', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        const users = await readData(usersFile);
        const usersWithoutPasswords = users.map(({ password, ...user }) => user);
        res.json({ success: true, data: usersWithoutPasswords });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to load users' });
    }
});

app.post('/api/admin/users', authenticateToken, requireRole(['admin']), async (req, res) => {
    try {
        const { name, email, role, accessLevel, permissions } = req.body;
        const users = await readData(usersFile);
        
        const existingUser = users.find(u => u.email === email);
        if (existingUser) {
            return res.status(400).json({ success: false, message: 'User with this email already exists' });
        }
        
        const hashedPassword = await bcrypt.hash('temp123', 10);
        
        const newUser = {
            id: generateId(),
            name,
            email,
            password: hashedPassword,
            role: role || 'staff',
            isActive: true,
            createdAt: new Date().toISOString(),
            accessLevel: accessLevel || 'staff',
            permissions: permissions || (role === 'admin' ? ['all'] : [
                'view_bookings', 
                'manage_bookings', 
                'view_customers', 
                'manage_customers', 
                'view_fleet', 
                'view_fleet_details',
                'manage_water_taxi', 
                'manage_boat_rental', 
                'manage_car_rental',
                'view_schedule',
                'manage_tasks'
            ])
        };
        
        users.push(newUser);
        await writeData(usersFile, users);
        
        const { password, ...userWithoutPassword } = newUser;
        res.json({ success: true, message: 'User created successfully', data: userWithoutPassword });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to create user' });
    }
});

// ======== DEBUG ENDPOINTS ========
app.get('/api/debug/reset-passwords', async (req, res) => {
    try {
        const users = await readData(usersFile);
        
        // Reset passwords for staff users
        for (let user of users) {
            if (user.email === 'boats@islandtimebvi.com') {
                user.password = await bcrypt.hash('boats123', 10);
                user.accessLevel = 'captain';
                console.log('Reset boats user password and access level');
            }
            if (user.email === 'cars@islandtimeltd.com') {
                user.password = await bcrypt.hash('cars123', 10);
                user.accessLevel = 'car-rental';
                console.log('Reset cars user password and access level');
            }
            if (user.email === 'content@islandtimeltd.com') {
                user.password = await bcrypt.hash('content123', 10);
                user.accessLevel = 'creator';
                console.log('Reset content user password and access level');
            }
        }
                
        await writeData(usersFile, users);
        
        res.json({ 
            success: true, 
            message: 'Passwords reset successfully',
            data: {
                boats: { email: 'boats@islandtimebvi.com', password: 'boats123', accessLevel: 'captain' },
                cars: { email: 'cars@islandtimeltd.com', password: 'cars123', accessLevel: 'car-rental' },
                content: { email: 'content@islandtimeltd.com', password: 'content123', accessLevel: 'creator' }
            }
        });
    } catch (error) {
        console.error('Password reset error:', error);
        res.status(500).json({ success: false, message: 'Failed to reset passwords' });
    }
});

app.get('/api/debug/check-users', async (req, res) => {
    try {
        const users = await readData(usersFile);
        const userInfo = users.map(u => ({
            email: u.email,
            role: u.role,
            accessLevel: u.accessLevel,
            passwordStartsWith: u.password ? u.password.substring(0, 20) + '...' : 'MISSING',
            passwordIsBcrypt: u.password ? u.password.startsWith('$2a$') : false,
            permissions: u.permissions
        }));
        res.json({ success: true, data: userInfo });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to check users' });
    }
});
// ======== DEBUG ENDPOINT TO FIX CONTENT CREATOR ========
app.post('/api/debug/fix-content-creator', async (req, res) => {
    try {
        const users = await readData(usersFile);
        
        // Check if content creator exists
        let contentUser = users.find(u => u.email === 'content@islandtimeltd.com');
        
        if (!contentUser) {
            // Create content creator user if doesn't exist
            const creatorHashedPassword = await bcrypt.hash('content123', 10);
            contentUser = {
                id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 4,
                name: 'Content Creator',
                email: 'content@islandtimeltd.com',
                password: creatorHashedPassword,
                role: 'staff',
                isActive: true,
                lastLogin: new Date().toISOString(),
                createdAt: new Date().toISOString(),
                accessLevel: 'creator',
                permissions: [
                    'manage_content',
                    'view_content',
                    'create_content',
                    'schedule_content',
                    'manage_calendar',
                    'manage_notes',
                    'view_reports',
                    'create_reports',
                    'social_integration',
                    'view_analytics',
                    'view_bookings',
                    'view_fleet',
                    'view_schedule',
                    'manage_tasks'
                ]
            };
            users.push(contentUser);
            await writeData(usersFile, users);
            
            console.log('✅ Content creator user CREATED successfully');
            
            res.json({ 
                success: true, 
                message: 'Content creator user created successfully',
                data: {
                    email: 'content@islandtimeltd.com',
                    password: 'content123',
                    accessLevel: 'creator',
                    permissions: contentUser.permissions
                }
            });
        } else {
            // Fix existing user
            console.log('🔧 Fixing existing content creator user...');
            
            // Update access level if needed
            if (contentUser.accessLevel !== 'creator') {
                contentUser.accessLevel = 'creator';
                console.log('Updated access level to: creator');
            }
            
            // Ensure permissions are correct
            const requiredPermissions = [
                'manage_content',
                'view_content',
                'create_content',
                'schedule_content',
                'manage_calendar',
                'manage_notes',
                'view_reports',
                'create_reports',
                'social_integration',
                'view_analytics',
                'view_bookings',
                'view_fleet',
                'view_schedule',
                'manage_tasks'
            ];
            
            // Add missing permissions
            requiredPermissions.forEach(permission => {
                if (!contentUser.permissions || !contentUser.permissions.includes(permission)) {
                    if (!contentUser.permissions) contentUser.permissions = [];
                    contentUser.permissions.push(permission);
                }
            });
            
            // Reset password if needed
            const testPassword = await bcrypt.compare('content123', contentUser.password);
            if (!testPassword) {
                contentUser.password = await bcrypt.hash('content123', 10);
                console.log('Password reset to: content123');
            }
            
            await writeData(usersFile, users);
            console.log('✅ Content creator user FIXED successfully');
            
            res.json({ 
                success: true, 
                message: 'Content creator user fixed successfully',
                data: {
                    email: contentUser.email,
                    password: 'content123',
                    accessLevel: contentUser.accessLevel,
                    permissions: contentUser.permissions
                }
            });
        }
    } catch (error) {
        console.error('Fix content creator error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Failed to fix content creator: ' + error.message 
        });
    }
});
// GET version for browser access
app.get('/api/debug/fix-content-creator', async (req, res) => {
    try {
        const users = await readData(usersFile);
        
        // Check if content creator exists
        let contentUser = users.find(u => u.email === 'content@islandtimeltd.com');
        
        if (!contentUser) {
            // Create content creator user if doesn't exist
            const creatorHashedPassword = await bcrypt.hash('content123', 10);
            contentUser = {
                id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 4,
                name: 'Content Creator',
                email: 'content@islandtimeltd.com',
                password: creatorHashedPassword,
                role: 'staff',
                isActive: true,
                lastLogin: new Date().toISOString(),
                createdAt: new Date().toISOString(),
                accessLevel: 'creator',
                permissions: [
                    'manage_content',
                    'view_content',
                    'create_content',
                    'schedule_content',
                    'manage_calendar',
                    'manage_notes',
                    'view_reports',
                    'create_reports',
                    'social_integration',
                    'view_analytics',
                    'view_bookings',
                    'view_fleet',
                    'view_schedule',
                    'manage_tasks'
                ]
            };
            users.push(contentUser);
            await writeData(usersFile, users);
            
            console.log('✅ Content creator user CREATED successfully');
            
            res.json({ 
                success: true, 
                message: 'Content creator user created successfully',
                data: {
                    email: 'content@islandtimeltd.com',
                    password: 'content123',
                    accessLevel: 'creator',
                    permissions: contentUser.permissions
                }
            });
        } else {
            // Fix existing user
            const testPassword = await bcrypt.compare('content123', contentUser.password);
            
            res.json({ 
                success: true, 
                message: 'Content creator user exists',
                data: {
                    email: contentUser.email,
                    passwordCorrect: testPassword,
                    accessLevel: contentUser.accessLevel,
                    permissions: contentUser.permissions,
                    needsFix: !testPassword || contentUser.accessLevel !== 'creator'
                }
            });
        }
    } catch (error) {
        console.error('Fix content creator error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Failed to fix content creator: ' + error.message 
        });
    }
});
app.post('/api/debug/test-login', async (req, res) => {
    const { email, password } = req.body;
    
    try {
        const users = await readData(usersFile);
        const user = users.find(u => u.email === email && u.isActive !== false);
        
        if (!user) {
            return res.json({ 
                success: false, 
                message: 'User not found',
                exists: false 
            });
        }
        
        const passwordValid = await bcrypt.compare(password, user.password);
        
        res.json({
            success: true,
            data: {
                userExists: true,
                isActive: user.isActive,
                role: user.role,
                accessLevel: user.accessLevel,
                permissions: user.permissions,
                passwordValid: passwordValid,
                passwordHash: user.password.substring(0, 30) + '...',
                isBcrypt: user.password.startsWith('$2a$')
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});
// ======== RSS FEED FUNCTIONS ========
function cleanSummary(summary, maxLength = 200) {
    if (!summary) return 'No summary available';
    
    let clean = summary.replace(/<[^>]*>/g, '');
    clean = clean.replace(/\s+/g, ' ').trim();
    
    if (clean.length > maxLength) {
        clean = clean.substring(0, maxLength) + '...';
    }
    
    return clean;
}

function isDuplicateArticle(existingArticles, newArticle) {
    return existingArticles.some(existing => 
        existing.title === newArticle.title || 
        existing.url === newArticle.url
    );
}

async function fetchRSSNews() {
    try {
        console.log('📡 Starting RSS news fetch...');
        const news = await readData(newsFile);
        const newArticles = [];
        const allFeeds = [...BVI_RSS_FEEDS, ...WEATHER_FEEDS];

        for (const feedConfig of allFeeds) {
            try {
                console.log(`🔍 Fetching from ${feedConfig.name}...`);
                const feed = await rssParser.parseURL(feedConfig.url);
                
                if (feed.items && feed.items.length > 0) {
                    console.log(`📰 Found ${feed.items.length} items in ${feedConfig.name}`);
                    
                    for (const item of feed.items.slice(0, 10)) {
                        try {
                            const articleDate = item.pubDate ? new Date(item.pubDate) : new Date();
                            const articleSummary = cleanSummary(item.contentSnippet || item.description || item.content);
                            
                            const newArticle = {
                                id: generateId(),
                                title: item.title || 'Untitled Article',
                                source: feedConfig.name,
                                date: articleDate.toISOString().split('T')[0],
                                summary: articleSummary,
                                url: item.link || '#',
                                category: feedConfig.category,
                                createdAt: new Date().toISOString(),
                                updatedAt: new Date().toISOString(),
                                autoFetched: true,
                                publishedDate: item.pubDate || new Date().toISOString()
                            };

                            if (!isDuplicateArticle(news, newArticle) && !isDuplicateArticle(newArticles, newArticle)) {
                                newArticles.push(newArticle);
                                console.log(`✅ New article: ${newArticle.title}`);
                            }
                        } catch (itemError) {
                            console.error(`Error processing item from ${feedConfig.name}:`, itemError.message);
                        }
                    }
                } else {
                    console.log(`❌ No items found in ${feedConfig.name}`);
                }
                
                await new Promise(resolve => setTimeout(resolve, 1000));
                
            } catch (feedError) {
                console.error(`❌ Error fetching from ${feedConfig.name}:`, feedError.message);
            }
        }

        if (newArticles.length > 0 || news.length > 0) {
            const updatedNews = [...newArticles, ...news];
            updatedNews.sort((a, b) => new Date(b.publishedDate || b.date) - new Date(a.publishedDate || a.date));
            
            const thirtyDaysAgo = new Date();
            thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 15);
            
            const finalNews = updatedNews
                .filter(article => {
                    const articleDate = new Date(article.publishedDate || article.date);
                    return articleDate >= thirtyDaysAgo;
                })
                .slice(0, 20);
            
            console.log(`🗑️  Cleanup: Kept ${finalNews.length} articles (removed ${updatedNews.length - finalNews.length} old articles)`);
            
            await writeData(newsFile, finalNews);
            
            newArticles.forEach(article => {
                broadcastNewsUpdate(article, 'added');
            });
            
            console.log(`🎉 Successfully added ${newArticles.length} new articles from RSS feeds`);
            broadcastNewsFeed(finalNews);
        } else {
            console.log('ℹ️  No new articles found in RSS feeds');
        }

        return newArticles.length;
    } catch (error) {
        console.error('💥 Error in fetchRSSNews:', error);
        return 0;
    }
}

async function cleanupOldNews() {
    try {
        const news = await readData(newsFile);
        
        if (news.length === 0) return { removed: 0, kept: 0 };
        
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        
        const originalCount = news.length;
        const cleanedNews = news
            .filter(article => {
                const articleDate = new Date(article.publishedDate || article.date);
                return articleDate >= thirtyDaysAgo;
            })
            .slice(0, 20);
        
        const removedCount = originalCount - cleanedNews.length;
        
        if (removedCount > 0) {
            await writeData(newsFile, cleanedNews);
            console.log(`🧹 Cleaned up ${removedCount} old news articles. Kept ${cleanedNews.length} articles.`);
            broadcastNewsFeed(cleanedNews);
        }
        
        return { removed: removedCount, kept: cleanedNews.length };
    } catch (error) {
        console.error('Error cleaning up old news:', error);
        return { removed: 0, kept: 0 };
    }
}

// Manual RSS fetch endpoint
app.post('/api/admin/news/fetch-rss', authenticateToken, async (req, res) => {
    try {
        console.log('🔄 Manual RSS fetch triggered by admin');
        const newArticleCount = await fetchRSSNews();
        
        res.json({
            success: true,
            message: `RSS fetch completed. Added ${newArticleCount} new articles.`,
            data: { newArticleCount }
        });
    } catch (error) {
        console.error('Manual RSS fetch error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch RSS news'
        });
    }
});

// ======== STATIC FILE SERVING ========
app.use(express.static(path.join(__dirname)));

app.get('/', (req, res) => {
    res.json({ 
        message: 'Island Time BVI Booking System API',
        admin: 'Go to /admin for admin dashboard',
        portal: 'Go to /islandtime-access for staff portal',
        api: 'API endpoints available at /api/*',
        health: 'Check /api/health for server status',
        author: 'By: Jason I, the Master of None'
    });
});

app.get('/admin/*', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin', 'index.html'));
});

app.get('/islandtime-access/*', (req, res) => {
    res.sendFile(path.join(__dirname, 'islandtime-access', 'portal.html'));
});

app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    res.status(500).json({ success: false, message: 'Internal server error' });
});

app.use((req, res) => {
    res.status(404).json({ success: false, message: 'Endpoint not found' });
});

// ======== RSS CRON SCHEDULING ========
function setupRSSCron() {
    setTimeout(() => {
        console.log('🚀 Initial RSS fetch scheduled...');
        fetchRSSNews().catch(console.error);
    }, 10000);

    const TWO_HOURS = 4 * 60 * 60 * 1000;
    setInterval(() => {
        console.log('🕒 Scheduled RSS fetch running...');
        fetchRSSNews().catch(console.error);
    }, TWO_HOURS);

    const SIX_HOURS = 12 * 60 * 60 * 1000;
    setInterval(() => {
        console.log('🌤️  Weather RSS fetch running...');
        fetchRSSNews().catch(console.error);
    }, SIX_HOURS);

    const TWENTY_FOUR_HOURS = 24 * 60 * 60 * 1000;
    setInterval(() => {
        console.log('🧹 Daily news cleanup running...');
        cleanupOldNews().catch(console.error);
    }, TWENTY_FOUR_HOURS);

    console.log('⏰ RSS cron jobs scheduled: Every 2 hours (news), Every 6 hours (weather), Daily cleanup');
}

// ======== START SERVER ========
async function startServer() {
    await ensureDataFiles();
    await fixUserPasswords();

    setupRSSCron();
    setupSocialCron();

    server.listen(PORT, () => {
        console.log('🏝️  ' + '='.repeat(60));
        console.log('🏝️  Island Time BVI Booking System - Backend Server');
        console.log('🏝️  ' + '='.repeat(60));
        console.log(`🏝️  Server running on: http://localhost:${PORT}`);
        console.log(`📊  Health Check: http://localhost:${PORT}/api/health`);
        console.log(`👑  Admin Dashboard: http://localhost:${PORT}/admin`);
        console.log(`👥  Staff Portal: http://localhost:${PORT}/islandtime-access`);
        console.log('🔐  ACCESS PORTAL LOGINS:');
        console.log('🏝️  ' + '='.repeat(60));
        console.log('🔐  DEFAULT ADMIN LOGIN:');
        console.log('📧  Email: admin@islandtimebvi.com');
        console.log('🔑  Password: admin123');
        console.log('🏝️  ' + '='.repeat(60));
        console.log('🔐  ACCESS PORTAL LOGINS:');
        console.log('🚤  Boats Team: boats@islandtimebvi.com / boats123');
        console.log('   → Access: Water Taxi, Boat Rentals, Car Rentals, Fleet Management');
        console.log('🚗  Cars Team: cars@islandtimeltd.com / cars123');
        console.log('   → Access: Water Taxi, Boat Rentals, Car Rentals, Customer Management');
        console.log('📱  Content Creator: content@islandtimeltd.com / content123');
        console.log('   → Access: Content Calendar, Notes, Content Planner, Social Media, Reports');
        console.log('🧮  Accounting: accounting@islandtimeltd.com / accounting123');
        console.log('   → Access: Financial Dashboard, QuickBooks Sync, Expenses, Mapping');
        console.log('🏝️  ' + '='.repeat(60));
        console.log('🎨  CONTENT CREATOR FEATURES:');
        console.log('📅  Content Calendar with scheduling');
        console.log('📝  Notes & Reminders system');
        console.log('📋  Content Planner with pipeline');
        console.log('📊  Social Media Integration (Facebook/Instagram)');
        console.log('📈  Report Creation & Analytics');
        console.log('💡  Content Ideas management');
        console.log('🏝️  ' + '='.repeat(60));
        console.log('👨‍💻  Developed by: Jason I, the Master of None');
        console.log('🏝️  ' + '='.repeat(60));
    });
}

startServer().catch(console.error);